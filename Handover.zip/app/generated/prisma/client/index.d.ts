
/**
 * Client
**/

import * as runtime from './runtime/client.js';
import $Types = runtime.Types // general types
import $Public = runtime.Types.Public
import $Utils = runtime.Types.Utils
import $Extensions = runtime.Types.Extensions
import $Result = runtime.Types.Result

export type PrismaPromise<T> = $Public.PrismaPromise<T>


/**
 * Model User
 * 
 */
export type User = $Result.DefaultSelection<Prisma.$UserPayload>
/**
 * Model Contact
 * 
 */
export type Contact = $Result.DefaultSelection<Prisma.$ContactPayload>
/**
 * Model Message
 * 
 */
export type Message = $Result.DefaultSelection<Prisma.$MessagePayload>
/**
 * Model MessageInvite
 * 
 */
export type MessageInvite = $Result.DefaultSelection<Prisma.$MessageInvitePayload>
/**
 * Model Contribution
 * 
 */
export type Contribution = $Result.DefaultSelection<Prisma.$ContributionPayload>
/**
 * Model TimelineItem
 * 
 */
export type TimelineItem = $Result.DefaultSelection<Prisma.$TimelineItemPayload>
/**
 * Model Photo
 * 
 */
export type Photo = $Result.DefaultSelection<Prisma.$PhotoPayload>
/**
 * Model Arrangement
 * 
 */
export type Arrangement = $Result.DefaultSelection<Prisma.$ArrangementPayload>
/**
 * Model VaultItem
 * 
 */
export type VaultItem = $Result.DefaultSelection<Prisma.$VaultItemPayload>
/**
 * Model Executor
 * 
 */
export type Executor = $Result.DefaultSelection<Prisma.$ExecutorPayload>
/**
 * Model Settings
 * 
 */
export type Settings = $Result.DefaultSelection<Prisma.$SettingsPayload>

/**
 * ##  Prisma Client ʲˢ
 *
 * Type-safe database client for TypeScript & Node.js
 * @example
 * ```
 * const prisma = new PrismaClient({
 *   adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL })
 * })
 * // Fetch zero or more Users
 * const users = await prisma.user.findMany()
 * ```
 *
 *
 * Read more in our [docs](https://pris.ly/d/client).
 */
export class PrismaClient<
  ClientOptions extends Prisma.PrismaClientOptions = Prisma.PrismaClientOptions,
  const U = 'log' extends keyof ClientOptions ? ClientOptions['log'] extends Array<Prisma.LogLevel | Prisma.LogDefinition> ? Prisma.GetEvents<ClientOptions['log']> : never : never,
  ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs
> {
  [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['other'] }

    /**
   * ##  Prisma Client ʲˢ
   *
   * Type-safe database client for TypeScript & Node.js
   * @example
   * ```
   * const prisma = new PrismaClient({
   *   adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL })
   * })
   * // Fetch zero or more Users
   * const users = await prisma.user.findMany()
   * ```
   *
   *
   * Read more in our [docs](https://pris.ly/d/client).
   */

  constructor(optionsArg ?: Prisma.Subset<ClientOptions, Prisma.PrismaClientOptions>);
  $on<V extends U>(eventType: V, callback: (event: V extends 'query' ? Prisma.QueryEvent : Prisma.LogEvent) => void): PrismaClient;

  /**
   * Connect with the database
   */
  $connect(): $Utils.JsPromise<void>;

  /**
   * Disconnect from the database
   */
  $disconnect(): $Utils.JsPromise<void>;

/**
   * Executes a prepared raw query and returns the number of affected rows.
   * @example
   * ```
   * const result = await prisma.$executeRaw`UPDATE User SET cool = ${true} WHERE email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://pris.ly/d/raw-queries).
   */
  $executeRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Executes a raw query and returns the number of affected rows.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$executeRawUnsafe('UPDATE User SET cool = $1 WHERE email = $2 ;', true, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://pris.ly/d/raw-queries).
   */
  $executeRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<number>;

  /**
   * Performs a prepared raw query and returns the `SELECT` data.
   * @example
   * ```
   * const result = await prisma.$queryRaw`SELECT * FROM User WHERE id = ${1} OR email = ${'user@email.com'};`
   * ```
   *
   * Read more in our [docs](https://pris.ly/d/raw-queries).
   */
  $queryRaw<T = unknown>(query: TemplateStringsArray | Prisma.Sql, ...values: any[]): Prisma.PrismaPromise<T>;

  /**
   * Performs a raw query and returns the `SELECT` data.
   * Susceptible to SQL injections, see documentation.
   * @example
   * ```
   * const result = await prisma.$queryRawUnsafe('SELECT * FROM User WHERE id = $1 OR email = $2;', 1, 'user@email.com')
   * ```
   *
   * Read more in our [docs](https://pris.ly/d/raw-queries).
   */
  $queryRawUnsafe<T = unknown>(query: string, ...values: any[]): Prisma.PrismaPromise<T>;


  /**
   * Allows the running of a sequence of read/write operations that are guaranteed to either succeed or fail as a whole.
   * @example
   * ```
   * const [george, bob, alice] = await prisma.$transaction([
   *   prisma.user.create({ data: { name: 'George' } }),
   *   prisma.user.create({ data: { name: 'Bob' } }),
   *   prisma.user.create({ data: { name: 'Alice' } }),
   * ])
   * ```
   * 
   * Read more in our [docs](https://www.prisma.io/docs/orm/prisma-client/queries/transactions).
   */
  $transaction<P extends Prisma.PrismaPromise<any>[]>(arg: [...P], options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<runtime.Types.Utils.UnwrapTuple<P>>

  $transaction<R>(fn: (prisma: Omit<PrismaClient, runtime.ITXClientDenyList>) => $Utils.JsPromise<R>, options?: { maxWait?: number, timeout?: number, isolationLevel?: Prisma.TransactionIsolationLevel }): $Utils.JsPromise<R>

  $extends: $Extensions.ExtendsHook<"extends", Prisma.TypeMapCb<ClientOptions>, ExtArgs, $Utils.Call<Prisma.TypeMapCb<ClientOptions>, {
    extArgs: ExtArgs
  }>>

      /**
   * `prisma.user`: Exposes CRUD operations for the **User** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Users
    * const users = await prisma.user.findMany()
    * ```
    */
  get user(): Prisma.UserDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.contact`: Exposes CRUD operations for the **Contact** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Contacts
    * const contacts = await prisma.contact.findMany()
    * ```
    */
  get contact(): Prisma.ContactDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.message`: Exposes CRUD operations for the **Message** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Messages
    * const messages = await prisma.message.findMany()
    * ```
    */
  get message(): Prisma.MessageDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.messageInvite`: Exposes CRUD operations for the **MessageInvite** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more MessageInvites
    * const messageInvites = await prisma.messageInvite.findMany()
    * ```
    */
  get messageInvite(): Prisma.MessageInviteDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.contribution`: Exposes CRUD operations for the **Contribution** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Contributions
    * const contributions = await prisma.contribution.findMany()
    * ```
    */
  get contribution(): Prisma.ContributionDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.timelineItem`: Exposes CRUD operations for the **TimelineItem** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more TimelineItems
    * const timelineItems = await prisma.timelineItem.findMany()
    * ```
    */
  get timelineItem(): Prisma.TimelineItemDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.photo`: Exposes CRUD operations for the **Photo** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Photos
    * const photos = await prisma.photo.findMany()
    * ```
    */
  get photo(): Prisma.PhotoDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.arrangement`: Exposes CRUD operations for the **Arrangement** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Arrangements
    * const arrangements = await prisma.arrangement.findMany()
    * ```
    */
  get arrangement(): Prisma.ArrangementDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.vaultItem`: Exposes CRUD operations for the **VaultItem** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more VaultItems
    * const vaultItems = await prisma.vaultItem.findMany()
    * ```
    */
  get vaultItem(): Prisma.VaultItemDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.executor`: Exposes CRUD operations for the **Executor** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Executors
    * const executors = await prisma.executor.findMany()
    * ```
    */
  get executor(): Prisma.ExecutorDelegate<ExtArgs, ClientOptions>;

  /**
   * `prisma.settings`: Exposes CRUD operations for the **Settings** model.
    * Example usage:
    * ```ts
    * // Fetch zero or more Settings
    * const settings = await prisma.settings.findMany()
    * ```
    */
  get settings(): Prisma.SettingsDelegate<ExtArgs, ClientOptions>;
}

export namespace Prisma {
  export import DMMF = runtime.DMMF

  export type PrismaPromise<T> = $Public.PrismaPromise<T>

  /**
   * Validator
   */
  export import validator = runtime.Public.validator

  /**
   * Prisma Errors
   */
  export import PrismaClientKnownRequestError = runtime.PrismaClientKnownRequestError
  export import PrismaClientUnknownRequestError = runtime.PrismaClientUnknownRequestError
  export import PrismaClientRustPanicError = runtime.PrismaClientRustPanicError
  export import PrismaClientInitializationError = runtime.PrismaClientInitializationError
  export import PrismaClientValidationError = runtime.PrismaClientValidationError

  /**
   * Re-export of sql-template-tag
   */
  export import sql = runtime.sqltag
  export import empty = runtime.empty
  export import join = runtime.join
  export import raw = runtime.raw
  export import Sql = runtime.Sql



  /**
   * Decimal.js
   */
  export import Decimal = runtime.Decimal

  export type DecimalJsLike = runtime.DecimalJsLike

  /**
  * Extensions
  */
  export import Extension = $Extensions.UserArgs
  export import getExtensionContext = runtime.Extensions.getExtensionContext
  export import Args = $Public.Args
  export import Payload = $Public.Payload
  export import Result = $Public.Result
  export import Exact = $Public.Exact

  /**
   * Prisma Client JS version: 7.8.0
   * Query Engine version: 3c6e192761c0362d496ed980de936e2f3cebcd3a
   */
  export type PrismaVersion = {
    client: string
    engine: string
  }

  export const prismaVersion: PrismaVersion

  /**
   * Utility Types
   */


  export import Bytes = runtime.Bytes
  export import JsonObject = runtime.JsonObject
  export import JsonArray = runtime.JsonArray
  export import JsonValue = runtime.JsonValue
  export import InputJsonObject = runtime.InputJsonObject
  export import InputJsonArray = runtime.InputJsonArray
  export import InputJsonValue = runtime.InputJsonValue

  /**
   * Types of the values used to represent different kinds of `null` values when working with JSON fields.
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  namespace NullTypes {
    /**
    * Type of `Prisma.DbNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.DbNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class DbNull {
      private DbNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.JsonNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.JsonNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class JsonNull {
      private JsonNull: never
      private constructor()
    }

    /**
    * Type of `Prisma.AnyNull`.
    *
    * You cannot use other instances of this class. Please use the `Prisma.AnyNull` value.
    *
    * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
    */
    class AnyNull {
      private AnyNull: never
      private constructor()
    }
  }

  /**
   * Helper for filtering JSON entries that have `null` on the database (empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const DbNull: NullTypes.DbNull

  /**
   * Helper for filtering JSON entries that have JSON `null` values (not empty on the db)
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const JsonNull: NullTypes.JsonNull

  /**
   * Helper for filtering JSON entries that are `Prisma.DbNull` or `Prisma.JsonNull`
   *
   * @see https://www.prisma.io/docs/concepts/components/prisma-client/working-with-fields/working-with-json-fields#filtering-on-a-json-field
   */
  export const AnyNull: NullTypes.AnyNull

  type SelectAndInclude = {
    select: any
    include: any
  }

  type SelectAndOmit = {
    select: any
    omit: any
  }

  /**
   * Get the type of the value, that the Promise holds.
   */
  export type PromiseType<T extends PromiseLike<any>> = T extends PromiseLike<infer U> ? U : T;

  /**
   * Get the return type of a function which returns a Promise.
   */
  export type PromiseReturnType<T extends (...args: any) => $Utils.JsPromise<any>> = PromiseType<ReturnType<T>>

  /**
   * From T, pick a set of properties whose keys are in the union K
   */
  type Prisma__Pick<T, K extends keyof T> = {
      [P in K]: T[P];
  };


  export type Enumerable<T> = T | Array<T>;

  export type RequiredKeys<T> = {
    [K in keyof T]-?: {} extends Prisma__Pick<T, K> ? never : K
  }[keyof T]

  export type TruthyKeys<T> = keyof {
    [K in keyof T as T[K] extends false | undefined | null ? never : K]: K
  }

  export type TrueKeys<T> = TruthyKeys<Prisma__Pick<T, RequiredKeys<T>>>

  /**
   * Subset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection
   */
  export type Subset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never;
  };

  /**
   * SelectSubset
   * @desc From `T` pick properties that exist in `U`. Simple version of Intersection.
   * Additionally, it validates, if both select and include are present. If the case, it errors.
   */
  export type SelectSubset<T, U> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    (T extends SelectAndInclude
      ? 'Please either choose `select` or `include`.'
      : T extends SelectAndOmit
        ? 'Please either choose `select` or `omit`.'
        : {})

  /**
   * Subset + Intersection
   * @desc From `T` pick properties that exist in `U` and intersect `K`
   */
  export type SubsetIntersection<T, U, K> = {
    [key in keyof T]: key extends keyof U ? T[key] : never
  } &
    K

  type Without<T, U> = { [P in Exclude<keyof T, keyof U>]?: never };

  /**
   * XOR is needed to have a real mutually exclusive union type
   * https://stackoverflow.com/questions/42123407/does-typescript-support-mutually-exclusive-types
   */
  type XOR<T, U> =
    T extends object ?
    U extends object ?
      (Without<T, U> & U) | (Without<U, T> & T)
    : U : T


  /**
   * Is T a Record?
   */
  type IsObject<T extends any> = T extends Array<any>
  ? False
  : T extends Date
  ? False
  : T extends Uint8Array
  ? False
  : T extends BigInt
  ? False
  : T extends object
  ? True
  : False


  /**
   * If it's T[], return T
   */
  export type UnEnumerate<T extends unknown> = T extends Array<infer U> ? U : T

  /**
   * From ts-toolbelt
   */

  type __Either<O extends object, K extends Key> = Omit<O, K> &
    {
      // Merge all but K
      [P in K]: Prisma__Pick<O, P & keyof O> // With K possibilities
    }[K]

  type EitherStrict<O extends object, K extends Key> = Strict<__Either<O, K>>

  type EitherLoose<O extends object, K extends Key> = ComputeRaw<__Either<O, K>>

  type _Either<
    O extends object,
    K extends Key,
    strict extends Boolean
  > = {
    1: EitherStrict<O, K>
    0: EitherLoose<O, K>
  }[strict]

  type Either<
    O extends object,
    K extends Key,
    strict extends Boolean = 1
  > = O extends unknown ? _Either<O, K, strict> : never

  export type Union = any

  type PatchUndefined<O extends object, O1 extends object> = {
    [K in keyof O]: O[K] extends undefined ? At<O1, K> : O[K]
  } & {}

  /** Helper Types for "Merge" **/
  export type IntersectOf<U extends Union> = (
    U extends unknown ? (k: U) => void : never
  ) extends (k: infer I) => void
    ? I
    : never

  export type Overwrite<O extends object, O1 extends object> = {
      [K in keyof O]: K extends keyof O1 ? O1[K] : O[K];
  } & {};

  type _Merge<U extends object> = IntersectOf<Overwrite<U, {
      [K in keyof U]-?: At<U, K>;
  }>>;

  type Key = string | number | symbol;
  type AtBasic<O extends object, K extends Key> = K extends keyof O ? O[K] : never;
  type AtStrict<O extends object, K extends Key> = O[K & keyof O];
  type AtLoose<O extends object, K extends Key> = O extends unknown ? AtStrict<O, K> : never;
  export type At<O extends object, K extends Key, strict extends Boolean = 1> = {
      1: AtStrict<O, K>;
      0: AtLoose<O, K>;
  }[strict];

  export type ComputeRaw<A extends any> = A extends Function ? A : {
    [K in keyof A]: A[K];
  } & {};

  export type OptionalFlat<O> = {
    [K in keyof O]?: O[K];
  } & {};

  type _Record<K extends keyof any, T> = {
    [P in K]: T;
  };

  // cause typescript not to expand types and preserve names
  type NoExpand<T> = T extends unknown ? T : never;

  // this type assumes the passed object is entirely optional
  type AtLeast<O extends object, K extends string> = NoExpand<
    O extends unknown
    ? | (K extends keyof O ? { [P in K]: O[P] } & O : O)
      | {[P in keyof O as P extends K ? P : never]-?: O[P]} & O
    : never>;

  type _Strict<U, _U = U> = U extends unknown ? U & OptionalFlat<_Record<Exclude<Keys<_U>, keyof U>, never>> : never;

  export type Strict<U extends object> = ComputeRaw<_Strict<U>>;
  /** End Helper Types for "Merge" **/

  export type Merge<U extends object> = ComputeRaw<_Merge<Strict<U>>>;

  /**
  A [[Boolean]]
  */
  export type Boolean = True | False

  // /**
  // 1
  // */
  export type True = 1

  /**
  0
  */
  export type False = 0

  export type Not<B extends Boolean> = {
    0: 1
    1: 0
  }[B]

  export type Extends<A1 extends any, A2 extends any> = [A1] extends [never]
    ? 0 // anything `never` is false
    : A1 extends A2
    ? 1
    : 0

  export type Has<U extends Union, U1 extends Union> = Not<
    Extends<Exclude<U1, U>, U1>
  >

  export type Or<B1 extends Boolean, B2 extends Boolean> = {
    0: {
      0: 0
      1: 1
    }
    1: {
      0: 1
      1: 1
    }
  }[B1][B2]

  export type Keys<U extends Union> = U extends unknown ? keyof U : never

  type Cast<A, B> = A extends B ? A : B;

  export const type: unique symbol;



  /**
   * Used by group by
   */

  export type GetScalarType<T, O> = O extends object ? {
    [P in keyof T]: P extends keyof O
      ? O[P]
      : never
  } : never

  type FieldPaths<
    T,
    U = Omit<T, '_avg' | '_sum' | '_count' | '_min' | '_max'>
  > = IsObject<T> extends True ? U : T

  type GetHavingFields<T> = {
    [K in keyof T]: Or<
      Or<Extends<'OR', K>, Extends<'AND', K>>,
      Extends<'NOT', K>
    > extends True
      ? // infer is only needed to not hit TS limit
        // based on the brilliant idea of Pierre-Antoine Mills
        // https://github.com/microsoft/TypeScript/issues/30188#issuecomment-478938437
        T[K] extends infer TK
        ? GetHavingFields<UnEnumerate<TK> extends object ? Merge<UnEnumerate<TK>> : never>
        : never
      : {} extends FieldPaths<T[K]>
      ? never
      : K
  }[keyof T]

  /**
   * Convert tuple to union
   */
  type _TupleToUnion<T> = T extends (infer E)[] ? E : never
  type TupleToUnion<K extends readonly any[]> = _TupleToUnion<K>
  type MaybeTupleToUnion<T> = T extends any[] ? TupleToUnion<T> : T

  /**
   * Like `Pick`, but additionally can also accept an array of keys
   */
  type PickEnumerable<T, K extends Enumerable<keyof T> | keyof T> = Prisma__Pick<T, MaybeTupleToUnion<K>>

  /**
   * Exclude all keys with underscores
   */
  type ExcludeUnderscoreKeys<T extends string> = T extends `_${string}` ? never : T


  export type FieldRef<Model, FieldType> = runtime.FieldRef<Model, FieldType>

  type FieldRefInputType<Model, FieldType> = Model extends never ? never : FieldRef<Model, FieldType>


  export const ModelName: {
    User: 'User',
    Contact: 'Contact',
    Message: 'Message',
    MessageInvite: 'MessageInvite',
    Contribution: 'Contribution',
    TimelineItem: 'TimelineItem',
    Photo: 'Photo',
    Arrangement: 'Arrangement',
    VaultItem: 'VaultItem',
    Executor: 'Executor',
    Settings: 'Settings'
  };

  export type ModelName = (typeof ModelName)[keyof typeof ModelName]



  interface TypeMapCb<ClientOptions = {}> extends $Utils.Fn<{extArgs: $Extensions.InternalArgs }, $Utils.Record<string, any>> {
    returns: Prisma.TypeMap<this['params']['extArgs'], ClientOptions extends { omit: infer OmitOptions } ? OmitOptions : {}>
  }

  export type TypeMap<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> = {
    globalOmitOptions: {
      omit: GlobalOmitOptions
    }
    meta: {
      modelProps: "user" | "contact" | "message" | "messageInvite" | "contribution" | "timelineItem" | "photo" | "arrangement" | "vaultItem" | "executor" | "settings"
      txIsolationLevel: Prisma.TransactionIsolationLevel
    }
    model: {
      User: {
        payload: Prisma.$UserPayload<ExtArgs>
        fields: Prisma.UserFieldRefs
        operations: {
          findUnique: {
            args: Prisma.UserFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.UserFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          findFirst: {
            args: Prisma.UserFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.UserFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          findMany: {
            args: Prisma.UserFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>[]
          }
          create: {
            args: Prisma.UserCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          createMany: {
            args: Prisma.UserCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.UserCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>[]
          }
          delete: {
            args: Prisma.UserDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          update: {
            args: Prisma.UserUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          deleteMany: {
            args: Prisma.UserDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.UserUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.UserUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>[]
          }
          upsert: {
            args: Prisma.UserUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$UserPayload>
          }
          aggregate: {
            args: Prisma.UserAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateUser>
          }
          groupBy: {
            args: Prisma.UserGroupByArgs<ExtArgs>
            result: $Utils.Optional<UserGroupByOutputType>[]
          }
          count: {
            args: Prisma.UserCountArgs<ExtArgs>
            result: $Utils.Optional<UserCountAggregateOutputType> | number
          }
        }
      }
      Contact: {
        payload: Prisma.$ContactPayload<ExtArgs>
        fields: Prisma.ContactFieldRefs
        operations: {
          findUnique: {
            args: Prisma.ContactFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ContactPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.ContactFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ContactPayload>
          }
          findFirst: {
            args: Prisma.ContactFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ContactPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.ContactFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ContactPayload>
          }
          findMany: {
            args: Prisma.ContactFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ContactPayload>[]
          }
          create: {
            args: Prisma.ContactCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ContactPayload>
          }
          createMany: {
            args: Prisma.ContactCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.ContactCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ContactPayload>[]
          }
          delete: {
            args: Prisma.ContactDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ContactPayload>
          }
          update: {
            args: Prisma.ContactUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ContactPayload>
          }
          deleteMany: {
            args: Prisma.ContactDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.ContactUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.ContactUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ContactPayload>[]
          }
          upsert: {
            args: Prisma.ContactUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ContactPayload>
          }
          aggregate: {
            args: Prisma.ContactAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateContact>
          }
          groupBy: {
            args: Prisma.ContactGroupByArgs<ExtArgs>
            result: $Utils.Optional<ContactGroupByOutputType>[]
          }
          count: {
            args: Prisma.ContactCountArgs<ExtArgs>
            result: $Utils.Optional<ContactCountAggregateOutputType> | number
          }
        }
      }
      Message: {
        payload: Prisma.$MessagePayload<ExtArgs>
        fields: Prisma.MessageFieldRefs
        operations: {
          findUnique: {
            args: Prisma.MessageFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MessagePayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.MessageFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MessagePayload>
          }
          findFirst: {
            args: Prisma.MessageFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MessagePayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.MessageFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MessagePayload>
          }
          findMany: {
            args: Prisma.MessageFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MessagePayload>[]
          }
          create: {
            args: Prisma.MessageCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MessagePayload>
          }
          createMany: {
            args: Prisma.MessageCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.MessageCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MessagePayload>[]
          }
          delete: {
            args: Prisma.MessageDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MessagePayload>
          }
          update: {
            args: Prisma.MessageUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MessagePayload>
          }
          deleteMany: {
            args: Prisma.MessageDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.MessageUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.MessageUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MessagePayload>[]
          }
          upsert: {
            args: Prisma.MessageUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MessagePayload>
          }
          aggregate: {
            args: Prisma.MessageAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateMessage>
          }
          groupBy: {
            args: Prisma.MessageGroupByArgs<ExtArgs>
            result: $Utils.Optional<MessageGroupByOutputType>[]
          }
          count: {
            args: Prisma.MessageCountArgs<ExtArgs>
            result: $Utils.Optional<MessageCountAggregateOutputType> | number
          }
        }
      }
      MessageInvite: {
        payload: Prisma.$MessageInvitePayload<ExtArgs>
        fields: Prisma.MessageInviteFieldRefs
        operations: {
          findUnique: {
            args: Prisma.MessageInviteFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MessageInvitePayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.MessageInviteFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MessageInvitePayload>
          }
          findFirst: {
            args: Prisma.MessageInviteFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MessageInvitePayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.MessageInviteFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MessageInvitePayload>
          }
          findMany: {
            args: Prisma.MessageInviteFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MessageInvitePayload>[]
          }
          create: {
            args: Prisma.MessageInviteCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MessageInvitePayload>
          }
          createMany: {
            args: Prisma.MessageInviteCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.MessageInviteCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MessageInvitePayload>[]
          }
          delete: {
            args: Prisma.MessageInviteDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MessageInvitePayload>
          }
          update: {
            args: Prisma.MessageInviteUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MessageInvitePayload>
          }
          deleteMany: {
            args: Prisma.MessageInviteDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.MessageInviteUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.MessageInviteUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MessageInvitePayload>[]
          }
          upsert: {
            args: Prisma.MessageInviteUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$MessageInvitePayload>
          }
          aggregate: {
            args: Prisma.MessageInviteAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateMessageInvite>
          }
          groupBy: {
            args: Prisma.MessageInviteGroupByArgs<ExtArgs>
            result: $Utils.Optional<MessageInviteGroupByOutputType>[]
          }
          count: {
            args: Prisma.MessageInviteCountArgs<ExtArgs>
            result: $Utils.Optional<MessageInviteCountAggregateOutputType> | number
          }
        }
      }
      Contribution: {
        payload: Prisma.$ContributionPayload<ExtArgs>
        fields: Prisma.ContributionFieldRefs
        operations: {
          findUnique: {
            args: Prisma.ContributionFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ContributionPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.ContributionFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ContributionPayload>
          }
          findFirst: {
            args: Prisma.ContributionFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ContributionPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.ContributionFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ContributionPayload>
          }
          findMany: {
            args: Prisma.ContributionFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ContributionPayload>[]
          }
          create: {
            args: Prisma.ContributionCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ContributionPayload>
          }
          createMany: {
            args: Prisma.ContributionCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.ContributionCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ContributionPayload>[]
          }
          delete: {
            args: Prisma.ContributionDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ContributionPayload>
          }
          update: {
            args: Prisma.ContributionUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ContributionPayload>
          }
          deleteMany: {
            args: Prisma.ContributionDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.ContributionUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.ContributionUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ContributionPayload>[]
          }
          upsert: {
            args: Prisma.ContributionUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ContributionPayload>
          }
          aggregate: {
            args: Prisma.ContributionAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateContribution>
          }
          groupBy: {
            args: Prisma.ContributionGroupByArgs<ExtArgs>
            result: $Utils.Optional<ContributionGroupByOutputType>[]
          }
          count: {
            args: Prisma.ContributionCountArgs<ExtArgs>
            result: $Utils.Optional<ContributionCountAggregateOutputType> | number
          }
        }
      }
      TimelineItem: {
        payload: Prisma.$TimelineItemPayload<ExtArgs>
        fields: Prisma.TimelineItemFieldRefs
        operations: {
          findUnique: {
            args: Prisma.TimelineItemFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TimelineItemPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.TimelineItemFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TimelineItemPayload>
          }
          findFirst: {
            args: Prisma.TimelineItemFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TimelineItemPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.TimelineItemFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TimelineItemPayload>
          }
          findMany: {
            args: Prisma.TimelineItemFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TimelineItemPayload>[]
          }
          create: {
            args: Prisma.TimelineItemCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TimelineItemPayload>
          }
          createMany: {
            args: Prisma.TimelineItemCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.TimelineItemCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TimelineItemPayload>[]
          }
          delete: {
            args: Prisma.TimelineItemDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TimelineItemPayload>
          }
          update: {
            args: Prisma.TimelineItemUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TimelineItemPayload>
          }
          deleteMany: {
            args: Prisma.TimelineItemDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.TimelineItemUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.TimelineItemUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TimelineItemPayload>[]
          }
          upsert: {
            args: Prisma.TimelineItemUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$TimelineItemPayload>
          }
          aggregate: {
            args: Prisma.TimelineItemAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateTimelineItem>
          }
          groupBy: {
            args: Prisma.TimelineItemGroupByArgs<ExtArgs>
            result: $Utils.Optional<TimelineItemGroupByOutputType>[]
          }
          count: {
            args: Prisma.TimelineItemCountArgs<ExtArgs>
            result: $Utils.Optional<TimelineItemCountAggregateOutputType> | number
          }
        }
      }
      Photo: {
        payload: Prisma.$PhotoPayload<ExtArgs>
        fields: Prisma.PhotoFieldRefs
        operations: {
          findUnique: {
            args: Prisma.PhotoFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PhotoPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.PhotoFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PhotoPayload>
          }
          findFirst: {
            args: Prisma.PhotoFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PhotoPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.PhotoFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PhotoPayload>
          }
          findMany: {
            args: Prisma.PhotoFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PhotoPayload>[]
          }
          create: {
            args: Prisma.PhotoCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PhotoPayload>
          }
          createMany: {
            args: Prisma.PhotoCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.PhotoCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PhotoPayload>[]
          }
          delete: {
            args: Prisma.PhotoDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PhotoPayload>
          }
          update: {
            args: Prisma.PhotoUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PhotoPayload>
          }
          deleteMany: {
            args: Prisma.PhotoDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.PhotoUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.PhotoUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PhotoPayload>[]
          }
          upsert: {
            args: Prisma.PhotoUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$PhotoPayload>
          }
          aggregate: {
            args: Prisma.PhotoAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregatePhoto>
          }
          groupBy: {
            args: Prisma.PhotoGroupByArgs<ExtArgs>
            result: $Utils.Optional<PhotoGroupByOutputType>[]
          }
          count: {
            args: Prisma.PhotoCountArgs<ExtArgs>
            result: $Utils.Optional<PhotoCountAggregateOutputType> | number
          }
        }
      }
      Arrangement: {
        payload: Prisma.$ArrangementPayload<ExtArgs>
        fields: Prisma.ArrangementFieldRefs
        operations: {
          findUnique: {
            args: Prisma.ArrangementFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ArrangementPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.ArrangementFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ArrangementPayload>
          }
          findFirst: {
            args: Prisma.ArrangementFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ArrangementPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.ArrangementFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ArrangementPayload>
          }
          findMany: {
            args: Prisma.ArrangementFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ArrangementPayload>[]
          }
          create: {
            args: Prisma.ArrangementCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ArrangementPayload>
          }
          createMany: {
            args: Prisma.ArrangementCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.ArrangementCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ArrangementPayload>[]
          }
          delete: {
            args: Prisma.ArrangementDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ArrangementPayload>
          }
          update: {
            args: Prisma.ArrangementUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ArrangementPayload>
          }
          deleteMany: {
            args: Prisma.ArrangementDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.ArrangementUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.ArrangementUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ArrangementPayload>[]
          }
          upsert: {
            args: Prisma.ArrangementUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ArrangementPayload>
          }
          aggregate: {
            args: Prisma.ArrangementAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateArrangement>
          }
          groupBy: {
            args: Prisma.ArrangementGroupByArgs<ExtArgs>
            result: $Utils.Optional<ArrangementGroupByOutputType>[]
          }
          count: {
            args: Prisma.ArrangementCountArgs<ExtArgs>
            result: $Utils.Optional<ArrangementCountAggregateOutputType> | number
          }
        }
      }
      VaultItem: {
        payload: Prisma.$VaultItemPayload<ExtArgs>
        fields: Prisma.VaultItemFieldRefs
        operations: {
          findUnique: {
            args: Prisma.VaultItemFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VaultItemPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.VaultItemFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VaultItemPayload>
          }
          findFirst: {
            args: Prisma.VaultItemFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VaultItemPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.VaultItemFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VaultItemPayload>
          }
          findMany: {
            args: Prisma.VaultItemFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VaultItemPayload>[]
          }
          create: {
            args: Prisma.VaultItemCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VaultItemPayload>
          }
          createMany: {
            args: Prisma.VaultItemCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.VaultItemCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VaultItemPayload>[]
          }
          delete: {
            args: Prisma.VaultItemDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VaultItemPayload>
          }
          update: {
            args: Prisma.VaultItemUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VaultItemPayload>
          }
          deleteMany: {
            args: Prisma.VaultItemDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.VaultItemUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.VaultItemUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VaultItemPayload>[]
          }
          upsert: {
            args: Prisma.VaultItemUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$VaultItemPayload>
          }
          aggregate: {
            args: Prisma.VaultItemAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateVaultItem>
          }
          groupBy: {
            args: Prisma.VaultItemGroupByArgs<ExtArgs>
            result: $Utils.Optional<VaultItemGroupByOutputType>[]
          }
          count: {
            args: Prisma.VaultItemCountArgs<ExtArgs>
            result: $Utils.Optional<VaultItemCountAggregateOutputType> | number
          }
        }
      }
      Executor: {
        payload: Prisma.$ExecutorPayload<ExtArgs>
        fields: Prisma.ExecutorFieldRefs
        operations: {
          findUnique: {
            args: Prisma.ExecutorFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExecutorPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.ExecutorFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExecutorPayload>
          }
          findFirst: {
            args: Prisma.ExecutorFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExecutorPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.ExecutorFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExecutorPayload>
          }
          findMany: {
            args: Prisma.ExecutorFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExecutorPayload>[]
          }
          create: {
            args: Prisma.ExecutorCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExecutorPayload>
          }
          createMany: {
            args: Prisma.ExecutorCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.ExecutorCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExecutorPayload>[]
          }
          delete: {
            args: Prisma.ExecutorDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExecutorPayload>
          }
          update: {
            args: Prisma.ExecutorUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExecutorPayload>
          }
          deleteMany: {
            args: Prisma.ExecutorDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.ExecutorUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.ExecutorUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExecutorPayload>[]
          }
          upsert: {
            args: Prisma.ExecutorUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$ExecutorPayload>
          }
          aggregate: {
            args: Prisma.ExecutorAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateExecutor>
          }
          groupBy: {
            args: Prisma.ExecutorGroupByArgs<ExtArgs>
            result: $Utils.Optional<ExecutorGroupByOutputType>[]
          }
          count: {
            args: Prisma.ExecutorCountArgs<ExtArgs>
            result: $Utils.Optional<ExecutorCountAggregateOutputType> | number
          }
        }
      }
      Settings: {
        payload: Prisma.$SettingsPayload<ExtArgs>
        fields: Prisma.SettingsFieldRefs
        operations: {
          findUnique: {
            args: Prisma.SettingsFindUniqueArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SettingsPayload> | null
          }
          findUniqueOrThrow: {
            args: Prisma.SettingsFindUniqueOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SettingsPayload>
          }
          findFirst: {
            args: Prisma.SettingsFindFirstArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SettingsPayload> | null
          }
          findFirstOrThrow: {
            args: Prisma.SettingsFindFirstOrThrowArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SettingsPayload>
          }
          findMany: {
            args: Prisma.SettingsFindManyArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SettingsPayload>[]
          }
          create: {
            args: Prisma.SettingsCreateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SettingsPayload>
          }
          createMany: {
            args: Prisma.SettingsCreateManyArgs<ExtArgs>
            result: BatchPayload
          }
          createManyAndReturn: {
            args: Prisma.SettingsCreateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SettingsPayload>[]
          }
          delete: {
            args: Prisma.SettingsDeleteArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SettingsPayload>
          }
          update: {
            args: Prisma.SettingsUpdateArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SettingsPayload>
          }
          deleteMany: {
            args: Prisma.SettingsDeleteManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateMany: {
            args: Prisma.SettingsUpdateManyArgs<ExtArgs>
            result: BatchPayload
          }
          updateManyAndReturn: {
            args: Prisma.SettingsUpdateManyAndReturnArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SettingsPayload>[]
          }
          upsert: {
            args: Prisma.SettingsUpsertArgs<ExtArgs>
            result: $Utils.PayloadToResult<Prisma.$SettingsPayload>
          }
          aggregate: {
            args: Prisma.SettingsAggregateArgs<ExtArgs>
            result: $Utils.Optional<AggregateSettings>
          }
          groupBy: {
            args: Prisma.SettingsGroupByArgs<ExtArgs>
            result: $Utils.Optional<SettingsGroupByOutputType>[]
          }
          count: {
            args: Prisma.SettingsCountArgs<ExtArgs>
            result: $Utils.Optional<SettingsCountAggregateOutputType> | number
          }
        }
      }
    }
  } & {
    other: {
      payload: any
      operations: {
        $executeRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $executeRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
        $queryRaw: {
          args: [query: TemplateStringsArray | Prisma.Sql, ...values: any[]],
          result: any
        }
        $queryRawUnsafe: {
          args: [query: string, ...values: any[]],
          result: any
        }
      }
    }
  }
  export const defineExtension: $Extensions.ExtendsHook<"define", Prisma.TypeMapCb, $Extensions.DefaultArgs>
  export type DefaultPrismaClient = PrismaClient
  export type ErrorFormat = 'pretty' | 'colorless' | 'minimal'
  export interface PrismaClientOptions {
    /**
     * @default "colorless"
     */
    errorFormat?: ErrorFormat
    /**
     * @example
     * ```
     * // Shorthand for `emit: 'stdout'`
     * log: ['query', 'info', 'warn', 'error']
     * 
     * // Emit as events only
     * log: [
     *   { emit: 'event', level: 'query' },
     *   { emit: 'event', level: 'info' },
     *   { emit: 'event', level: 'warn' }
     *   { emit: 'event', level: 'error' }
     * ]
     * 
     * / Emit as events and log to stdout
     * og: [
     *  { emit: 'stdout', level: 'query' },
     *  { emit: 'stdout', level: 'info' },
     *  { emit: 'stdout', level: 'warn' }
     *  { emit: 'stdout', level: 'error' }
     * 
     * ```
     * Read more in our [docs](https://pris.ly/d/logging).
     */
    log?: (LogLevel | LogDefinition)[]
    /**
     * The default values for transactionOptions
     * maxWait ?= 2000
     * timeout ?= 5000
     */
    transactionOptions?: {
      maxWait?: number
      timeout?: number
      isolationLevel?: Prisma.TransactionIsolationLevel
    }
    /**
     * Instance of a Driver Adapter, e.g., like one provided by `@prisma/adapter-planetscale`
     */
    adapter?: runtime.SqlDriverAdapterFactory
    /**
     * Prisma Accelerate URL allowing the client to connect through Accelerate instead of a direct database.
     */
    accelerateUrl?: string
    /**
     * Global configuration for omitting model fields by default.
     * 
     * @example
     * ```
     * const prisma = new PrismaClient({
     *   omit: {
     *     user: {
     *       password: true
     *     }
     *   }
     * })
     * ```
     */
    omit?: Prisma.GlobalOmitConfig
    /**
     * SQL commenter plugins that add metadata to SQL queries as comments.
     * Comments follow the sqlcommenter format: https://google.github.io/sqlcommenter/
     * 
     * @example
     * ```
     * const prisma = new PrismaClient({
     *   adapter,
     *   comments: [
     *     traceContext(),
     *     queryInsights(),
     *   ],
     * })
     * ```
     */
    comments?: runtime.SqlCommenterPlugin[]
  }
  export type GlobalOmitConfig = {
    user?: UserOmit
    contact?: ContactOmit
    message?: MessageOmit
    messageInvite?: MessageInviteOmit
    contribution?: ContributionOmit
    timelineItem?: TimelineItemOmit
    photo?: PhotoOmit
    arrangement?: ArrangementOmit
    vaultItem?: VaultItemOmit
    executor?: ExecutorOmit
    settings?: SettingsOmit
  }

  /* Types for Logging */
  export type LogLevel = 'info' | 'query' | 'warn' | 'error'
  export type LogDefinition = {
    level: LogLevel
    emit: 'stdout' | 'event'
  }

  export type CheckIsLogLevel<T> = T extends LogLevel ? T : never;

  export type GetLogType<T> = CheckIsLogLevel<
    T extends LogDefinition ? T['level'] : T
  >;

  export type GetEvents<T extends any[]> = T extends Array<LogLevel | LogDefinition>
    ? GetLogType<T[number]>
    : never;

  export type QueryEvent = {
    timestamp: Date
    query: string
    params: string
    duration: number
    target: string
  }

  export type LogEvent = {
    timestamp: Date
    message: string
    target: string
  }
  /* End Types for Logging */


  export type PrismaAction =
    | 'findUnique'
    | 'findUniqueOrThrow'
    | 'findMany'
    | 'findFirst'
    | 'findFirstOrThrow'
    | 'create'
    | 'createMany'
    | 'createManyAndReturn'
    | 'update'
    | 'updateMany'
    | 'updateManyAndReturn'
    | 'upsert'
    | 'delete'
    | 'deleteMany'
    | 'executeRaw'
    | 'queryRaw'
    | 'aggregate'
    | 'count'
    | 'runCommandRaw'
    | 'findRaw'
    | 'groupBy'

  // tested in getLogLevel.test.ts
  export function getLogLevel(log: Array<LogLevel | LogDefinition>): LogLevel | undefined;

  /**
   * `PrismaClient` proxy available in interactive transactions.
   */
  export type TransactionClient = Omit<Prisma.DefaultPrismaClient, runtime.ITXClientDenyList>

  export type Datasource = {
    url?: string
  }

  /**
   * Count Types
   */


  /**
   * Count Type UserCountOutputType
   */

  export type UserCountOutputType = {
    contacts: number
    messages: number
    arrangements: number
    timelineItems: number
    vaultItems: number
    photos: number
    messageInvites: number
    contributions: number
  }

  export type UserCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    contacts?: boolean | UserCountOutputTypeCountContactsArgs
    messages?: boolean | UserCountOutputTypeCountMessagesArgs
    arrangements?: boolean | UserCountOutputTypeCountArrangementsArgs
    timelineItems?: boolean | UserCountOutputTypeCountTimelineItemsArgs
    vaultItems?: boolean | UserCountOutputTypeCountVaultItemsArgs
    photos?: boolean | UserCountOutputTypeCountPhotosArgs
    messageInvites?: boolean | UserCountOutputTypeCountMessageInvitesArgs
    contributions?: boolean | UserCountOutputTypeCountContributionsArgs
  }

  // Custom InputTypes
  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the UserCountOutputType
     */
    select?: UserCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountContactsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ContactWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountMessagesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: MessageWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountArrangementsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ArrangementWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountTimelineItemsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: TimelineItemWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountVaultItemsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: VaultItemWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountPhotosArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PhotoWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountMessageInvitesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: MessageInviteWhereInput
  }

  /**
   * UserCountOutputType without action
   */
  export type UserCountOutputTypeCountContributionsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ContributionWhereInput
  }


  /**
   * Count Type MessageInviteCountOutputType
   */

  export type MessageInviteCountOutputType = {
    contributions: number
  }

  export type MessageInviteCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    contributions?: boolean | MessageInviteCountOutputTypeCountContributionsArgs
  }

  // Custom InputTypes
  /**
   * MessageInviteCountOutputType without action
   */
  export type MessageInviteCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MessageInviteCountOutputType
     */
    select?: MessageInviteCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * MessageInviteCountOutputType without action
   */
  export type MessageInviteCountOutputTypeCountContributionsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ContributionWhereInput
  }


  /**
   * Count Type TimelineItemCountOutputType
   */

  export type TimelineItemCountOutputType = {
    photos: number
  }

  export type TimelineItemCountOutputTypeSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    photos?: boolean | TimelineItemCountOutputTypeCountPhotosArgs
  }

  // Custom InputTypes
  /**
   * TimelineItemCountOutputType without action
   */
  export type TimelineItemCountOutputTypeDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TimelineItemCountOutputType
     */
    select?: TimelineItemCountOutputTypeSelect<ExtArgs> | null
  }

  /**
   * TimelineItemCountOutputType without action
   */
  export type TimelineItemCountOutputTypeCountPhotosArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PhotoWhereInput
  }


  /**
   * Models
   */

  /**
   * Model User
   */

  export type AggregateUser = {
    _count: UserCountAggregateOutputType | null
    _min: UserMinAggregateOutputType | null
    _max: UserMaxAggregateOutputType | null
  }

  export type UserMinAggregateOutputType = {
    id: string | null
    email: string | null
    name: string | null
    plan: string | null
    pendingDeathVerificationAt: Date | null
    deceasedAt: Date | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type UserMaxAggregateOutputType = {
    id: string | null
    email: string | null
    name: string | null
    plan: string | null
    pendingDeathVerificationAt: Date | null
    deceasedAt: Date | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type UserCountAggregateOutputType = {
    id: number
    email: number
    name: number
    plan: number
    pendingDeathVerificationAt: number
    deceasedAt: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type UserMinAggregateInputType = {
    id?: true
    email?: true
    name?: true
    plan?: true
    pendingDeathVerificationAt?: true
    deceasedAt?: true
    createdAt?: true
    updatedAt?: true
  }

  export type UserMaxAggregateInputType = {
    id?: true
    email?: true
    name?: true
    plan?: true
    pendingDeathVerificationAt?: true
    deceasedAt?: true
    createdAt?: true
    updatedAt?: true
  }

  export type UserCountAggregateInputType = {
    id?: true
    email?: true
    name?: true
    plan?: true
    pendingDeathVerificationAt?: true
    deceasedAt?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type UserAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which User to aggregate.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Users
    **/
    _count?: true | UserCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: UserMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: UserMaxAggregateInputType
  }

  export type GetUserAggregateType<T extends UserAggregateArgs> = {
        [P in keyof T & keyof AggregateUser]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateUser[P]>
      : GetScalarType<T[P], AggregateUser[P]>
  }




  export type UserGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: UserWhereInput
    orderBy?: UserOrderByWithAggregationInput | UserOrderByWithAggregationInput[]
    by: UserScalarFieldEnum[] | UserScalarFieldEnum
    having?: UserScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: UserCountAggregateInputType | true
    _min?: UserMinAggregateInputType
    _max?: UserMaxAggregateInputType
  }

  export type UserGroupByOutputType = {
    id: string
    email: string
    name: string | null
    plan: string
    pendingDeathVerificationAt: Date | null
    deceasedAt: Date | null
    createdAt: Date
    updatedAt: Date
    _count: UserCountAggregateOutputType | null
    _min: UserMinAggregateOutputType | null
    _max: UserMaxAggregateOutputType | null
  }

  type GetUserGroupByPayload<T extends UserGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<UserGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof UserGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], UserGroupByOutputType[P]>
            : GetScalarType<T[P], UserGroupByOutputType[P]>
        }
      >
    >


  export type UserSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    email?: boolean
    name?: boolean
    plan?: boolean
    pendingDeathVerificationAt?: boolean
    deceasedAt?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    contacts?: boolean | User$contactsArgs<ExtArgs>
    messages?: boolean | User$messagesArgs<ExtArgs>
    arrangements?: boolean | User$arrangementsArgs<ExtArgs>
    timelineItems?: boolean | User$timelineItemsArgs<ExtArgs>
    vaultItems?: boolean | User$vaultItemsArgs<ExtArgs>
    executor?: boolean | User$executorArgs<ExtArgs>
    photos?: boolean | User$photosArgs<ExtArgs>
    settings?: boolean | User$settingsArgs<ExtArgs>
    messageInvites?: boolean | User$messageInvitesArgs<ExtArgs>
    contributions?: boolean | User$contributionsArgs<ExtArgs>
    _count?: boolean | UserCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["user"]>

  export type UserSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    email?: boolean
    name?: boolean
    plan?: boolean
    pendingDeathVerificationAt?: boolean
    deceasedAt?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["user"]>

  export type UserSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    email?: boolean
    name?: boolean
    plan?: boolean
    pendingDeathVerificationAt?: boolean
    deceasedAt?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }, ExtArgs["result"]["user"]>

  export type UserSelectScalar = {
    id?: boolean
    email?: boolean
    name?: boolean
    plan?: boolean
    pendingDeathVerificationAt?: boolean
    deceasedAt?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type UserOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "email" | "name" | "plan" | "pendingDeathVerificationAt" | "deceasedAt" | "createdAt" | "updatedAt", ExtArgs["result"]["user"]>
  export type UserInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    contacts?: boolean | User$contactsArgs<ExtArgs>
    messages?: boolean | User$messagesArgs<ExtArgs>
    arrangements?: boolean | User$arrangementsArgs<ExtArgs>
    timelineItems?: boolean | User$timelineItemsArgs<ExtArgs>
    vaultItems?: boolean | User$vaultItemsArgs<ExtArgs>
    executor?: boolean | User$executorArgs<ExtArgs>
    photos?: boolean | User$photosArgs<ExtArgs>
    settings?: boolean | User$settingsArgs<ExtArgs>
    messageInvites?: boolean | User$messageInvitesArgs<ExtArgs>
    contributions?: boolean | User$contributionsArgs<ExtArgs>
    _count?: boolean | UserCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type UserIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}
  export type UserIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {}

  export type $UserPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "User"
    objects: {
      contacts: Prisma.$ContactPayload<ExtArgs>[]
      messages: Prisma.$MessagePayload<ExtArgs>[]
      arrangements: Prisma.$ArrangementPayload<ExtArgs>[]
      timelineItems: Prisma.$TimelineItemPayload<ExtArgs>[]
      vaultItems: Prisma.$VaultItemPayload<ExtArgs>[]
      executor: Prisma.$ExecutorPayload<ExtArgs> | null
      photos: Prisma.$PhotoPayload<ExtArgs>[]
      settings: Prisma.$SettingsPayload<ExtArgs> | null
      messageInvites: Prisma.$MessageInvitePayload<ExtArgs>[]
      contributions: Prisma.$ContributionPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      email: string
      name: string | null
      plan: string
      pendingDeathVerificationAt: Date | null
      deceasedAt: Date | null
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["user"]>
    composites: {}
  }

  type UserGetPayload<S extends boolean | null | undefined | UserDefaultArgs> = $Result.GetResult<Prisma.$UserPayload, S>

  type UserCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<UserFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: UserCountAggregateInputType | true
    }

  export interface UserDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['User'], meta: { name: 'User' } }
    /**
     * Find zero or one User that matches the filter.
     * @param {UserFindUniqueArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends UserFindUniqueArgs>(args: SelectSubset<T, UserFindUniqueArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one User that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {UserFindUniqueOrThrowArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends UserFindUniqueOrThrowArgs>(args: SelectSubset<T, UserFindUniqueOrThrowArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first User that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindFirstArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends UserFindFirstArgs>(args?: SelectSubset<T, UserFindFirstArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first User that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindFirstOrThrowArgs} args - Arguments to find a User
     * @example
     * // Get one User
     * const user = await prisma.user.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends UserFindFirstOrThrowArgs>(args?: SelectSubset<T, UserFindFirstOrThrowArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Users that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Users
     * const users = await prisma.user.findMany()
     * 
     * // Get first 10 Users
     * const users = await prisma.user.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const userWithIdOnly = await prisma.user.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends UserFindManyArgs>(args?: SelectSubset<T, UserFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a User.
     * @param {UserCreateArgs} args - Arguments to create a User.
     * @example
     * // Create one User
     * const User = await prisma.user.create({
     *   data: {
     *     // ... data to create a User
     *   }
     * })
     * 
     */
    create<T extends UserCreateArgs>(args: SelectSubset<T, UserCreateArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Users.
     * @param {UserCreateManyArgs} args - Arguments to create many Users.
     * @example
     * // Create many Users
     * const user = await prisma.user.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends UserCreateManyArgs>(args?: SelectSubset<T, UserCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Users and returns the data saved in the database.
     * @param {UserCreateManyAndReturnArgs} args - Arguments to create many Users.
     * @example
     * // Create many Users
     * const user = await prisma.user.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Users and only return the `id`
     * const userWithIdOnly = await prisma.user.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends UserCreateManyAndReturnArgs>(args?: SelectSubset<T, UserCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a User.
     * @param {UserDeleteArgs} args - Arguments to delete one User.
     * @example
     * // Delete one User
     * const User = await prisma.user.delete({
     *   where: {
     *     // ... filter to delete one User
     *   }
     * })
     * 
     */
    delete<T extends UserDeleteArgs>(args: SelectSubset<T, UserDeleteArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one User.
     * @param {UserUpdateArgs} args - Arguments to update one User.
     * @example
     * // Update one User
     * const user = await prisma.user.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends UserUpdateArgs>(args: SelectSubset<T, UserUpdateArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Users.
     * @param {UserDeleteManyArgs} args - Arguments to filter Users to delete.
     * @example
     * // Delete a few Users
     * const { count } = await prisma.user.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends UserDeleteManyArgs>(args?: SelectSubset<T, UserDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Users
     * const user = await prisma.user.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends UserUpdateManyArgs>(args: SelectSubset<T, UserUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Users and returns the data updated in the database.
     * @param {UserUpdateManyAndReturnArgs} args - Arguments to update many Users.
     * @example
     * // Update many Users
     * const user = await prisma.user.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Users and only return the `id`
     * const userWithIdOnly = await prisma.user.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends UserUpdateManyAndReturnArgs>(args: SelectSubset<T, UserUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one User.
     * @param {UserUpsertArgs} args - Arguments to update or create a User.
     * @example
     * // Update or create a User
     * const user = await prisma.user.upsert({
     *   create: {
     *     // ... data to create a User
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the User we want to update
     *   }
     * })
     */
    upsert<T extends UserUpsertArgs>(args: SelectSubset<T, UserUpsertArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Users.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserCountArgs} args - Arguments to filter Users to count.
     * @example
     * // Count the number of Users
     * const count = await prisma.user.count({
     *   where: {
     *     // ... the filter for the Users we want to count
     *   }
     * })
    **/
    count<T extends UserCountArgs>(
      args?: Subset<T, UserCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], UserCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a User.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends UserAggregateArgs>(args: Subset<T, UserAggregateArgs>): Prisma.PrismaPromise<GetUserAggregateType<T>>

    /**
     * Group by User.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {UserGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends UserGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: UserGroupByArgs['orderBy'] }
        : { orderBy?: UserGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, UserGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetUserGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the User model
   */
  readonly fields: UserFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for User.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__UserClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    contacts<T extends User$contactsArgs<ExtArgs> = {}>(args?: Subset<T, User$contactsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ContactPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    messages<T extends User$messagesArgs<ExtArgs> = {}>(args?: Subset<T, User$messagesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MessagePayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    arrangements<T extends User$arrangementsArgs<ExtArgs> = {}>(args?: Subset<T, User$arrangementsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ArrangementPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    timelineItems<T extends User$timelineItemsArgs<ExtArgs> = {}>(args?: Subset<T, User$timelineItemsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TimelineItemPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    vaultItems<T extends User$vaultItemsArgs<ExtArgs> = {}>(args?: Subset<T, User$vaultItemsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$VaultItemPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    executor<T extends User$executorArgs<ExtArgs> = {}>(args?: Subset<T, User$executorArgs<ExtArgs>>): Prisma__ExecutorClient<$Result.GetResult<Prisma.$ExecutorPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    photos<T extends User$photosArgs<ExtArgs> = {}>(args?: Subset<T, User$photosArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PhotoPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    settings<T extends User$settingsArgs<ExtArgs> = {}>(args?: Subset<T, User$settingsArgs<ExtArgs>>): Prisma__SettingsClient<$Result.GetResult<Prisma.$SettingsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    messageInvites<T extends User$messageInvitesArgs<ExtArgs> = {}>(args?: Subset<T, User$messageInvitesArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MessageInvitePayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    contributions<T extends User$contributionsArgs<ExtArgs> = {}>(args?: Subset<T, User$contributionsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ContributionPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the User model
   */
  interface UserFieldRefs {
    readonly id: FieldRef<"User", 'String'>
    readonly email: FieldRef<"User", 'String'>
    readonly name: FieldRef<"User", 'String'>
    readonly plan: FieldRef<"User", 'String'>
    readonly pendingDeathVerificationAt: FieldRef<"User", 'DateTime'>
    readonly deceasedAt: FieldRef<"User", 'DateTime'>
    readonly createdAt: FieldRef<"User", 'DateTime'>
    readonly updatedAt: FieldRef<"User", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * User findUnique
   */
  export type UserFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User findUniqueOrThrow
   */
  export type UserFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User findFirst
   */
  export type UserFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Users.
     */
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User findFirstOrThrow
   */
  export type UserFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which User to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Users.
     */
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User findMany
   */
  export type UserFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter, which Users to fetch.
     */
    where?: UserWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Users to fetch.
     */
    orderBy?: UserOrderByWithRelationInput | UserOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Users.
     */
    cursor?: UserWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Users from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Users.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Users.
     */
    distinct?: UserScalarFieldEnum | UserScalarFieldEnum[]
  }

  /**
   * User create
   */
  export type UserCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The data needed to create a User.
     */
    data: XOR<UserCreateInput, UserUncheckedCreateInput>
  }

  /**
   * User createMany
   */
  export type UserCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Users.
     */
    data: UserCreateManyInput | UserCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * User createManyAndReturn
   */
  export type UserCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * The data used to create many Users.
     */
    data: UserCreateManyInput | UserCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * User update
   */
  export type UserUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The data needed to update a User.
     */
    data: XOR<UserUpdateInput, UserUncheckedUpdateInput>
    /**
     * Choose, which User to update.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User updateMany
   */
  export type UserUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Users.
     */
    data: XOR<UserUpdateManyMutationInput, UserUncheckedUpdateManyInput>
    /**
     * Filter which Users to update
     */
    where?: UserWhereInput
    /**
     * Limit how many Users to update.
     */
    limit?: number
  }

  /**
   * User updateManyAndReturn
   */
  export type UserUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * The data used to update Users.
     */
    data: XOR<UserUpdateManyMutationInput, UserUncheckedUpdateManyInput>
    /**
     * Filter which Users to update
     */
    where?: UserWhereInput
    /**
     * Limit how many Users to update.
     */
    limit?: number
  }

  /**
   * User upsert
   */
  export type UserUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * The filter to search for the User to update in case it exists.
     */
    where: UserWhereUniqueInput
    /**
     * In case the User found by the `where` argument doesn't exist, create a new User with this data.
     */
    create: XOR<UserCreateInput, UserUncheckedCreateInput>
    /**
     * In case the User was found with the provided `where` argument, update it with this data.
     */
    update: XOR<UserUpdateInput, UserUncheckedUpdateInput>
  }

  /**
   * User delete
   */
  export type UserDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
    /**
     * Filter which User to delete.
     */
    where: UserWhereUniqueInput
  }

  /**
   * User deleteMany
   */
  export type UserDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Users to delete
     */
    where?: UserWhereInput
    /**
     * Limit how many Users to delete.
     */
    limit?: number
  }

  /**
   * User.contacts
   */
  export type User$contactsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Contact
     */
    select?: ContactSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Contact
     */
    omit?: ContactOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ContactInclude<ExtArgs> | null
    where?: ContactWhereInput
    orderBy?: ContactOrderByWithRelationInput | ContactOrderByWithRelationInput[]
    cursor?: ContactWhereUniqueInput
    take?: number
    skip?: number
    distinct?: ContactScalarFieldEnum | ContactScalarFieldEnum[]
  }

  /**
   * User.messages
   */
  export type User$messagesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Message
     */
    select?: MessageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Message
     */
    omit?: MessageOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageInclude<ExtArgs> | null
    where?: MessageWhereInput
    orderBy?: MessageOrderByWithRelationInput | MessageOrderByWithRelationInput[]
    cursor?: MessageWhereUniqueInput
    take?: number
    skip?: number
    distinct?: MessageScalarFieldEnum | MessageScalarFieldEnum[]
  }

  /**
   * User.arrangements
   */
  export type User$arrangementsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Arrangement
     */
    select?: ArrangementSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Arrangement
     */
    omit?: ArrangementOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ArrangementInclude<ExtArgs> | null
    where?: ArrangementWhereInput
    orderBy?: ArrangementOrderByWithRelationInput | ArrangementOrderByWithRelationInput[]
    cursor?: ArrangementWhereUniqueInput
    take?: number
    skip?: number
    distinct?: ArrangementScalarFieldEnum | ArrangementScalarFieldEnum[]
  }

  /**
   * User.timelineItems
   */
  export type User$timelineItemsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TimelineItem
     */
    select?: TimelineItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TimelineItem
     */
    omit?: TimelineItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TimelineItemInclude<ExtArgs> | null
    where?: TimelineItemWhereInput
    orderBy?: TimelineItemOrderByWithRelationInput | TimelineItemOrderByWithRelationInput[]
    cursor?: TimelineItemWhereUniqueInput
    take?: number
    skip?: number
    distinct?: TimelineItemScalarFieldEnum | TimelineItemScalarFieldEnum[]
  }

  /**
   * User.vaultItems
   */
  export type User$vaultItemsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VaultItem
     */
    select?: VaultItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VaultItem
     */
    omit?: VaultItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VaultItemInclude<ExtArgs> | null
    where?: VaultItemWhereInput
    orderBy?: VaultItemOrderByWithRelationInput | VaultItemOrderByWithRelationInput[]
    cursor?: VaultItemWhereUniqueInput
    take?: number
    skip?: number
    distinct?: VaultItemScalarFieldEnum | VaultItemScalarFieldEnum[]
  }

  /**
   * User.executor
   */
  export type User$executorArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Executor
     */
    select?: ExecutorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Executor
     */
    omit?: ExecutorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExecutorInclude<ExtArgs> | null
    where?: ExecutorWhereInput
  }

  /**
   * User.photos
   */
  export type User$photosArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Photo
     */
    select?: PhotoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Photo
     */
    omit?: PhotoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PhotoInclude<ExtArgs> | null
    where?: PhotoWhereInput
    orderBy?: PhotoOrderByWithRelationInput | PhotoOrderByWithRelationInput[]
    cursor?: PhotoWhereUniqueInput
    take?: number
    skip?: number
    distinct?: PhotoScalarFieldEnum | PhotoScalarFieldEnum[]
  }

  /**
   * User.settings
   */
  export type User$settingsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Settings
     */
    select?: SettingsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Settings
     */
    omit?: SettingsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SettingsInclude<ExtArgs> | null
    where?: SettingsWhereInput
  }

  /**
   * User.messageInvites
   */
  export type User$messageInvitesArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MessageInvite
     */
    select?: MessageInviteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MessageInvite
     */
    omit?: MessageInviteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageInviteInclude<ExtArgs> | null
    where?: MessageInviteWhereInput
    orderBy?: MessageInviteOrderByWithRelationInput | MessageInviteOrderByWithRelationInput[]
    cursor?: MessageInviteWhereUniqueInput
    take?: number
    skip?: number
    distinct?: MessageInviteScalarFieldEnum | MessageInviteScalarFieldEnum[]
  }

  /**
   * User.contributions
   */
  export type User$contributionsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Contribution
     */
    select?: ContributionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Contribution
     */
    omit?: ContributionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ContributionInclude<ExtArgs> | null
    where?: ContributionWhereInput
    orderBy?: ContributionOrderByWithRelationInput | ContributionOrderByWithRelationInput[]
    cursor?: ContributionWhereUniqueInput
    take?: number
    skip?: number
    distinct?: ContributionScalarFieldEnum | ContributionScalarFieldEnum[]
  }

  /**
   * User without action
   */
  export type UserDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the User
     */
    select?: UserSelect<ExtArgs> | null
    /**
     * Omit specific fields from the User
     */
    omit?: UserOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: UserInclude<ExtArgs> | null
  }


  /**
   * Model Contact
   */

  export type AggregateContact = {
    _count: ContactCountAggregateOutputType | null
    _min: ContactMinAggregateOutputType | null
    _max: ContactMaxAggregateOutputType | null
  }

  export type ContactMinAggregateOutputType = {
    id: string | null
    userId: string | null
    name: string | null
    email: string | null
    phone: string | null
    relationship: string | null
    isExecutor: boolean | null
    isBackup: boolean | null
    createdAt: Date | null
  }

  export type ContactMaxAggregateOutputType = {
    id: string | null
    userId: string | null
    name: string | null
    email: string | null
    phone: string | null
    relationship: string | null
    isExecutor: boolean | null
    isBackup: boolean | null
    createdAt: Date | null
  }

  export type ContactCountAggregateOutputType = {
    id: number
    userId: number
    name: number
    email: number
    phone: number
    relationship: number
    isExecutor: number
    isBackup: number
    createdAt: number
    _all: number
  }


  export type ContactMinAggregateInputType = {
    id?: true
    userId?: true
    name?: true
    email?: true
    phone?: true
    relationship?: true
    isExecutor?: true
    isBackup?: true
    createdAt?: true
  }

  export type ContactMaxAggregateInputType = {
    id?: true
    userId?: true
    name?: true
    email?: true
    phone?: true
    relationship?: true
    isExecutor?: true
    isBackup?: true
    createdAt?: true
  }

  export type ContactCountAggregateInputType = {
    id?: true
    userId?: true
    name?: true
    email?: true
    phone?: true
    relationship?: true
    isExecutor?: true
    isBackup?: true
    createdAt?: true
    _all?: true
  }

  export type ContactAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Contact to aggregate.
     */
    where?: ContactWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Contacts to fetch.
     */
    orderBy?: ContactOrderByWithRelationInput | ContactOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: ContactWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Contacts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Contacts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Contacts
    **/
    _count?: true | ContactCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: ContactMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: ContactMaxAggregateInputType
  }

  export type GetContactAggregateType<T extends ContactAggregateArgs> = {
        [P in keyof T & keyof AggregateContact]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateContact[P]>
      : GetScalarType<T[P], AggregateContact[P]>
  }




  export type ContactGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ContactWhereInput
    orderBy?: ContactOrderByWithAggregationInput | ContactOrderByWithAggregationInput[]
    by: ContactScalarFieldEnum[] | ContactScalarFieldEnum
    having?: ContactScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: ContactCountAggregateInputType | true
    _min?: ContactMinAggregateInputType
    _max?: ContactMaxAggregateInputType
  }

  export type ContactGroupByOutputType = {
    id: string
    userId: string
    name: string
    email: string | null
    phone: string | null
    relationship: string | null
    isExecutor: boolean
    isBackup: boolean
    createdAt: Date
    _count: ContactCountAggregateOutputType | null
    _min: ContactMinAggregateOutputType | null
    _max: ContactMaxAggregateOutputType | null
  }

  type GetContactGroupByPayload<T extends ContactGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<ContactGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof ContactGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], ContactGroupByOutputType[P]>
            : GetScalarType<T[P], ContactGroupByOutputType[P]>
        }
      >
    >


  export type ContactSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    name?: boolean
    email?: boolean
    phone?: boolean
    relationship?: boolean
    isExecutor?: boolean
    isBackup?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["contact"]>

  export type ContactSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    name?: boolean
    email?: boolean
    phone?: boolean
    relationship?: boolean
    isExecutor?: boolean
    isBackup?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["contact"]>

  export type ContactSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    name?: boolean
    email?: boolean
    phone?: boolean
    relationship?: boolean
    isExecutor?: boolean
    isBackup?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["contact"]>

  export type ContactSelectScalar = {
    id?: boolean
    userId?: boolean
    name?: boolean
    email?: boolean
    phone?: boolean
    relationship?: boolean
    isExecutor?: boolean
    isBackup?: boolean
    createdAt?: boolean
  }

  export type ContactOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "userId" | "name" | "email" | "phone" | "relationship" | "isExecutor" | "isBackup" | "createdAt", ExtArgs["result"]["contact"]>
  export type ContactInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }
  export type ContactIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }
  export type ContactIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }

  export type $ContactPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Contact"
    objects: {
      user: Prisma.$UserPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      userId: string
      name: string
      email: string | null
      phone: string | null
      relationship: string | null
      isExecutor: boolean
      isBackup: boolean
      createdAt: Date
    }, ExtArgs["result"]["contact"]>
    composites: {}
  }

  type ContactGetPayload<S extends boolean | null | undefined | ContactDefaultArgs> = $Result.GetResult<Prisma.$ContactPayload, S>

  type ContactCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<ContactFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: ContactCountAggregateInputType | true
    }

  export interface ContactDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Contact'], meta: { name: 'Contact' } }
    /**
     * Find zero or one Contact that matches the filter.
     * @param {ContactFindUniqueArgs} args - Arguments to find a Contact
     * @example
     * // Get one Contact
     * const contact = await prisma.contact.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends ContactFindUniqueArgs>(args: SelectSubset<T, ContactFindUniqueArgs<ExtArgs>>): Prisma__ContactClient<$Result.GetResult<Prisma.$ContactPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Contact that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {ContactFindUniqueOrThrowArgs} args - Arguments to find a Contact
     * @example
     * // Get one Contact
     * const contact = await prisma.contact.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends ContactFindUniqueOrThrowArgs>(args: SelectSubset<T, ContactFindUniqueOrThrowArgs<ExtArgs>>): Prisma__ContactClient<$Result.GetResult<Prisma.$ContactPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Contact that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ContactFindFirstArgs} args - Arguments to find a Contact
     * @example
     * // Get one Contact
     * const contact = await prisma.contact.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends ContactFindFirstArgs>(args?: SelectSubset<T, ContactFindFirstArgs<ExtArgs>>): Prisma__ContactClient<$Result.GetResult<Prisma.$ContactPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Contact that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ContactFindFirstOrThrowArgs} args - Arguments to find a Contact
     * @example
     * // Get one Contact
     * const contact = await prisma.contact.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends ContactFindFirstOrThrowArgs>(args?: SelectSubset<T, ContactFindFirstOrThrowArgs<ExtArgs>>): Prisma__ContactClient<$Result.GetResult<Prisma.$ContactPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Contacts that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ContactFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Contacts
     * const contacts = await prisma.contact.findMany()
     * 
     * // Get first 10 Contacts
     * const contacts = await prisma.contact.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const contactWithIdOnly = await prisma.contact.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends ContactFindManyArgs>(args?: SelectSubset<T, ContactFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ContactPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Contact.
     * @param {ContactCreateArgs} args - Arguments to create a Contact.
     * @example
     * // Create one Contact
     * const Contact = await prisma.contact.create({
     *   data: {
     *     // ... data to create a Contact
     *   }
     * })
     * 
     */
    create<T extends ContactCreateArgs>(args: SelectSubset<T, ContactCreateArgs<ExtArgs>>): Prisma__ContactClient<$Result.GetResult<Prisma.$ContactPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Contacts.
     * @param {ContactCreateManyArgs} args - Arguments to create many Contacts.
     * @example
     * // Create many Contacts
     * const contact = await prisma.contact.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends ContactCreateManyArgs>(args?: SelectSubset<T, ContactCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Contacts and returns the data saved in the database.
     * @param {ContactCreateManyAndReturnArgs} args - Arguments to create many Contacts.
     * @example
     * // Create many Contacts
     * const contact = await prisma.contact.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Contacts and only return the `id`
     * const contactWithIdOnly = await prisma.contact.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends ContactCreateManyAndReturnArgs>(args?: SelectSubset<T, ContactCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ContactPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Contact.
     * @param {ContactDeleteArgs} args - Arguments to delete one Contact.
     * @example
     * // Delete one Contact
     * const Contact = await prisma.contact.delete({
     *   where: {
     *     // ... filter to delete one Contact
     *   }
     * })
     * 
     */
    delete<T extends ContactDeleteArgs>(args: SelectSubset<T, ContactDeleteArgs<ExtArgs>>): Prisma__ContactClient<$Result.GetResult<Prisma.$ContactPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Contact.
     * @param {ContactUpdateArgs} args - Arguments to update one Contact.
     * @example
     * // Update one Contact
     * const contact = await prisma.contact.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends ContactUpdateArgs>(args: SelectSubset<T, ContactUpdateArgs<ExtArgs>>): Prisma__ContactClient<$Result.GetResult<Prisma.$ContactPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Contacts.
     * @param {ContactDeleteManyArgs} args - Arguments to filter Contacts to delete.
     * @example
     * // Delete a few Contacts
     * const { count } = await prisma.contact.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends ContactDeleteManyArgs>(args?: SelectSubset<T, ContactDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Contacts.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ContactUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Contacts
     * const contact = await prisma.contact.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends ContactUpdateManyArgs>(args: SelectSubset<T, ContactUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Contacts and returns the data updated in the database.
     * @param {ContactUpdateManyAndReturnArgs} args - Arguments to update many Contacts.
     * @example
     * // Update many Contacts
     * const contact = await prisma.contact.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Contacts and only return the `id`
     * const contactWithIdOnly = await prisma.contact.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends ContactUpdateManyAndReturnArgs>(args: SelectSubset<T, ContactUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ContactPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Contact.
     * @param {ContactUpsertArgs} args - Arguments to update or create a Contact.
     * @example
     * // Update or create a Contact
     * const contact = await prisma.contact.upsert({
     *   create: {
     *     // ... data to create a Contact
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Contact we want to update
     *   }
     * })
     */
    upsert<T extends ContactUpsertArgs>(args: SelectSubset<T, ContactUpsertArgs<ExtArgs>>): Prisma__ContactClient<$Result.GetResult<Prisma.$ContactPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Contacts.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ContactCountArgs} args - Arguments to filter Contacts to count.
     * @example
     * // Count the number of Contacts
     * const count = await prisma.contact.count({
     *   where: {
     *     // ... the filter for the Contacts we want to count
     *   }
     * })
    **/
    count<T extends ContactCountArgs>(
      args?: Subset<T, ContactCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], ContactCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Contact.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ContactAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ContactAggregateArgs>(args: Subset<T, ContactAggregateArgs>): Prisma.PrismaPromise<GetContactAggregateType<T>>

    /**
     * Group by Contact.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ContactGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends ContactGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: ContactGroupByArgs['orderBy'] }
        : { orderBy?: ContactGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, ContactGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetContactGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Contact model
   */
  readonly fields: ContactFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Contact.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__ContactClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Contact model
   */
  interface ContactFieldRefs {
    readonly id: FieldRef<"Contact", 'String'>
    readonly userId: FieldRef<"Contact", 'String'>
    readonly name: FieldRef<"Contact", 'String'>
    readonly email: FieldRef<"Contact", 'String'>
    readonly phone: FieldRef<"Contact", 'String'>
    readonly relationship: FieldRef<"Contact", 'String'>
    readonly isExecutor: FieldRef<"Contact", 'Boolean'>
    readonly isBackup: FieldRef<"Contact", 'Boolean'>
    readonly createdAt: FieldRef<"Contact", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Contact findUnique
   */
  export type ContactFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Contact
     */
    select?: ContactSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Contact
     */
    omit?: ContactOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ContactInclude<ExtArgs> | null
    /**
     * Filter, which Contact to fetch.
     */
    where: ContactWhereUniqueInput
  }

  /**
   * Contact findUniqueOrThrow
   */
  export type ContactFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Contact
     */
    select?: ContactSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Contact
     */
    omit?: ContactOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ContactInclude<ExtArgs> | null
    /**
     * Filter, which Contact to fetch.
     */
    where: ContactWhereUniqueInput
  }

  /**
   * Contact findFirst
   */
  export type ContactFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Contact
     */
    select?: ContactSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Contact
     */
    omit?: ContactOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ContactInclude<ExtArgs> | null
    /**
     * Filter, which Contact to fetch.
     */
    where?: ContactWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Contacts to fetch.
     */
    orderBy?: ContactOrderByWithRelationInput | ContactOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Contacts.
     */
    cursor?: ContactWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Contacts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Contacts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Contacts.
     */
    distinct?: ContactScalarFieldEnum | ContactScalarFieldEnum[]
  }

  /**
   * Contact findFirstOrThrow
   */
  export type ContactFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Contact
     */
    select?: ContactSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Contact
     */
    omit?: ContactOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ContactInclude<ExtArgs> | null
    /**
     * Filter, which Contact to fetch.
     */
    where?: ContactWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Contacts to fetch.
     */
    orderBy?: ContactOrderByWithRelationInput | ContactOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Contacts.
     */
    cursor?: ContactWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Contacts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Contacts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Contacts.
     */
    distinct?: ContactScalarFieldEnum | ContactScalarFieldEnum[]
  }

  /**
   * Contact findMany
   */
  export type ContactFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Contact
     */
    select?: ContactSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Contact
     */
    omit?: ContactOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ContactInclude<ExtArgs> | null
    /**
     * Filter, which Contacts to fetch.
     */
    where?: ContactWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Contacts to fetch.
     */
    orderBy?: ContactOrderByWithRelationInput | ContactOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Contacts.
     */
    cursor?: ContactWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Contacts from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Contacts.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Contacts.
     */
    distinct?: ContactScalarFieldEnum | ContactScalarFieldEnum[]
  }

  /**
   * Contact create
   */
  export type ContactCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Contact
     */
    select?: ContactSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Contact
     */
    omit?: ContactOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ContactInclude<ExtArgs> | null
    /**
     * The data needed to create a Contact.
     */
    data: XOR<ContactCreateInput, ContactUncheckedCreateInput>
  }

  /**
   * Contact createMany
   */
  export type ContactCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Contacts.
     */
    data: ContactCreateManyInput | ContactCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Contact createManyAndReturn
   */
  export type ContactCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Contact
     */
    select?: ContactSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Contact
     */
    omit?: ContactOmit<ExtArgs> | null
    /**
     * The data used to create many Contacts.
     */
    data: ContactCreateManyInput | ContactCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ContactIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * Contact update
   */
  export type ContactUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Contact
     */
    select?: ContactSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Contact
     */
    omit?: ContactOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ContactInclude<ExtArgs> | null
    /**
     * The data needed to update a Contact.
     */
    data: XOR<ContactUpdateInput, ContactUncheckedUpdateInput>
    /**
     * Choose, which Contact to update.
     */
    where: ContactWhereUniqueInput
  }

  /**
   * Contact updateMany
   */
  export type ContactUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Contacts.
     */
    data: XOR<ContactUpdateManyMutationInput, ContactUncheckedUpdateManyInput>
    /**
     * Filter which Contacts to update
     */
    where?: ContactWhereInput
    /**
     * Limit how many Contacts to update.
     */
    limit?: number
  }

  /**
   * Contact updateManyAndReturn
   */
  export type ContactUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Contact
     */
    select?: ContactSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Contact
     */
    omit?: ContactOmit<ExtArgs> | null
    /**
     * The data used to update Contacts.
     */
    data: XOR<ContactUpdateManyMutationInput, ContactUncheckedUpdateManyInput>
    /**
     * Filter which Contacts to update
     */
    where?: ContactWhereInput
    /**
     * Limit how many Contacts to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ContactIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * Contact upsert
   */
  export type ContactUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Contact
     */
    select?: ContactSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Contact
     */
    omit?: ContactOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ContactInclude<ExtArgs> | null
    /**
     * The filter to search for the Contact to update in case it exists.
     */
    where: ContactWhereUniqueInput
    /**
     * In case the Contact found by the `where` argument doesn't exist, create a new Contact with this data.
     */
    create: XOR<ContactCreateInput, ContactUncheckedCreateInput>
    /**
     * In case the Contact was found with the provided `where` argument, update it with this data.
     */
    update: XOR<ContactUpdateInput, ContactUncheckedUpdateInput>
  }

  /**
   * Contact delete
   */
  export type ContactDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Contact
     */
    select?: ContactSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Contact
     */
    omit?: ContactOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ContactInclude<ExtArgs> | null
    /**
     * Filter which Contact to delete.
     */
    where: ContactWhereUniqueInput
  }

  /**
   * Contact deleteMany
   */
  export type ContactDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Contacts to delete
     */
    where?: ContactWhereInput
    /**
     * Limit how many Contacts to delete.
     */
    limit?: number
  }

  /**
   * Contact without action
   */
  export type ContactDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Contact
     */
    select?: ContactSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Contact
     */
    omit?: ContactOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ContactInclude<ExtArgs> | null
  }


  /**
   * Model Message
   */

  export type AggregateMessage = {
    _count: MessageCountAggregateOutputType | null
    _avg: MessageAvgAggregateOutputType | null
    _sum: MessageSumAggregateOutputType | null
    _min: MessageMinAggregateOutputType | null
    _max: MessageMaxAggregateOutputType | null
  }

  export type MessageAvgAggregateOutputType = {
    mediaDurationSec: number | null
    approvalRemindersSent: number | null
  }

  export type MessageSumAggregateOutputType = {
    mediaDurationSec: number | null
    approvalRemindersSent: number | null
  }

  export type MessageMinAggregateOutputType = {
    id: string | null
    userId: string | null
    recipientName: string | null
    recipientEmail: string | null
    type: string | null
    subject: string | null
    content: string | null
    mediaUrl: string | null
    mediaBlobPath: string | null
    mediaDurationSec: number | null
    triggerDate: Date | null
    state: string | null
    approvalPromptedAt: Date | null
    approvalExpiresAt: Date | null
    sentAt: Date | null
    archivedAt: Date | null
    deliveryToken: string | null
    approvalToken: string | null
    approvalRemindersSent: number | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type MessageMaxAggregateOutputType = {
    id: string | null
    userId: string | null
    recipientName: string | null
    recipientEmail: string | null
    type: string | null
    subject: string | null
    content: string | null
    mediaUrl: string | null
    mediaBlobPath: string | null
    mediaDurationSec: number | null
    triggerDate: Date | null
    state: string | null
    approvalPromptedAt: Date | null
    approvalExpiresAt: Date | null
    sentAt: Date | null
    archivedAt: Date | null
    deliveryToken: string | null
    approvalToken: string | null
    approvalRemindersSent: number | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type MessageCountAggregateOutputType = {
    id: number
    userId: number
    recipientName: number
    recipientEmail: number
    type: number
    subject: number
    content: number
    mediaUrl: number
    mediaBlobPath: number
    mediaDurationSec: number
    triggerDate: number
    state: number
    approvalPromptedAt: number
    approvalExpiresAt: number
    sentAt: number
    archivedAt: number
    deliveryToken: number
    approvalToken: number
    approvalRemindersSent: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type MessageAvgAggregateInputType = {
    mediaDurationSec?: true
    approvalRemindersSent?: true
  }

  export type MessageSumAggregateInputType = {
    mediaDurationSec?: true
    approvalRemindersSent?: true
  }

  export type MessageMinAggregateInputType = {
    id?: true
    userId?: true
    recipientName?: true
    recipientEmail?: true
    type?: true
    subject?: true
    content?: true
    mediaUrl?: true
    mediaBlobPath?: true
    mediaDurationSec?: true
    triggerDate?: true
    state?: true
    approvalPromptedAt?: true
    approvalExpiresAt?: true
    sentAt?: true
    archivedAt?: true
    deliveryToken?: true
    approvalToken?: true
    approvalRemindersSent?: true
    createdAt?: true
    updatedAt?: true
  }

  export type MessageMaxAggregateInputType = {
    id?: true
    userId?: true
    recipientName?: true
    recipientEmail?: true
    type?: true
    subject?: true
    content?: true
    mediaUrl?: true
    mediaBlobPath?: true
    mediaDurationSec?: true
    triggerDate?: true
    state?: true
    approvalPromptedAt?: true
    approvalExpiresAt?: true
    sentAt?: true
    archivedAt?: true
    deliveryToken?: true
    approvalToken?: true
    approvalRemindersSent?: true
    createdAt?: true
    updatedAt?: true
  }

  export type MessageCountAggregateInputType = {
    id?: true
    userId?: true
    recipientName?: true
    recipientEmail?: true
    type?: true
    subject?: true
    content?: true
    mediaUrl?: true
    mediaBlobPath?: true
    mediaDurationSec?: true
    triggerDate?: true
    state?: true
    approvalPromptedAt?: true
    approvalExpiresAt?: true
    sentAt?: true
    archivedAt?: true
    deliveryToken?: true
    approvalToken?: true
    approvalRemindersSent?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type MessageAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Message to aggregate.
     */
    where?: MessageWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Messages to fetch.
     */
    orderBy?: MessageOrderByWithRelationInput | MessageOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: MessageWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Messages from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Messages.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Messages
    **/
    _count?: true | MessageCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: MessageAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: MessageSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: MessageMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: MessageMaxAggregateInputType
  }

  export type GetMessageAggregateType<T extends MessageAggregateArgs> = {
        [P in keyof T & keyof AggregateMessage]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateMessage[P]>
      : GetScalarType<T[P], AggregateMessage[P]>
  }




  export type MessageGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: MessageWhereInput
    orderBy?: MessageOrderByWithAggregationInput | MessageOrderByWithAggregationInput[]
    by: MessageScalarFieldEnum[] | MessageScalarFieldEnum
    having?: MessageScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: MessageCountAggregateInputType | true
    _avg?: MessageAvgAggregateInputType
    _sum?: MessageSumAggregateInputType
    _min?: MessageMinAggregateInputType
    _max?: MessageMaxAggregateInputType
  }

  export type MessageGroupByOutputType = {
    id: string
    userId: string
    recipientName: string
    recipientEmail: string | null
    type: string
    subject: string | null
    content: string | null
    mediaUrl: string | null
    mediaBlobPath: string | null
    mediaDurationSec: number | null
    triggerDate: Date | null
    state: string
    approvalPromptedAt: Date | null
    approvalExpiresAt: Date | null
    sentAt: Date | null
    archivedAt: Date | null
    deliveryToken: string | null
    approvalToken: string | null
    approvalRemindersSent: number
    createdAt: Date
    updatedAt: Date
    _count: MessageCountAggregateOutputType | null
    _avg: MessageAvgAggregateOutputType | null
    _sum: MessageSumAggregateOutputType | null
    _min: MessageMinAggregateOutputType | null
    _max: MessageMaxAggregateOutputType | null
  }

  type GetMessageGroupByPayload<T extends MessageGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<MessageGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof MessageGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], MessageGroupByOutputType[P]>
            : GetScalarType<T[P], MessageGroupByOutputType[P]>
        }
      >
    >


  export type MessageSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    recipientName?: boolean
    recipientEmail?: boolean
    type?: boolean
    subject?: boolean
    content?: boolean
    mediaUrl?: boolean
    mediaBlobPath?: boolean
    mediaDurationSec?: boolean
    triggerDate?: boolean
    state?: boolean
    approvalPromptedAt?: boolean
    approvalExpiresAt?: boolean
    sentAt?: boolean
    archivedAt?: boolean
    deliveryToken?: boolean
    approvalToken?: boolean
    approvalRemindersSent?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["message"]>

  export type MessageSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    recipientName?: boolean
    recipientEmail?: boolean
    type?: boolean
    subject?: boolean
    content?: boolean
    mediaUrl?: boolean
    mediaBlobPath?: boolean
    mediaDurationSec?: boolean
    triggerDate?: boolean
    state?: boolean
    approvalPromptedAt?: boolean
    approvalExpiresAt?: boolean
    sentAt?: boolean
    archivedAt?: boolean
    deliveryToken?: boolean
    approvalToken?: boolean
    approvalRemindersSent?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["message"]>

  export type MessageSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    recipientName?: boolean
    recipientEmail?: boolean
    type?: boolean
    subject?: boolean
    content?: boolean
    mediaUrl?: boolean
    mediaBlobPath?: boolean
    mediaDurationSec?: boolean
    triggerDate?: boolean
    state?: boolean
    approvalPromptedAt?: boolean
    approvalExpiresAt?: boolean
    sentAt?: boolean
    archivedAt?: boolean
    deliveryToken?: boolean
    approvalToken?: boolean
    approvalRemindersSent?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["message"]>

  export type MessageSelectScalar = {
    id?: boolean
    userId?: boolean
    recipientName?: boolean
    recipientEmail?: boolean
    type?: boolean
    subject?: boolean
    content?: boolean
    mediaUrl?: boolean
    mediaBlobPath?: boolean
    mediaDurationSec?: boolean
    triggerDate?: boolean
    state?: boolean
    approvalPromptedAt?: boolean
    approvalExpiresAt?: boolean
    sentAt?: boolean
    archivedAt?: boolean
    deliveryToken?: boolean
    approvalToken?: boolean
    approvalRemindersSent?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type MessageOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "userId" | "recipientName" | "recipientEmail" | "type" | "subject" | "content" | "mediaUrl" | "mediaBlobPath" | "mediaDurationSec" | "triggerDate" | "state" | "approvalPromptedAt" | "approvalExpiresAt" | "sentAt" | "archivedAt" | "deliveryToken" | "approvalToken" | "approvalRemindersSent" | "createdAt" | "updatedAt", ExtArgs["result"]["message"]>
  export type MessageInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }
  export type MessageIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }
  export type MessageIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }

  export type $MessagePayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Message"
    objects: {
      user: Prisma.$UserPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      userId: string
      recipientName: string
      recipientEmail: string | null
      type: string
      subject: string | null
      content: string | null
      mediaUrl: string | null
      mediaBlobPath: string | null
      mediaDurationSec: number | null
      triggerDate: Date | null
      state: string
      approvalPromptedAt: Date | null
      approvalExpiresAt: Date | null
      sentAt: Date | null
      archivedAt: Date | null
      deliveryToken: string | null
      approvalToken: string | null
      approvalRemindersSent: number
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["message"]>
    composites: {}
  }

  type MessageGetPayload<S extends boolean | null | undefined | MessageDefaultArgs> = $Result.GetResult<Prisma.$MessagePayload, S>

  type MessageCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<MessageFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: MessageCountAggregateInputType | true
    }

  export interface MessageDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Message'], meta: { name: 'Message' } }
    /**
     * Find zero or one Message that matches the filter.
     * @param {MessageFindUniqueArgs} args - Arguments to find a Message
     * @example
     * // Get one Message
     * const message = await prisma.message.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends MessageFindUniqueArgs>(args: SelectSubset<T, MessageFindUniqueArgs<ExtArgs>>): Prisma__MessageClient<$Result.GetResult<Prisma.$MessagePayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Message that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {MessageFindUniqueOrThrowArgs} args - Arguments to find a Message
     * @example
     * // Get one Message
     * const message = await prisma.message.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends MessageFindUniqueOrThrowArgs>(args: SelectSubset<T, MessageFindUniqueOrThrowArgs<ExtArgs>>): Prisma__MessageClient<$Result.GetResult<Prisma.$MessagePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Message that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MessageFindFirstArgs} args - Arguments to find a Message
     * @example
     * // Get one Message
     * const message = await prisma.message.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends MessageFindFirstArgs>(args?: SelectSubset<T, MessageFindFirstArgs<ExtArgs>>): Prisma__MessageClient<$Result.GetResult<Prisma.$MessagePayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Message that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MessageFindFirstOrThrowArgs} args - Arguments to find a Message
     * @example
     * // Get one Message
     * const message = await prisma.message.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends MessageFindFirstOrThrowArgs>(args?: SelectSubset<T, MessageFindFirstOrThrowArgs<ExtArgs>>): Prisma__MessageClient<$Result.GetResult<Prisma.$MessagePayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Messages that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MessageFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Messages
     * const messages = await prisma.message.findMany()
     * 
     * // Get first 10 Messages
     * const messages = await prisma.message.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const messageWithIdOnly = await prisma.message.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends MessageFindManyArgs>(args?: SelectSubset<T, MessageFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MessagePayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Message.
     * @param {MessageCreateArgs} args - Arguments to create a Message.
     * @example
     * // Create one Message
     * const Message = await prisma.message.create({
     *   data: {
     *     // ... data to create a Message
     *   }
     * })
     * 
     */
    create<T extends MessageCreateArgs>(args: SelectSubset<T, MessageCreateArgs<ExtArgs>>): Prisma__MessageClient<$Result.GetResult<Prisma.$MessagePayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Messages.
     * @param {MessageCreateManyArgs} args - Arguments to create many Messages.
     * @example
     * // Create many Messages
     * const message = await prisma.message.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends MessageCreateManyArgs>(args?: SelectSubset<T, MessageCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Messages and returns the data saved in the database.
     * @param {MessageCreateManyAndReturnArgs} args - Arguments to create many Messages.
     * @example
     * // Create many Messages
     * const message = await prisma.message.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Messages and only return the `id`
     * const messageWithIdOnly = await prisma.message.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends MessageCreateManyAndReturnArgs>(args?: SelectSubset<T, MessageCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MessagePayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Message.
     * @param {MessageDeleteArgs} args - Arguments to delete one Message.
     * @example
     * // Delete one Message
     * const Message = await prisma.message.delete({
     *   where: {
     *     // ... filter to delete one Message
     *   }
     * })
     * 
     */
    delete<T extends MessageDeleteArgs>(args: SelectSubset<T, MessageDeleteArgs<ExtArgs>>): Prisma__MessageClient<$Result.GetResult<Prisma.$MessagePayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Message.
     * @param {MessageUpdateArgs} args - Arguments to update one Message.
     * @example
     * // Update one Message
     * const message = await prisma.message.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends MessageUpdateArgs>(args: SelectSubset<T, MessageUpdateArgs<ExtArgs>>): Prisma__MessageClient<$Result.GetResult<Prisma.$MessagePayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Messages.
     * @param {MessageDeleteManyArgs} args - Arguments to filter Messages to delete.
     * @example
     * // Delete a few Messages
     * const { count } = await prisma.message.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends MessageDeleteManyArgs>(args?: SelectSubset<T, MessageDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Messages.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MessageUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Messages
     * const message = await prisma.message.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends MessageUpdateManyArgs>(args: SelectSubset<T, MessageUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Messages and returns the data updated in the database.
     * @param {MessageUpdateManyAndReturnArgs} args - Arguments to update many Messages.
     * @example
     * // Update many Messages
     * const message = await prisma.message.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Messages and only return the `id`
     * const messageWithIdOnly = await prisma.message.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends MessageUpdateManyAndReturnArgs>(args: SelectSubset<T, MessageUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MessagePayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Message.
     * @param {MessageUpsertArgs} args - Arguments to update or create a Message.
     * @example
     * // Update or create a Message
     * const message = await prisma.message.upsert({
     *   create: {
     *     // ... data to create a Message
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Message we want to update
     *   }
     * })
     */
    upsert<T extends MessageUpsertArgs>(args: SelectSubset<T, MessageUpsertArgs<ExtArgs>>): Prisma__MessageClient<$Result.GetResult<Prisma.$MessagePayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Messages.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MessageCountArgs} args - Arguments to filter Messages to count.
     * @example
     * // Count the number of Messages
     * const count = await prisma.message.count({
     *   where: {
     *     // ... the filter for the Messages we want to count
     *   }
     * })
    **/
    count<T extends MessageCountArgs>(
      args?: Subset<T, MessageCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], MessageCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Message.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MessageAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends MessageAggregateArgs>(args: Subset<T, MessageAggregateArgs>): Prisma.PrismaPromise<GetMessageAggregateType<T>>

    /**
     * Group by Message.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MessageGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends MessageGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: MessageGroupByArgs['orderBy'] }
        : { orderBy?: MessageGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, MessageGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetMessageGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Message model
   */
  readonly fields: MessageFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Message.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__MessageClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Message model
   */
  interface MessageFieldRefs {
    readonly id: FieldRef<"Message", 'String'>
    readonly userId: FieldRef<"Message", 'String'>
    readonly recipientName: FieldRef<"Message", 'String'>
    readonly recipientEmail: FieldRef<"Message", 'String'>
    readonly type: FieldRef<"Message", 'String'>
    readonly subject: FieldRef<"Message", 'String'>
    readonly content: FieldRef<"Message", 'String'>
    readonly mediaUrl: FieldRef<"Message", 'String'>
    readonly mediaBlobPath: FieldRef<"Message", 'String'>
    readonly mediaDurationSec: FieldRef<"Message", 'Int'>
    readonly triggerDate: FieldRef<"Message", 'DateTime'>
    readonly state: FieldRef<"Message", 'String'>
    readonly approvalPromptedAt: FieldRef<"Message", 'DateTime'>
    readonly approvalExpiresAt: FieldRef<"Message", 'DateTime'>
    readonly sentAt: FieldRef<"Message", 'DateTime'>
    readonly archivedAt: FieldRef<"Message", 'DateTime'>
    readonly deliveryToken: FieldRef<"Message", 'String'>
    readonly approvalToken: FieldRef<"Message", 'String'>
    readonly approvalRemindersSent: FieldRef<"Message", 'Int'>
    readonly createdAt: FieldRef<"Message", 'DateTime'>
    readonly updatedAt: FieldRef<"Message", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Message findUnique
   */
  export type MessageFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Message
     */
    select?: MessageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Message
     */
    omit?: MessageOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageInclude<ExtArgs> | null
    /**
     * Filter, which Message to fetch.
     */
    where: MessageWhereUniqueInput
  }

  /**
   * Message findUniqueOrThrow
   */
  export type MessageFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Message
     */
    select?: MessageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Message
     */
    omit?: MessageOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageInclude<ExtArgs> | null
    /**
     * Filter, which Message to fetch.
     */
    where: MessageWhereUniqueInput
  }

  /**
   * Message findFirst
   */
  export type MessageFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Message
     */
    select?: MessageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Message
     */
    omit?: MessageOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageInclude<ExtArgs> | null
    /**
     * Filter, which Message to fetch.
     */
    where?: MessageWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Messages to fetch.
     */
    orderBy?: MessageOrderByWithRelationInput | MessageOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Messages.
     */
    cursor?: MessageWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Messages from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Messages.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Messages.
     */
    distinct?: MessageScalarFieldEnum | MessageScalarFieldEnum[]
  }

  /**
   * Message findFirstOrThrow
   */
  export type MessageFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Message
     */
    select?: MessageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Message
     */
    omit?: MessageOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageInclude<ExtArgs> | null
    /**
     * Filter, which Message to fetch.
     */
    where?: MessageWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Messages to fetch.
     */
    orderBy?: MessageOrderByWithRelationInput | MessageOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Messages.
     */
    cursor?: MessageWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Messages from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Messages.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Messages.
     */
    distinct?: MessageScalarFieldEnum | MessageScalarFieldEnum[]
  }

  /**
   * Message findMany
   */
  export type MessageFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Message
     */
    select?: MessageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Message
     */
    omit?: MessageOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageInclude<ExtArgs> | null
    /**
     * Filter, which Messages to fetch.
     */
    where?: MessageWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Messages to fetch.
     */
    orderBy?: MessageOrderByWithRelationInput | MessageOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Messages.
     */
    cursor?: MessageWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Messages from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Messages.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Messages.
     */
    distinct?: MessageScalarFieldEnum | MessageScalarFieldEnum[]
  }

  /**
   * Message create
   */
  export type MessageCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Message
     */
    select?: MessageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Message
     */
    omit?: MessageOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageInclude<ExtArgs> | null
    /**
     * The data needed to create a Message.
     */
    data: XOR<MessageCreateInput, MessageUncheckedCreateInput>
  }

  /**
   * Message createMany
   */
  export type MessageCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Messages.
     */
    data: MessageCreateManyInput | MessageCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Message createManyAndReturn
   */
  export type MessageCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Message
     */
    select?: MessageSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Message
     */
    omit?: MessageOmit<ExtArgs> | null
    /**
     * The data used to create many Messages.
     */
    data: MessageCreateManyInput | MessageCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * Message update
   */
  export type MessageUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Message
     */
    select?: MessageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Message
     */
    omit?: MessageOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageInclude<ExtArgs> | null
    /**
     * The data needed to update a Message.
     */
    data: XOR<MessageUpdateInput, MessageUncheckedUpdateInput>
    /**
     * Choose, which Message to update.
     */
    where: MessageWhereUniqueInput
  }

  /**
   * Message updateMany
   */
  export type MessageUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Messages.
     */
    data: XOR<MessageUpdateManyMutationInput, MessageUncheckedUpdateManyInput>
    /**
     * Filter which Messages to update
     */
    where?: MessageWhereInput
    /**
     * Limit how many Messages to update.
     */
    limit?: number
  }

  /**
   * Message updateManyAndReturn
   */
  export type MessageUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Message
     */
    select?: MessageSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Message
     */
    omit?: MessageOmit<ExtArgs> | null
    /**
     * The data used to update Messages.
     */
    data: XOR<MessageUpdateManyMutationInput, MessageUncheckedUpdateManyInput>
    /**
     * Filter which Messages to update
     */
    where?: MessageWhereInput
    /**
     * Limit how many Messages to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * Message upsert
   */
  export type MessageUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Message
     */
    select?: MessageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Message
     */
    omit?: MessageOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageInclude<ExtArgs> | null
    /**
     * The filter to search for the Message to update in case it exists.
     */
    where: MessageWhereUniqueInput
    /**
     * In case the Message found by the `where` argument doesn't exist, create a new Message with this data.
     */
    create: XOR<MessageCreateInput, MessageUncheckedCreateInput>
    /**
     * In case the Message was found with the provided `where` argument, update it with this data.
     */
    update: XOR<MessageUpdateInput, MessageUncheckedUpdateInput>
  }

  /**
   * Message delete
   */
  export type MessageDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Message
     */
    select?: MessageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Message
     */
    omit?: MessageOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageInclude<ExtArgs> | null
    /**
     * Filter which Message to delete.
     */
    where: MessageWhereUniqueInput
  }

  /**
   * Message deleteMany
   */
  export type MessageDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Messages to delete
     */
    where?: MessageWhereInput
    /**
     * Limit how many Messages to delete.
     */
    limit?: number
  }

  /**
   * Message without action
   */
  export type MessageDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Message
     */
    select?: MessageSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Message
     */
    omit?: MessageOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageInclude<ExtArgs> | null
  }


  /**
   * Model MessageInvite
   */

  export type AggregateMessageInvite = {
    _count: MessageInviteCountAggregateOutputType | null
    _avg: MessageInviteAvgAggregateOutputType | null
    _sum: MessageInviteSumAggregateOutputType | null
    _min: MessageInviteMinAggregateOutputType | null
    _max: MessageInviteMaxAggregateOutputType | null
  }

  export type MessageInviteAvgAggregateOutputType = {
    useCount: number | null
  }

  export type MessageInviteSumAggregateOutputType = {
    useCount: number | null
  }

  export type MessageInviteMinAggregateOutputType = {
    id: string | null
    userId: string | null
    token: string | null
    contributorName: string | null
    contributorEmail: string | null
    message: string | null
    expiresAt: Date | null
    revokedAt: Date | null
    lastUsedAt: Date | null
    useCount: number | null
    createdAt: Date | null
  }

  export type MessageInviteMaxAggregateOutputType = {
    id: string | null
    userId: string | null
    token: string | null
    contributorName: string | null
    contributorEmail: string | null
    message: string | null
    expiresAt: Date | null
    revokedAt: Date | null
    lastUsedAt: Date | null
    useCount: number | null
    createdAt: Date | null
  }

  export type MessageInviteCountAggregateOutputType = {
    id: number
    userId: number
    token: number
    contributorName: number
    contributorEmail: number
    message: number
    expiresAt: number
    revokedAt: number
    lastUsedAt: number
    useCount: number
    createdAt: number
    _all: number
  }


  export type MessageInviteAvgAggregateInputType = {
    useCount?: true
  }

  export type MessageInviteSumAggregateInputType = {
    useCount?: true
  }

  export type MessageInviteMinAggregateInputType = {
    id?: true
    userId?: true
    token?: true
    contributorName?: true
    contributorEmail?: true
    message?: true
    expiresAt?: true
    revokedAt?: true
    lastUsedAt?: true
    useCount?: true
    createdAt?: true
  }

  export type MessageInviteMaxAggregateInputType = {
    id?: true
    userId?: true
    token?: true
    contributorName?: true
    contributorEmail?: true
    message?: true
    expiresAt?: true
    revokedAt?: true
    lastUsedAt?: true
    useCount?: true
    createdAt?: true
  }

  export type MessageInviteCountAggregateInputType = {
    id?: true
    userId?: true
    token?: true
    contributorName?: true
    contributorEmail?: true
    message?: true
    expiresAt?: true
    revokedAt?: true
    lastUsedAt?: true
    useCount?: true
    createdAt?: true
    _all?: true
  }

  export type MessageInviteAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which MessageInvite to aggregate.
     */
    where?: MessageInviteWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MessageInvites to fetch.
     */
    orderBy?: MessageInviteOrderByWithRelationInput | MessageInviteOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: MessageInviteWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MessageInvites from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MessageInvites.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned MessageInvites
    **/
    _count?: true | MessageInviteCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: MessageInviteAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: MessageInviteSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: MessageInviteMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: MessageInviteMaxAggregateInputType
  }

  export type GetMessageInviteAggregateType<T extends MessageInviteAggregateArgs> = {
        [P in keyof T & keyof AggregateMessageInvite]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateMessageInvite[P]>
      : GetScalarType<T[P], AggregateMessageInvite[P]>
  }




  export type MessageInviteGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: MessageInviteWhereInput
    orderBy?: MessageInviteOrderByWithAggregationInput | MessageInviteOrderByWithAggregationInput[]
    by: MessageInviteScalarFieldEnum[] | MessageInviteScalarFieldEnum
    having?: MessageInviteScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: MessageInviteCountAggregateInputType | true
    _avg?: MessageInviteAvgAggregateInputType
    _sum?: MessageInviteSumAggregateInputType
    _min?: MessageInviteMinAggregateInputType
    _max?: MessageInviteMaxAggregateInputType
  }

  export type MessageInviteGroupByOutputType = {
    id: string
    userId: string
    token: string
    contributorName: string
    contributorEmail: string | null
    message: string | null
    expiresAt: Date
    revokedAt: Date | null
    lastUsedAt: Date | null
    useCount: number
    createdAt: Date
    _count: MessageInviteCountAggregateOutputType | null
    _avg: MessageInviteAvgAggregateOutputType | null
    _sum: MessageInviteSumAggregateOutputType | null
    _min: MessageInviteMinAggregateOutputType | null
    _max: MessageInviteMaxAggregateOutputType | null
  }

  type GetMessageInviteGroupByPayload<T extends MessageInviteGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<MessageInviteGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof MessageInviteGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], MessageInviteGroupByOutputType[P]>
            : GetScalarType<T[P], MessageInviteGroupByOutputType[P]>
        }
      >
    >


  export type MessageInviteSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    token?: boolean
    contributorName?: boolean
    contributorEmail?: boolean
    message?: boolean
    expiresAt?: boolean
    revokedAt?: boolean
    lastUsedAt?: boolean
    useCount?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
    contributions?: boolean | MessageInvite$contributionsArgs<ExtArgs>
    _count?: boolean | MessageInviteCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["messageInvite"]>

  export type MessageInviteSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    token?: boolean
    contributorName?: boolean
    contributorEmail?: boolean
    message?: boolean
    expiresAt?: boolean
    revokedAt?: boolean
    lastUsedAt?: boolean
    useCount?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["messageInvite"]>

  export type MessageInviteSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    token?: boolean
    contributorName?: boolean
    contributorEmail?: boolean
    message?: boolean
    expiresAt?: boolean
    revokedAt?: boolean
    lastUsedAt?: boolean
    useCount?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["messageInvite"]>

  export type MessageInviteSelectScalar = {
    id?: boolean
    userId?: boolean
    token?: boolean
    contributorName?: boolean
    contributorEmail?: boolean
    message?: boolean
    expiresAt?: boolean
    revokedAt?: boolean
    lastUsedAt?: boolean
    useCount?: boolean
    createdAt?: boolean
  }

  export type MessageInviteOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "userId" | "token" | "contributorName" | "contributorEmail" | "message" | "expiresAt" | "revokedAt" | "lastUsedAt" | "useCount" | "createdAt", ExtArgs["result"]["messageInvite"]>
  export type MessageInviteInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
    contributions?: boolean | MessageInvite$contributionsArgs<ExtArgs>
    _count?: boolean | MessageInviteCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type MessageInviteIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }
  export type MessageInviteIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }

  export type $MessageInvitePayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "MessageInvite"
    objects: {
      user: Prisma.$UserPayload<ExtArgs>
      contributions: Prisma.$ContributionPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      userId: string
      token: string
      contributorName: string
      contributorEmail: string | null
      message: string | null
      expiresAt: Date
      revokedAt: Date | null
      lastUsedAt: Date | null
      useCount: number
      createdAt: Date
    }, ExtArgs["result"]["messageInvite"]>
    composites: {}
  }

  type MessageInviteGetPayload<S extends boolean | null | undefined | MessageInviteDefaultArgs> = $Result.GetResult<Prisma.$MessageInvitePayload, S>

  type MessageInviteCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<MessageInviteFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: MessageInviteCountAggregateInputType | true
    }

  export interface MessageInviteDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['MessageInvite'], meta: { name: 'MessageInvite' } }
    /**
     * Find zero or one MessageInvite that matches the filter.
     * @param {MessageInviteFindUniqueArgs} args - Arguments to find a MessageInvite
     * @example
     * // Get one MessageInvite
     * const messageInvite = await prisma.messageInvite.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends MessageInviteFindUniqueArgs>(args: SelectSubset<T, MessageInviteFindUniqueArgs<ExtArgs>>): Prisma__MessageInviteClient<$Result.GetResult<Prisma.$MessageInvitePayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one MessageInvite that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {MessageInviteFindUniqueOrThrowArgs} args - Arguments to find a MessageInvite
     * @example
     * // Get one MessageInvite
     * const messageInvite = await prisma.messageInvite.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends MessageInviteFindUniqueOrThrowArgs>(args: SelectSubset<T, MessageInviteFindUniqueOrThrowArgs<ExtArgs>>): Prisma__MessageInviteClient<$Result.GetResult<Prisma.$MessageInvitePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first MessageInvite that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MessageInviteFindFirstArgs} args - Arguments to find a MessageInvite
     * @example
     * // Get one MessageInvite
     * const messageInvite = await prisma.messageInvite.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends MessageInviteFindFirstArgs>(args?: SelectSubset<T, MessageInviteFindFirstArgs<ExtArgs>>): Prisma__MessageInviteClient<$Result.GetResult<Prisma.$MessageInvitePayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first MessageInvite that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MessageInviteFindFirstOrThrowArgs} args - Arguments to find a MessageInvite
     * @example
     * // Get one MessageInvite
     * const messageInvite = await prisma.messageInvite.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends MessageInviteFindFirstOrThrowArgs>(args?: SelectSubset<T, MessageInviteFindFirstOrThrowArgs<ExtArgs>>): Prisma__MessageInviteClient<$Result.GetResult<Prisma.$MessageInvitePayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more MessageInvites that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MessageInviteFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all MessageInvites
     * const messageInvites = await prisma.messageInvite.findMany()
     * 
     * // Get first 10 MessageInvites
     * const messageInvites = await prisma.messageInvite.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const messageInviteWithIdOnly = await prisma.messageInvite.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends MessageInviteFindManyArgs>(args?: SelectSubset<T, MessageInviteFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MessageInvitePayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a MessageInvite.
     * @param {MessageInviteCreateArgs} args - Arguments to create a MessageInvite.
     * @example
     * // Create one MessageInvite
     * const MessageInvite = await prisma.messageInvite.create({
     *   data: {
     *     // ... data to create a MessageInvite
     *   }
     * })
     * 
     */
    create<T extends MessageInviteCreateArgs>(args: SelectSubset<T, MessageInviteCreateArgs<ExtArgs>>): Prisma__MessageInviteClient<$Result.GetResult<Prisma.$MessageInvitePayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many MessageInvites.
     * @param {MessageInviteCreateManyArgs} args - Arguments to create many MessageInvites.
     * @example
     * // Create many MessageInvites
     * const messageInvite = await prisma.messageInvite.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends MessageInviteCreateManyArgs>(args?: SelectSubset<T, MessageInviteCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many MessageInvites and returns the data saved in the database.
     * @param {MessageInviteCreateManyAndReturnArgs} args - Arguments to create many MessageInvites.
     * @example
     * // Create many MessageInvites
     * const messageInvite = await prisma.messageInvite.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many MessageInvites and only return the `id`
     * const messageInviteWithIdOnly = await prisma.messageInvite.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends MessageInviteCreateManyAndReturnArgs>(args?: SelectSubset<T, MessageInviteCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MessageInvitePayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a MessageInvite.
     * @param {MessageInviteDeleteArgs} args - Arguments to delete one MessageInvite.
     * @example
     * // Delete one MessageInvite
     * const MessageInvite = await prisma.messageInvite.delete({
     *   where: {
     *     // ... filter to delete one MessageInvite
     *   }
     * })
     * 
     */
    delete<T extends MessageInviteDeleteArgs>(args: SelectSubset<T, MessageInviteDeleteArgs<ExtArgs>>): Prisma__MessageInviteClient<$Result.GetResult<Prisma.$MessageInvitePayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one MessageInvite.
     * @param {MessageInviteUpdateArgs} args - Arguments to update one MessageInvite.
     * @example
     * // Update one MessageInvite
     * const messageInvite = await prisma.messageInvite.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends MessageInviteUpdateArgs>(args: SelectSubset<T, MessageInviteUpdateArgs<ExtArgs>>): Prisma__MessageInviteClient<$Result.GetResult<Prisma.$MessageInvitePayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more MessageInvites.
     * @param {MessageInviteDeleteManyArgs} args - Arguments to filter MessageInvites to delete.
     * @example
     * // Delete a few MessageInvites
     * const { count } = await prisma.messageInvite.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends MessageInviteDeleteManyArgs>(args?: SelectSubset<T, MessageInviteDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more MessageInvites.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MessageInviteUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many MessageInvites
     * const messageInvite = await prisma.messageInvite.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends MessageInviteUpdateManyArgs>(args: SelectSubset<T, MessageInviteUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more MessageInvites and returns the data updated in the database.
     * @param {MessageInviteUpdateManyAndReturnArgs} args - Arguments to update many MessageInvites.
     * @example
     * // Update many MessageInvites
     * const messageInvite = await prisma.messageInvite.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more MessageInvites and only return the `id`
     * const messageInviteWithIdOnly = await prisma.messageInvite.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends MessageInviteUpdateManyAndReturnArgs>(args: SelectSubset<T, MessageInviteUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$MessageInvitePayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one MessageInvite.
     * @param {MessageInviteUpsertArgs} args - Arguments to update or create a MessageInvite.
     * @example
     * // Update or create a MessageInvite
     * const messageInvite = await prisma.messageInvite.upsert({
     *   create: {
     *     // ... data to create a MessageInvite
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the MessageInvite we want to update
     *   }
     * })
     */
    upsert<T extends MessageInviteUpsertArgs>(args: SelectSubset<T, MessageInviteUpsertArgs<ExtArgs>>): Prisma__MessageInviteClient<$Result.GetResult<Prisma.$MessageInvitePayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of MessageInvites.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MessageInviteCountArgs} args - Arguments to filter MessageInvites to count.
     * @example
     * // Count the number of MessageInvites
     * const count = await prisma.messageInvite.count({
     *   where: {
     *     // ... the filter for the MessageInvites we want to count
     *   }
     * })
    **/
    count<T extends MessageInviteCountArgs>(
      args?: Subset<T, MessageInviteCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], MessageInviteCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a MessageInvite.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MessageInviteAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends MessageInviteAggregateArgs>(args: Subset<T, MessageInviteAggregateArgs>): Prisma.PrismaPromise<GetMessageInviteAggregateType<T>>

    /**
     * Group by MessageInvite.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {MessageInviteGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends MessageInviteGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: MessageInviteGroupByArgs['orderBy'] }
        : { orderBy?: MessageInviteGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, MessageInviteGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetMessageInviteGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the MessageInvite model
   */
  readonly fields: MessageInviteFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for MessageInvite.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__MessageInviteClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    contributions<T extends MessageInvite$contributionsArgs<ExtArgs> = {}>(args?: Subset<T, MessageInvite$contributionsArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ContributionPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the MessageInvite model
   */
  interface MessageInviteFieldRefs {
    readonly id: FieldRef<"MessageInvite", 'String'>
    readonly userId: FieldRef<"MessageInvite", 'String'>
    readonly token: FieldRef<"MessageInvite", 'String'>
    readonly contributorName: FieldRef<"MessageInvite", 'String'>
    readonly contributorEmail: FieldRef<"MessageInvite", 'String'>
    readonly message: FieldRef<"MessageInvite", 'String'>
    readonly expiresAt: FieldRef<"MessageInvite", 'DateTime'>
    readonly revokedAt: FieldRef<"MessageInvite", 'DateTime'>
    readonly lastUsedAt: FieldRef<"MessageInvite", 'DateTime'>
    readonly useCount: FieldRef<"MessageInvite", 'Int'>
    readonly createdAt: FieldRef<"MessageInvite", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * MessageInvite findUnique
   */
  export type MessageInviteFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MessageInvite
     */
    select?: MessageInviteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MessageInvite
     */
    omit?: MessageInviteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageInviteInclude<ExtArgs> | null
    /**
     * Filter, which MessageInvite to fetch.
     */
    where: MessageInviteWhereUniqueInput
  }

  /**
   * MessageInvite findUniqueOrThrow
   */
  export type MessageInviteFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MessageInvite
     */
    select?: MessageInviteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MessageInvite
     */
    omit?: MessageInviteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageInviteInclude<ExtArgs> | null
    /**
     * Filter, which MessageInvite to fetch.
     */
    where: MessageInviteWhereUniqueInput
  }

  /**
   * MessageInvite findFirst
   */
  export type MessageInviteFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MessageInvite
     */
    select?: MessageInviteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MessageInvite
     */
    omit?: MessageInviteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageInviteInclude<ExtArgs> | null
    /**
     * Filter, which MessageInvite to fetch.
     */
    where?: MessageInviteWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MessageInvites to fetch.
     */
    orderBy?: MessageInviteOrderByWithRelationInput | MessageInviteOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for MessageInvites.
     */
    cursor?: MessageInviteWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MessageInvites from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MessageInvites.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of MessageInvites.
     */
    distinct?: MessageInviteScalarFieldEnum | MessageInviteScalarFieldEnum[]
  }

  /**
   * MessageInvite findFirstOrThrow
   */
  export type MessageInviteFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MessageInvite
     */
    select?: MessageInviteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MessageInvite
     */
    omit?: MessageInviteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageInviteInclude<ExtArgs> | null
    /**
     * Filter, which MessageInvite to fetch.
     */
    where?: MessageInviteWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MessageInvites to fetch.
     */
    orderBy?: MessageInviteOrderByWithRelationInput | MessageInviteOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for MessageInvites.
     */
    cursor?: MessageInviteWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MessageInvites from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MessageInvites.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of MessageInvites.
     */
    distinct?: MessageInviteScalarFieldEnum | MessageInviteScalarFieldEnum[]
  }

  /**
   * MessageInvite findMany
   */
  export type MessageInviteFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MessageInvite
     */
    select?: MessageInviteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MessageInvite
     */
    omit?: MessageInviteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageInviteInclude<ExtArgs> | null
    /**
     * Filter, which MessageInvites to fetch.
     */
    where?: MessageInviteWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of MessageInvites to fetch.
     */
    orderBy?: MessageInviteOrderByWithRelationInput | MessageInviteOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing MessageInvites.
     */
    cursor?: MessageInviteWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` MessageInvites from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` MessageInvites.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of MessageInvites.
     */
    distinct?: MessageInviteScalarFieldEnum | MessageInviteScalarFieldEnum[]
  }

  /**
   * MessageInvite create
   */
  export type MessageInviteCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MessageInvite
     */
    select?: MessageInviteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MessageInvite
     */
    omit?: MessageInviteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageInviteInclude<ExtArgs> | null
    /**
     * The data needed to create a MessageInvite.
     */
    data: XOR<MessageInviteCreateInput, MessageInviteUncheckedCreateInput>
  }

  /**
   * MessageInvite createMany
   */
  export type MessageInviteCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many MessageInvites.
     */
    data: MessageInviteCreateManyInput | MessageInviteCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * MessageInvite createManyAndReturn
   */
  export type MessageInviteCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MessageInvite
     */
    select?: MessageInviteSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the MessageInvite
     */
    omit?: MessageInviteOmit<ExtArgs> | null
    /**
     * The data used to create many MessageInvites.
     */
    data: MessageInviteCreateManyInput | MessageInviteCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageInviteIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * MessageInvite update
   */
  export type MessageInviteUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MessageInvite
     */
    select?: MessageInviteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MessageInvite
     */
    omit?: MessageInviteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageInviteInclude<ExtArgs> | null
    /**
     * The data needed to update a MessageInvite.
     */
    data: XOR<MessageInviteUpdateInput, MessageInviteUncheckedUpdateInput>
    /**
     * Choose, which MessageInvite to update.
     */
    where: MessageInviteWhereUniqueInput
  }

  /**
   * MessageInvite updateMany
   */
  export type MessageInviteUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update MessageInvites.
     */
    data: XOR<MessageInviteUpdateManyMutationInput, MessageInviteUncheckedUpdateManyInput>
    /**
     * Filter which MessageInvites to update
     */
    where?: MessageInviteWhereInput
    /**
     * Limit how many MessageInvites to update.
     */
    limit?: number
  }

  /**
   * MessageInvite updateManyAndReturn
   */
  export type MessageInviteUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MessageInvite
     */
    select?: MessageInviteSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the MessageInvite
     */
    omit?: MessageInviteOmit<ExtArgs> | null
    /**
     * The data used to update MessageInvites.
     */
    data: XOR<MessageInviteUpdateManyMutationInput, MessageInviteUncheckedUpdateManyInput>
    /**
     * Filter which MessageInvites to update
     */
    where?: MessageInviteWhereInput
    /**
     * Limit how many MessageInvites to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageInviteIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * MessageInvite upsert
   */
  export type MessageInviteUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MessageInvite
     */
    select?: MessageInviteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MessageInvite
     */
    omit?: MessageInviteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageInviteInclude<ExtArgs> | null
    /**
     * The filter to search for the MessageInvite to update in case it exists.
     */
    where: MessageInviteWhereUniqueInput
    /**
     * In case the MessageInvite found by the `where` argument doesn't exist, create a new MessageInvite with this data.
     */
    create: XOR<MessageInviteCreateInput, MessageInviteUncheckedCreateInput>
    /**
     * In case the MessageInvite was found with the provided `where` argument, update it with this data.
     */
    update: XOR<MessageInviteUpdateInput, MessageInviteUncheckedUpdateInput>
  }

  /**
   * MessageInvite delete
   */
  export type MessageInviteDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MessageInvite
     */
    select?: MessageInviteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MessageInvite
     */
    omit?: MessageInviteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageInviteInclude<ExtArgs> | null
    /**
     * Filter which MessageInvite to delete.
     */
    where: MessageInviteWhereUniqueInput
  }

  /**
   * MessageInvite deleteMany
   */
  export type MessageInviteDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which MessageInvites to delete
     */
    where?: MessageInviteWhereInput
    /**
     * Limit how many MessageInvites to delete.
     */
    limit?: number
  }

  /**
   * MessageInvite.contributions
   */
  export type MessageInvite$contributionsArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Contribution
     */
    select?: ContributionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Contribution
     */
    omit?: ContributionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ContributionInclude<ExtArgs> | null
    where?: ContributionWhereInput
    orderBy?: ContributionOrderByWithRelationInput | ContributionOrderByWithRelationInput[]
    cursor?: ContributionWhereUniqueInput
    take?: number
    skip?: number
    distinct?: ContributionScalarFieldEnum | ContributionScalarFieldEnum[]
  }

  /**
   * MessageInvite without action
   */
  export type MessageInviteDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the MessageInvite
     */
    select?: MessageInviteSelect<ExtArgs> | null
    /**
     * Omit specific fields from the MessageInvite
     */
    omit?: MessageInviteOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: MessageInviteInclude<ExtArgs> | null
  }


  /**
   * Model Contribution
   */

  export type AggregateContribution = {
    _count: ContributionCountAggregateOutputType | null
    _min: ContributionMinAggregateOutputType | null
    _max: ContributionMaxAggregateOutputType | null
  }

  export type ContributionMinAggregateOutputType = {
    id: string | null
    userId: string | null
    inviteId: string | null
    contributorName: string | null
    contributorNote: string | null
    type: string | null
    content: string | null
    mediaUrl: string | null
    mediaBlobPath: string | null
    viewedByUser: boolean | null
    importedToTimelineItemId: string | null
    archivedAt: Date | null
    createdAt: Date | null
  }

  export type ContributionMaxAggregateOutputType = {
    id: string | null
    userId: string | null
    inviteId: string | null
    contributorName: string | null
    contributorNote: string | null
    type: string | null
    content: string | null
    mediaUrl: string | null
    mediaBlobPath: string | null
    viewedByUser: boolean | null
    importedToTimelineItemId: string | null
    archivedAt: Date | null
    createdAt: Date | null
  }

  export type ContributionCountAggregateOutputType = {
    id: number
    userId: number
    inviteId: number
    contributorName: number
    contributorNote: number
    type: number
    content: number
    mediaUrl: number
    mediaBlobPath: number
    viewedByUser: number
    importedToTimelineItemId: number
    archivedAt: number
    createdAt: number
    _all: number
  }


  export type ContributionMinAggregateInputType = {
    id?: true
    userId?: true
    inviteId?: true
    contributorName?: true
    contributorNote?: true
    type?: true
    content?: true
    mediaUrl?: true
    mediaBlobPath?: true
    viewedByUser?: true
    importedToTimelineItemId?: true
    archivedAt?: true
    createdAt?: true
  }

  export type ContributionMaxAggregateInputType = {
    id?: true
    userId?: true
    inviteId?: true
    contributorName?: true
    contributorNote?: true
    type?: true
    content?: true
    mediaUrl?: true
    mediaBlobPath?: true
    viewedByUser?: true
    importedToTimelineItemId?: true
    archivedAt?: true
    createdAt?: true
  }

  export type ContributionCountAggregateInputType = {
    id?: true
    userId?: true
    inviteId?: true
    contributorName?: true
    contributorNote?: true
    type?: true
    content?: true
    mediaUrl?: true
    mediaBlobPath?: true
    viewedByUser?: true
    importedToTimelineItemId?: true
    archivedAt?: true
    createdAt?: true
    _all?: true
  }

  export type ContributionAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Contribution to aggregate.
     */
    where?: ContributionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Contributions to fetch.
     */
    orderBy?: ContributionOrderByWithRelationInput | ContributionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: ContributionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Contributions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Contributions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Contributions
    **/
    _count?: true | ContributionCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: ContributionMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: ContributionMaxAggregateInputType
  }

  export type GetContributionAggregateType<T extends ContributionAggregateArgs> = {
        [P in keyof T & keyof AggregateContribution]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateContribution[P]>
      : GetScalarType<T[P], AggregateContribution[P]>
  }




  export type ContributionGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ContributionWhereInput
    orderBy?: ContributionOrderByWithAggregationInput | ContributionOrderByWithAggregationInput[]
    by: ContributionScalarFieldEnum[] | ContributionScalarFieldEnum
    having?: ContributionScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: ContributionCountAggregateInputType | true
    _min?: ContributionMinAggregateInputType
    _max?: ContributionMaxAggregateInputType
  }

  export type ContributionGroupByOutputType = {
    id: string
    userId: string
    inviteId: string
    contributorName: string
    contributorNote: string | null
    type: string
    content: string | null
    mediaUrl: string | null
    mediaBlobPath: string | null
    viewedByUser: boolean
    importedToTimelineItemId: string | null
    archivedAt: Date | null
    createdAt: Date
    _count: ContributionCountAggregateOutputType | null
    _min: ContributionMinAggregateOutputType | null
    _max: ContributionMaxAggregateOutputType | null
  }

  type GetContributionGroupByPayload<T extends ContributionGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<ContributionGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof ContributionGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], ContributionGroupByOutputType[P]>
            : GetScalarType<T[P], ContributionGroupByOutputType[P]>
        }
      >
    >


  export type ContributionSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    inviteId?: boolean
    contributorName?: boolean
    contributorNote?: boolean
    type?: boolean
    content?: boolean
    mediaUrl?: boolean
    mediaBlobPath?: boolean
    viewedByUser?: boolean
    importedToTimelineItemId?: boolean
    archivedAt?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
    invite?: boolean | MessageInviteDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["contribution"]>

  export type ContributionSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    inviteId?: boolean
    contributorName?: boolean
    contributorNote?: boolean
    type?: boolean
    content?: boolean
    mediaUrl?: boolean
    mediaBlobPath?: boolean
    viewedByUser?: boolean
    importedToTimelineItemId?: boolean
    archivedAt?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
    invite?: boolean | MessageInviteDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["contribution"]>

  export type ContributionSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    inviteId?: boolean
    contributorName?: boolean
    contributorNote?: boolean
    type?: boolean
    content?: boolean
    mediaUrl?: boolean
    mediaBlobPath?: boolean
    viewedByUser?: boolean
    importedToTimelineItemId?: boolean
    archivedAt?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
    invite?: boolean | MessageInviteDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["contribution"]>

  export type ContributionSelectScalar = {
    id?: boolean
    userId?: boolean
    inviteId?: boolean
    contributorName?: boolean
    contributorNote?: boolean
    type?: boolean
    content?: boolean
    mediaUrl?: boolean
    mediaBlobPath?: boolean
    viewedByUser?: boolean
    importedToTimelineItemId?: boolean
    archivedAt?: boolean
    createdAt?: boolean
  }

  export type ContributionOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "userId" | "inviteId" | "contributorName" | "contributorNote" | "type" | "content" | "mediaUrl" | "mediaBlobPath" | "viewedByUser" | "importedToTimelineItemId" | "archivedAt" | "createdAt", ExtArgs["result"]["contribution"]>
  export type ContributionInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
    invite?: boolean | MessageInviteDefaultArgs<ExtArgs>
  }
  export type ContributionIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
    invite?: boolean | MessageInviteDefaultArgs<ExtArgs>
  }
  export type ContributionIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
    invite?: boolean | MessageInviteDefaultArgs<ExtArgs>
  }

  export type $ContributionPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Contribution"
    objects: {
      user: Prisma.$UserPayload<ExtArgs>
      invite: Prisma.$MessageInvitePayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      userId: string
      inviteId: string
      contributorName: string
      contributorNote: string | null
      type: string
      content: string | null
      mediaUrl: string | null
      mediaBlobPath: string | null
      viewedByUser: boolean
      importedToTimelineItemId: string | null
      archivedAt: Date | null
      createdAt: Date
    }, ExtArgs["result"]["contribution"]>
    composites: {}
  }

  type ContributionGetPayload<S extends boolean | null | undefined | ContributionDefaultArgs> = $Result.GetResult<Prisma.$ContributionPayload, S>

  type ContributionCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<ContributionFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: ContributionCountAggregateInputType | true
    }

  export interface ContributionDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Contribution'], meta: { name: 'Contribution' } }
    /**
     * Find zero or one Contribution that matches the filter.
     * @param {ContributionFindUniqueArgs} args - Arguments to find a Contribution
     * @example
     * // Get one Contribution
     * const contribution = await prisma.contribution.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends ContributionFindUniqueArgs>(args: SelectSubset<T, ContributionFindUniqueArgs<ExtArgs>>): Prisma__ContributionClient<$Result.GetResult<Prisma.$ContributionPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Contribution that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {ContributionFindUniqueOrThrowArgs} args - Arguments to find a Contribution
     * @example
     * // Get one Contribution
     * const contribution = await prisma.contribution.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends ContributionFindUniqueOrThrowArgs>(args: SelectSubset<T, ContributionFindUniqueOrThrowArgs<ExtArgs>>): Prisma__ContributionClient<$Result.GetResult<Prisma.$ContributionPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Contribution that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ContributionFindFirstArgs} args - Arguments to find a Contribution
     * @example
     * // Get one Contribution
     * const contribution = await prisma.contribution.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends ContributionFindFirstArgs>(args?: SelectSubset<T, ContributionFindFirstArgs<ExtArgs>>): Prisma__ContributionClient<$Result.GetResult<Prisma.$ContributionPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Contribution that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ContributionFindFirstOrThrowArgs} args - Arguments to find a Contribution
     * @example
     * // Get one Contribution
     * const contribution = await prisma.contribution.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends ContributionFindFirstOrThrowArgs>(args?: SelectSubset<T, ContributionFindFirstOrThrowArgs<ExtArgs>>): Prisma__ContributionClient<$Result.GetResult<Prisma.$ContributionPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Contributions that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ContributionFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Contributions
     * const contributions = await prisma.contribution.findMany()
     * 
     * // Get first 10 Contributions
     * const contributions = await prisma.contribution.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const contributionWithIdOnly = await prisma.contribution.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends ContributionFindManyArgs>(args?: SelectSubset<T, ContributionFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ContributionPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Contribution.
     * @param {ContributionCreateArgs} args - Arguments to create a Contribution.
     * @example
     * // Create one Contribution
     * const Contribution = await prisma.contribution.create({
     *   data: {
     *     // ... data to create a Contribution
     *   }
     * })
     * 
     */
    create<T extends ContributionCreateArgs>(args: SelectSubset<T, ContributionCreateArgs<ExtArgs>>): Prisma__ContributionClient<$Result.GetResult<Prisma.$ContributionPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Contributions.
     * @param {ContributionCreateManyArgs} args - Arguments to create many Contributions.
     * @example
     * // Create many Contributions
     * const contribution = await prisma.contribution.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends ContributionCreateManyArgs>(args?: SelectSubset<T, ContributionCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Contributions and returns the data saved in the database.
     * @param {ContributionCreateManyAndReturnArgs} args - Arguments to create many Contributions.
     * @example
     * // Create many Contributions
     * const contribution = await prisma.contribution.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Contributions and only return the `id`
     * const contributionWithIdOnly = await prisma.contribution.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends ContributionCreateManyAndReturnArgs>(args?: SelectSubset<T, ContributionCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ContributionPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Contribution.
     * @param {ContributionDeleteArgs} args - Arguments to delete one Contribution.
     * @example
     * // Delete one Contribution
     * const Contribution = await prisma.contribution.delete({
     *   where: {
     *     // ... filter to delete one Contribution
     *   }
     * })
     * 
     */
    delete<T extends ContributionDeleteArgs>(args: SelectSubset<T, ContributionDeleteArgs<ExtArgs>>): Prisma__ContributionClient<$Result.GetResult<Prisma.$ContributionPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Contribution.
     * @param {ContributionUpdateArgs} args - Arguments to update one Contribution.
     * @example
     * // Update one Contribution
     * const contribution = await prisma.contribution.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends ContributionUpdateArgs>(args: SelectSubset<T, ContributionUpdateArgs<ExtArgs>>): Prisma__ContributionClient<$Result.GetResult<Prisma.$ContributionPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Contributions.
     * @param {ContributionDeleteManyArgs} args - Arguments to filter Contributions to delete.
     * @example
     * // Delete a few Contributions
     * const { count } = await prisma.contribution.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends ContributionDeleteManyArgs>(args?: SelectSubset<T, ContributionDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Contributions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ContributionUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Contributions
     * const contribution = await prisma.contribution.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends ContributionUpdateManyArgs>(args: SelectSubset<T, ContributionUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Contributions and returns the data updated in the database.
     * @param {ContributionUpdateManyAndReturnArgs} args - Arguments to update many Contributions.
     * @example
     * // Update many Contributions
     * const contribution = await prisma.contribution.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Contributions and only return the `id`
     * const contributionWithIdOnly = await prisma.contribution.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends ContributionUpdateManyAndReturnArgs>(args: SelectSubset<T, ContributionUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ContributionPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Contribution.
     * @param {ContributionUpsertArgs} args - Arguments to update or create a Contribution.
     * @example
     * // Update or create a Contribution
     * const contribution = await prisma.contribution.upsert({
     *   create: {
     *     // ... data to create a Contribution
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Contribution we want to update
     *   }
     * })
     */
    upsert<T extends ContributionUpsertArgs>(args: SelectSubset<T, ContributionUpsertArgs<ExtArgs>>): Prisma__ContributionClient<$Result.GetResult<Prisma.$ContributionPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Contributions.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ContributionCountArgs} args - Arguments to filter Contributions to count.
     * @example
     * // Count the number of Contributions
     * const count = await prisma.contribution.count({
     *   where: {
     *     // ... the filter for the Contributions we want to count
     *   }
     * })
    **/
    count<T extends ContributionCountArgs>(
      args?: Subset<T, ContributionCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], ContributionCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Contribution.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ContributionAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ContributionAggregateArgs>(args: Subset<T, ContributionAggregateArgs>): Prisma.PrismaPromise<GetContributionAggregateType<T>>

    /**
     * Group by Contribution.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ContributionGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends ContributionGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: ContributionGroupByArgs['orderBy'] }
        : { orderBy?: ContributionGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, ContributionGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetContributionGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Contribution model
   */
  readonly fields: ContributionFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Contribution.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__ContributionClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    invite<T extends MessageInviteDefaultArgs<ExtArgs> = {}>(args?: Subset<T, MessageInviteDefaultArgs<ExtArgs>>): Prisma__MessageInviteClient<$Result.GetResult<Prisma.$MessageInvitePayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Contribution model
   */
  interface ContributionFieldRefs {
    readonly id: FieldRef<"Contribution", 'String'>
    readonly userId: FieldRef<"Contribution", 'String'>
    readonly inviteId: FieldRef<"Contribution", 'String'>
    readonly contributorName: FieldRef<"Contribution", 'String'>
    readonly contributorNote: FieldRef<"Contribution", 'String'>
    readonly type: FieldRef<"Contribution", 'String'>
    readonly content: FieldRef<"Contribution", 'String'>
    readonly mediaUrl: FieldRef<"Contribution", 'String'>
    readonly mediaBlobPath: FieldRef<"Contribution", 'String'>
    readonly viewedByUser: FieldRef<"Contribution", 'Boolean'>
    readonly importedToTimelineItemId: FieldRef<"Contribution", 'String'>
    readonly archivedAt: FieldRef<"Contribution", 'DateTime'>
    readonly createdAt: FieldRef<"Contribution", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Contribution findUnique
   */
  export type ContributionFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Contribution
     */
    select?: ContributionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Contribution
     */
    omit?: ContributionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ContributionInclude<ExtArgs> | null
    /**
     * Filter, which Contribution to fetch.
     */
    where: ContributionWhereUniqueInput
  }

  /**
   * Contribution findUniqueOrThrow
   */
  export type ContributionFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Contribution
     */
    select?: ContributionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Contribution
     */
    omit?: ContributionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ContributionInclude<ExtArgs> | null
    /**
     * Filter, which Contribution to fetch.
     */
    where: ContributionWhereUniqueInput
  }

  /**
   * Contribution findFirst
   */
  export type ContributionFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Contribution
     */
    select?: ContributionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Contribution
     */
    omit?: ContributionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ContributionInclude<ExtArgs> | null
    /**
     * Filter, which Contribution to fetch.
     */
    where?: ContributionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Contributions to fetch.
     */
    orderBy?: ContributionOrderByWithRelationInput | ContributionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Contributions.
     */
    cursor?: ContributionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Contributions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Contributions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Contributions.
     */
    distinct?: ContributionScalarFieldEnum | ContributionScalarFieldEnum[]
  }

  /**
   * Contribution findFirstOrThrow
   */
  export type ContributionFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Contribution
     */
    select?: ContributionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Contribution
     */
    omit?: ContributionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ContributionInclude<ExtArgs> | null
    /**
     * Filter, which Contribution to fetch.
     */
    where?: ContributionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Contributions to fetch.
     */
    orderBy?: ContributionOrderByWithRelationInput | ContributionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Contributions.
     */
    cursor?: ContributionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Contributions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Contributions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Contributions.
     */
    distinct?: ContributionScalarFieldEnum | ContributionScalarFieldEnum[]
  }

  /**
   * Contribution findMany
   */
  export type ContributionFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Contribution
     */
    select?: ContributionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Contribution
     */
    omit?: ContributionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ContributionInclude<ExtArgs> | null
    /**
     * Filter, which Contributions to fetch.
     */
    where?: ContributionWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Contributions to fetch.
     */
    orderBy?: ContributionOrderByWithRelationInput | ContributionOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Contributions.
     */
    cursor?: ContributionWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Contributions from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Contributions.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Contributions.
     */
    distinct?: ContributionScalarFieldEnum | ContributionScalarFieldEnum[]
  }

  /**
   * Contribution create
   */
  export type ContributionCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Contribution
     */
    select?: ContributionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Contribution
     */
    omit?: ContributionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ContributionInclude<ExtArgs> | null
    /**
     * The data needed to create a Contribution.
     */
    data: XOR<ContributionCreateInput, ContributionUncheckedCreateInput>
  }

  /**
   * Contribution createMany
   */
  export type ContributionCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Contributions.
     */
    data: ContributionCreateManyInput | ContributionCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Contribution createManyAndReturn
   */
  export type ContributionCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Contribution
     */
    select?: ContributionSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Contribution
     */
    omit?: ContributionOmit<ExtArgs> | null
    /**
     * The data used to create many Contributions.
     */
    data: ContributionCreateManyInput | ContributionCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ContributionIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * Contribution update
   */
  export type ContributionUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Contribution
     */
    select?: ContributionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Contribution
     */
    omit?: ContributionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ContributionInclude<ExtArgs> | null
    /**
     * The data needed to update a Contribution.
     */
    data: XOR<ContributionUpdateInput, ContributionUncheckedUpdateInput>
    /**
     * Choose, which Contribution to update.
     */
    where: ContributionWhereUniqueInput
  }

  /**
   * Contribution updateMany
   */
  export type ContributionUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Contributions.
     */
    data: XOR<ContributionUpdateManyMutationInput, ContributionUncheckedUpdateManyInput>
    /**
     * Filter which Contributions to update
     */
    where?: ContributionWhereInput
    /**
     * Limit how many Contributions to update.
     */
    limit?: number
  }

  /**
   * Contribution updateManyAndReturn
   */
  export type ContributionUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Contribution
     */
    select?: ContributionSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Contribution
     */
    omit?: ContributionOmit<ExtArgs> | null
    /**
     * The data used to update Contributions.
     */
    data: XOR<ContributionUpdateManyMutationInput, ContributionUncheckedUpdateManyInput>
    /**
     * Filter which Contributions to update
     */
    where?: ContributionWhereInput
    /**
     * Limit how many Contributions to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ContributionIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * Contribution upsert
   */
  export type ContributionUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Contribution
     */
    select?: ContributionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Contribution
     */
    omit?: ContributionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ContributionInclude<ExtArgs> | null
    /**
     * The filter to search for the Contribution to update in case it exists.
     */
    where: ContributionWhereUniqueInput
    /**
     * In case the Contribution found by the `where` argument doesn't exist, create a new Contribution with this data.
     */
    create: XOR<ContributionCreateInput, ContributionUncheckedCreateInput>
    /**
     * In case the Contribution was found with the provided `where` argument, update it with this data.
     */
    update: XOR<ContributionUpdateInput, ContributionUncheckedUpdateInput>
  }

  /**
   * Contribution delete
   */
  export type ContributionDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Contribution
     */
    select?: ContributionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Contribution
     */
    omit?: ContributionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ContributionInclude<ExtArgs> | null
    /**
     * Filter which Contribution to delete.
     */
    where: ContributionWhereUniqueInput
  }

  /**
   * Contribution deleteMany
   */
  export type ContributionDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Contributions to delete
     */
    where?: ContributionWhereInput
    /**
     * Limit how many Contributions to delete.
     */
    limit?: number
  }

  /**
   * Contribution without action
   */
  export type ContributionDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Contribution
     */
    select?: ContributionSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Contribution
     */
    omit?: ContributionOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ContributionInclude<ExtArgs> | null
  }


  /**
   * Model TimelineItem
   */

  export type AggregateTimelineItem = {
    _count: TimelineItemCountAggregateOutputType | null
    _min: TimelineItemMinAggregateOutputType | null
    _max: TimelineItemMaxAggregateOutputType | null
  }

  export type TimelineItemMinAggregateOutputType = {
    id: string | null
    userId: string | null
    date: Date | null
    title: string | null
    story: string | null
    mediaUrl: string | null
    createdAt: Date | null
  }

  export type TimelineItemMaxAggregateOutputType = {
    id: string | null
    userId: string | null
    date: Date | null
    title: string | null
    story: string | null
    mediaUrl: string | null
    createdAt: Date | null
  }

  export type TimelineItemCountAggregateOutputType = {
    id: number
    userId: number
    date: number
    title: number
    story: number
    mediaUrl: number
    createdAt: number
    _all: number
  }


  export type TimelineItemMinAggregateInputType = {
    id?: true
    userId?: true
    date?: true
    title?: true
    story?: true
    mediaUrl?: true
    createdAt?: true
  }

  export type TimelineItemMaxAggregateInputType = {
    id?: true
    userId?: true
    date?: true
    title?: true
    story?: true
    mediaUrl?: true
    createdAt?: true
  }

  export type TimelineItemCountAggregateInputType = {
    id?: true
    userId?: true
    date?: true
    title?: true
    story?: true
    mediaUrl?: true
    createdAt?: true
    _all?: true
  }

  export type TimelineItemAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which TimelineItem to aggregate.
     */
    where?: TimelineItemWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TimelineItems to fetch.
     */
    orderBy?: TimelineItemOrderByWithRelationInput | TimelineItemOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: TimelineItemWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TimelineItems from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TimelineItems.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned TimelineItems
    **/
    _count?: true | TimelineItemCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: TimelineItemMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: TimelineItemMaxAggregateInputType
  }

  export type GetTimelineItemAggregateType<T extends TimelineItemAggregateArgs> = {
        [P in keyof T & keyof AggregateTimelineItem]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateTimelineItem[P]>
      : GetScalarType<T[P], AggregateTimelineItem[P]>
  }




  export type TimelineItemGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: TimelineItemWhereInput
    orderBy?: TimelineItemOrderByWithAggregationInput | TimelineItemOrderByWithAggregationInput[]
    by: TimelineItemScalarFieldEnum[] | TimelineItemScalarFieldEnum
    having?: TimelineItemScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: TimelineItemCountAggregateInputType | true
    _min?: TimelineItemMinAggregateInputType
    _max?: TimelineItemMaxAggregateInputType
  }

  export type TimelineItemGroupByOutputType = {
    id: string
    userId: string
    date: Date
    title: string
    story: string | null
    mediaUrl: string | null
    createdAt: Date
    _count: TimelineItemCountAggregateOutputType | null
    _min: TimelineItemMinAggregateOutputType | null
    _max: TimelineItemMaxAggregateOutputType | null
  }

  type GetTimelineItemGroupByPayload<T extends TimelineItemGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<TimelineItemGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof TimelineItemGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], TimelineItemGroupByOutputType[P]>
            : GetScalarType<T[P], TimelineItemGroupByOutputType[P]>
        }
      >
    >


  export type TimelineItemSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    date?: boolean
    title?: boolean
    story?: boolean
    mediaUrl?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
    photos?: boolean | TimelineItem$photosArgs<ExtArgs>
    _count?: boolean | TimelineItemCountOutputTypeDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["timelineItem"]>

  export type TimelineItemSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    date?: boolean
    title?: boolean
    story?: boolean
    mediaUrl?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["timelineItem"]>

  export type TimelineItemSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    date?: boolean
    title?: boolean
    story?: boolean
    mediaUrl?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["timelineItem"]>

  export type TimelineItemSelectScalar = {
    id?: boolean
    userId?: boolean
    date?: boolean
    title?: boolean
    story?: boolean
    mediaUrl?: boolean
    createdAt?: boolean
  }

  export type TimelineItemOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "userId" | "date" | "title" | "story" | "mediaUrl" | "createdAt", ExtArgs["result"]["timelineItem"]>
  export type TimelineItemInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
    photos?: boolean | TimelineItem$photosArgs<ExtArgs>
    _count?: boolean | TimelineItemCountOutputTypeDefaultArgs<ExtArgs>
  }
  export type TimelineItemIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }
  export type TimelineItemIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }

  export type $TimelineItemPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "TimelineItem"
    objects: {
      user: Prisma.$UserPayload<ExtArgs>
      photos: Prisma.$PhotoPayload<ExtArgs>[]
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      userId: string
      date: Date
      title: string
      story: string | null
      mediaUrl: string | null
      createdAt: Date
    }, ExtArgs["result"]["timelineItem"]>
    composites: {}
  }

  type TimelineItemGetPayload<S extends boolean | null | undefined | TimelineItemDefaultArgs> = $Result.GetResult<Prisma.$TimelineItemPayload, S>

  type TimelineItemCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<TimelineItemFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: TimelineItemCountAggregateInputType | true
    }

  export interface TimelineItemDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['TimelineItem'], meta: { name: 'TimelineItem' } }
    /**
     * Find zero or one TimelineItem that matches the filter.
     * @param {TimelineItemFindUniqueArgs} args - Arguments to find a TimelineItem
     * @example
     * // Get one TimelineItem
     * const timelineItem = await prisma.timelineItem.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends TimelineItemFindUniqueArgs>(args: SelectSubset<T, TimelineItemFindUniqueArgs<ExtArgs>>): Prisma__TimelineItemClient<$Result.GetResult<Prisma.$TimelineItemPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one TimelineItem that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {TimelineItemFindUniqueOrThrowArgs} args - Arguments to find a TimelineItem
     * @example
     * // Get one TimelineItem
     * const timelineItem = await prisma.timelineItem.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends TimelineItemFindUniqueOrThrowArgs>(args: SelectSubset<T, TimelineItemFindUniqueOrThrowArgs<ExtArgs>>): Prisma__TimelineItemClient<$Result.GetResult<Prisma.$TimelineItemPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first TimelineItem that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TimelineItemFindFirstArgs} args - Arguments to find a TimelineItem
     * @example
     * // Get one TimelineItem
     * const timelineItem = await prisma.timelineItem.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends TimelineItemFindFirstArgs>(args?: SelectSubset<T, TimelineItemFindFirstArgs<ExtArgs>>): Prisma__TimelineItemClient<$Result.GetResult<Prisma.$TimelineItemPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first TimelineItem that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TimelineItemFindFirstOrThrowArgs} args - Arguments to find a TimelineItem
     * @example
     * // Get one TimelineItem
     * const timelineItem = await prisma.timelineItem.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends TimelineItemFindFirstOrThrowArgs>(args?: SelectSubset<T, TimelineItemFindFirstOrThrowArgs<ExtArgs>>): Prisma__TimelineItemClient<$Result.GetResult<Prisma.$TimelineItemPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more TimelineItems that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TimelineItemFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all TimelineItems
     * const timelineItems = await prisma.timelineItem.findMany()
     * 
     * // Get first 10 TimelineItems
     * const timelineItems = await prisma.timelineItem.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const timelineItemWithIdOnly = await prisma.timelineItem.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends TimelineItemFindManyArgs>(args?: SelectSubset<T, TimelineItemFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TimelineItemPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a TimelineItem.
     * @param {TimelineItemCreateArgs} args - Arguments to create a TimelineItem.
     * @example
     * // Create one TimelineItem
     * const TimelineItem = await prisma.timelineItem.create({
     *   data: {
     *     // ... data to create a TimelineItem
     *   }
     * })
     * 
     */
    create<T extends TimelineItemCreateArgs>(args: SelectSubset<T, TimelineItemCreateArgs<ExtArgs>>): Prisma__TimelineItemClient<$Result.GetResult<Prisma.$TimelineItemPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many TimelineItems.
     * @param {TimelineItemCreateManyArgs} args - Arguments to create many TimelineItems.
     * @example
     * // Create many TimelineItems
     * const timelineItem = await prisma.timelineItem.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends TimelineItemCreateManyArgs>(args?: SelectSubset<T, TimelineItemCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many TimelineItems and returns the data saved in the database.
     * @param {TimelineItemCreateManyAndReturnArgs} args - Arguments to create many TimelineItems.
     * @example
     * // Create many TimelineItems
     * const timelineItem = await prisma.timelineItem.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many TimelineItems and only return the `id`
     * const timelineItemWithIdOnly = await prisma.timelineItem.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends TimelineItemCreateManyAndReturnArgs>(args?: SelectSubset<T, TimelineItemCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TimelineItemPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a TimelineItem.
     * @param {TimelineItemDeleteArgs} args - Arguments to delete one TimelineItem.
     * @example
     * // Delete one TimelineItem
     * const TimelineItem = await prisma.timelineItem.delete({
     *   where: {
     *     // ... filter to delete one TimelineItem
     *   }
     * })
     * 
     */
    delete<T extends TimelineItemDeleteArgs>(args: SelectSubset<T, TimelineItemDeleteArgs<ExtArgs>>): Prisma__TimelineItemClient<$Result.GetResult<Prisma.$TimelineItemPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one TimelineItem.
     * @param {TimelineItemUpdateArgs} args - Arguments to update one TimelineItem.
     * @example
     * // Update one TimelineItem
     * const timelineItem = await prisma.timelineItem.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends TimelineItemUpdateArgs>(args: SelectSubset<T, TimelineItemUpdateArgs<ExtArgs>>): Prisma__TimelineItemClient<$Result.GetResult<Prisma.$TimelineItemPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more TimelineItems.
     * @param {TimelineItemDeleteManyArgs} args - Arguments to filter TimelineItems to delete.
     * @example
     * // Delete a few TimelineItems
     * const { count } = await prisma.timelineItem.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends TimelineItemDeleteManyArgs>(args?: SelectSubset<T, TimelineItemDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more TimelineItems.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TimelineItemUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many TimelineItems
     * const timelineItem = await prisma.timelineItem.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends TimelineItemUpdateManyArgs>(args: SelectSubset<T, TimelineItemUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more TimelineItems and returns the data updated in the database.
     * @param {TimelineItemUpdateManyAndReturnArgs} args - Arguments to update many TimelineItems.
     * @example
     * // Update many TimelineItems
     * const timelineItem = await prisma.timelineItem.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more TimelineItems and only return the `id`
     * const timelineItemWithIdOnly = await prisma.timelineItem.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends TimelineItemUpdateManyAndReturnArgs>(args: SelectSubset<T, TimelineItemUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$TimelineItemPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one TimelineItem.
     * @param {TimelineItemUpsertArgs} args - Arguments to update or create a TimelineItem.
     * @example
     * // Update or create a TimelineItem
     * const timelineItem = await prisma.timelineItem.upsert({
     *   create: {
     *     // ... data to create a TimelineItem
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the TimelineItem we want to update
     *   }
     * })
     */
    upsert<T extends TimelineItemUpsertArgs>(args: SelectSubset<T, TimelineItemUpsertArgs<ExtArgs>>): Prisma__TimelineItemClient<$Result.GetResult<Prisma.$TimelineItemPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of TimelineItems.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TimelineItemCountArgs} args - Arguments to filter TimelineItems to count.
     * @example
     * // Count the number of TimelineItems
     * const count = await prisma.timelineItem.count({
     *   where: {
     *     // ... the filter for the TimelineItems we want to count
     *   }
     * })
    **/
    count<T extends TimelineItemCountArgs>(
      args?: Subset<T, TimelineItemCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], TimelineItemCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a TimelineItem.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TimelineItemAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends TimelineItemAggregateArgs>(args: Subset<T, TimelineItemAggregateArgs>): Prisma.PrismaPromise<GetTimelineItemAggregateType<T>>

    /**
     * Group by TimelineItem.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {TimelineItemGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends TimelineItemGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: TimelineItemGroupByArgs['orderBy'] }
        : { orderBy?: TimelineItemGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, TimelineItemGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetTimelineItemGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the TimelineItem model
   */
  readonly fields: TimelineItemFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for TimelineItem.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__TimelineItemClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    photos<T extends TimelineItem$photosArgs<ExtArgs> = {}>(args?: Subset<T, TimelineItem$photosArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PhotoPayload<ExtArgs>, T, "findMany", GlobalOmitOptions> | Null>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the TimelineItem model
   */
  interface TimelineItemFieldRefs {
    readonly id: FieldRef<"TimelineItem", 'String'>
    readonly userId: FieldRef<"TimelineItem", 'String'>
    readonly date: FieldRef<"TimelineItem", 'DateTime'>
    readonly title: FieldRef<"TimelineItem", 'String'>
    readonly story: FieldRef<"TimelineItem", 'String'>
    readonly mediaUrl: FieldRef<"TimelineItem", 'String'>
    readonly createdAt: FieldRef<"TimelineItem", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * TimelineItem findUnique
   */
  export type TimelineItemFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TimelineItem
     */
    select?: TimelineItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TimelineItem
     */
    omit?: TimelineItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TimelineItemInclude<ExtArgs> | null
    /**
     * Filter, which TimelineItem to fetch.
     */
    where: TimelineItemWhereUniqueInput
  }

  /**
   * TimelineItem findUniqueOrThrow
   */
  export type TimelineItemFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TimelineItem
     */
    select?: TimelineItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TimelineItem
     */
    omit?: TimelineItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TimelineItemInclude<ExtArgs> | null
    /**
     * Filter, which TimelineItem to fetch.
     */
    where: TimelineItemWhereUniqueInput
  }

  /**
   * TimelineItem findFirst
   */
  export type TimelineItemFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TimelineItem
     */
    select?: TimelineItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TimelineItem
     */
    omit?: TimelineItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TimelineItemInclude<ExtArgs> | null
    /**
     * Filter, which TimelineItem to fetch.
     */
    where?: TimelineItemWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TimelineItems to fetch.
     */
    orderBy?: TimelineItemOrderByWithRelationInput | TimelineItemOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for TimelineItems.
     */
    cursor?: TimelineItemWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TimelineItems from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TimelineItems.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of TimelineItems.
     */
    distinct?: TimelineItemScalarFieldEnum | TimelineItemScalarFieldEnum[]
  }

  /**
   * TimelineItem findFirstOrThrow
   */
  export type TimelineItemFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TimelineItem
     */
    select?: TimelineItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TimelineItem
     */
    omit?: TimelineItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TimelineItemInclude<ExtArgs> | null
    /**
     * Filter, which TimelineItem to fetch.
     */
    where?: TimelineItemWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TimelineItems to fetch.
     */
    orderBy?: TimelineItemOrderByWithRelationInput | TimelineItemOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for TimelineItems.
     */
    cursor?: TimelineItemWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TimelineItems from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TimelineItems.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of TimelineItems.
     */
    distinct?: TimelineItemScalarFieldEnum | TimelineItemScalarFieldEnum[]
  }

  /**
   * TimelineItem findMany
   */
  export type TimelineItemFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TimelineItem
     */
    select?: TimelineItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TimelineItem
     */
    omit?: TimelineItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TimelineItemInclude<ExtArgs> | null
    /**
     * Filter, which TimelineItems to fetch.
     */
    where?: TimelineItemWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of TimelineItems to fetch.
     */
    orderBy?: TimelineItemOrderByWithRelationInput | TimelineItemOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing TimelineItems.
     */
    cursor?: TimelineItemWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` TimelineItems from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` TimelineItems.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of TimelineItems.
     */
    distinct?: TimelineItemScalarFieldEnum | TimelineItemScalarFieldEnum[]
  }

  /**
   * TimelineItem create
   */
  export type TimelineItemCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TimelineItem
     */
    select?: TimelineItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TimelineItem
     */
    omit?: TimelineItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TimelineItemInclude<ExtArgs> | null
    /**
     * The data needed to create a TimelineItem.
     */
    data: XOR<TimelineItemCreateInput, TimelineItemUncheckedCreateInput>
  }

  /**
   * TimelineItem createMany
   */
  export type TimelineItemCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many TimelineItems.
     */
    data: TimelineItemCreateManyInput | TimelineItemCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * TimelineItem createManyAndReturn
   */
  export type TimelineItemCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TimelineItem
     */
    select?: TimelineItemSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the TimelineItem
     */
    omit?: TimelineItemOmit<ExtArgs> | null
    /**
     * The data used to create many TimelineItems.
     */
    data: TimelineItemCreateManyInput | TimelineItemCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TimelineItemIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * TimelineItem update
   */
  export type TimelineItemUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TimelineItem
     */
    select?: TimelineItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TimelineItem
     */
    omit?: TimelineItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TimelineItemInclude<ExtArgs> | null
    /**
     * The data needed to update a TimelineItem.
     */
    data: XOR<TimelineItemUpdateInput, TimelineItemUncheckedUpdateInput>
    /**
     * Choose, which TimelineItem to update.
     */
    where: TimelineItemWhereUniqueInput
  }

  /**
   * TimelineItem updateMany
   */
  export type TimelineItemUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update TimelineItems.
     */
    data: XOR<TimelineItemUpdateManyMutationInput, TimelineItemUncheckedUpdateManyInput>
    /**
     * Filter which TimelineItems to update
     */
    where?: TimelineItemWhereInput
    /**
     * Limit how many TimelineItems to update.
     */
    limit?: number
  }

  /**
   * TimelineItem updateManyAndReturn
   */
  export type TimelineItemUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TimelineItem
     */
    select?: TimelineItemSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the TimelineItem
     */
    omit?: TimelineItemOmit<ExtArgs> | null
    /**
     * The data used to update TimelineItems.
     */
    data: XOR<TimelineItemUpdateManyMutationInput, TimelineItemUncheckedUpdateManyInput>
    /**
     * Filter which TimelineItems to update
     */
    where?: TimelineItemWhereInput
    /**
     * Limit how many TimelineItems to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TimelineItemIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * TimelineItem upsert
   */
  export type TimelineItemUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TimelineItem
     */
    select?: TimelineItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TimelineItem
     */
    omit?: TimelineItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TimelineItemInclude<ExtArgs> | null
    /**
     * The filter to search for the TimelineItem to update in case it exists.
     */
    where: TimelineItemWhereUniqueInput
    /**
     * In case the TimelineItem found by the `where` argument doesn't exist, create a new TimelineItem with this data.
     */
    create: XOR<TimelineItemCreateInput, TimelineItemUncheckedCreateInput>
    /**
     * In case the TimelineItem was found with the provided `where` argument, update it with this data.
     */
    update: XOR<TimelineItemUpdateInput, TimelineItemUncheckedUpdateInput>
  }

  /**
   * TimelineItem delete
   */
  export type TimelineItemDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TimelineItem
     */
    select?: TimelineItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TimelineItem
     */
    omit?: TimelineItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TimelineItemInclude<ExtArgs> | null
    /**
     * Filter which TimelineItem to delete.
     */
    where: TimelineItemWhereUniqueInput
  }

  /**
   * TimelineItem deleteMany
   */
  export type TimelineItemDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which TimelineItems to delete
     */
    where?: TimelineItemWhereInput
    /**
     * Limit how many TimelineItems to delete.
     */
    limit?: number
  }

  /**
   * TimelineItem.photos
   */
  export type TimelineItem$photosArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Photo
     */
    select?: PhotoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Photo
     */
    omit?: PhotoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PhotoInclude<ExtArgs> | null
    where?: PhotoWhereInput
    orderBy?: PhotoOrderByWithRelationInput | PhotoOrderByWithRelationInput[]
    cursor?: PhotoWhereUniqueInput
    take?: number
    skip?: number
    distinct?: PhotoScalarFieldEnum | PhotoScalarFieldEnum[]
  }

  /**
   * TimelineItem without action
   */
  export type TimelineItemDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TimelineItem
     */
    select?: TimelineItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TimelineItem
     */
    omit?: TimelineItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TimelineItemInclude<ExtArgs> | null
  }


  /**
   * Model Photo
   */

  export type AggregatePhoto = {
    _count: PhotoCountAggregateOutputType | null
    _avg: PhotoAvgAggregateOutputType | null
    _sum: PhotoSumAggregateOutputType | null
    _min: PhotoMinAggregateOutputType | null
    _max: PhotoMaxAggregateOutputType | null
  }

  export type PhotoAvgAggregateOutputType = {
    width: number | null
    height: number | null
    sizeBytes: number | null
    order: number | null
  }

  export type PhotoSumAggregateOutputType = {
    width: number | null
    height: number | null
    sizeBytes: number | null
    order: number | null
  }

  export type PhotoMinAggregateOutputType = {
    id: string | null
    userId: string | null
    timelineItemId: string | null
    url: string | null
    thumbnailUrl: string | null
    blobPath: string | null
    caption: string | null
    width: number | null
    height: number | null
    sizeBytes: number | null
    order: number | null
    createdAt: Date | null
  }

  export type PhotoMaxAggregateOutputType = {
    id: string | null
    userId: string | null
    timelineItemId: string | null
    url: string | null
    thumbnailUrl: string | null
    blobPath: string | null
    caption: string | null
    width: number | null
    height: number | null
    sizeBytes: number | null
    order: number | null
    createdAt: Date | null
  }

  export type PhotoCountAggregateOutputType = {
    id: number
    userId: number
    timelineItemId: number
    url: number
    thumbnailUrl: number
    blobPath: number
    caption: number
    width: number
    height: number
    sizeBytes: number
    order: number
    createdAt: number
    _all: number
  }


  export type PhotoAvgAggregateInputType = {
    width?: true
    height?: true
    sizeBytes?: true
    order?: true
  }

  export type PhotoSumAggregateInputType = {
    width?: true
    height?: true
    sizeBytes?: true
    order?: true
  }

  export type PhotoMinAggregateInputType = {
    id?: true
    userId?: true
    timelineItemId?: true
    url?: true
    thumbnailUrl?: true
    blobPath?: true
    caption?: true
    width?: true
    height?: true
    sizeBytes?: true
    order?: true
    createdAt?: true
  }

  export type PhotoMaxAggregateInputType = {
    id?: true
    userId?: true
    timelineItemId?: true
    url?: true
    thumbnailUrl?: true
    blobPath?: true
    caption?: true
    width?: true
    height?: true
    sizeBytes?: true
    order?: true
    createdAt?: true
  }

  export type PhotoCountAggregateInputType = {
    id?: true
    userId?: true
    timelineItemId?: true
    url?: true
    thumbnailUrl?: true
    blobPath?: true
    caption?: true
    width?: true
    height?: true
    sizeBytes?: true
    order?: true
    createdAt?: true
    _all?: true
  }

  export type PhotoAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Photo to aggregate.
     */
    where?: PhotoWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Photos to fetch.
     */
    orderBy?: PhotoOrderByWithRelationInput | PhotoOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: PhotoWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Photos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Photos.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Photos
    **/
    _count?: true | PhotoCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to average
    **/
    _avg?: PhotoAvgAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to sum
    **/
    _sum?: PhotoSumAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: PhotoMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: PhotoMaxAggregateInputType
  }

  export type GetPhotoAggregateType<T extends PhotoAggregateArgs> = {
        [P in keyof T & keyof AggregatePhoto]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregatePhoto[P]>
      : GetScalarType<T[P], AggregatePhoto[P]>
  }




  export type PhotoGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: PhotoWhereInput
    orderBy?: PhotoOrderByWithAggregationInput | PhotoOrderByWithAggregationInput[]
    by: PhotoScalarFieldEnum[] | PhotoScalarFieldEnum
    having?: PhotoScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: PhotoCountAggregateInputType | true
    _avg?: PhotoAvgAggregateInputType
    _sum?: PhotoSumAggregateInputType
    _min?: PhotoMinAggregateInputType
    _max?: PhotoMaxAggregateInputType
  }

  export type PhotoGroupByOutputType = {
    id: string
    userId: string
    timelineItemId: string | null
    url: string
    thumbnailUrl: string | null
    blobPath: string
    caption: string | null
    width: number | null
    height: number | null
    sizeBytes: number | null
    order: number
    createdAt: Date
    _count: PhotoCountAggregateOutputType | null
    _avg: PhotoAvgAggregateOutputType | null
    _sum: PhotoSumAggregateOutputType | null
    _min: PhotoMinAggregateOutputType | null
    _max: PhotoMaxAggregateOutputType | null
  }

  type GetPhotoGroupByPayload<T extends PhotoGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<PhotoGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof PhotoGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], PhotoGroupByOutputType[P]>
            : GetScalarType<T[P], PhotoGroupByOutputType[P]>
        }
      >
    >


  export type PhotoSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    timelineItemId?: boolean
    url?: boolean
    thumbnailUrl?: boolean
    blobPath?: boolean
    caption?: boolean
    width?: boolean
    height?: boolean
    sizeBytes?: boolean
    order?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
    timelineItem?: boolean | Photo$timelineItemArgs<ExtArgs>
  }, ExtArgs["result"]["photo"]>

  export type PhotoSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    timelineItemId?: boolean
    url?: boolean
    thumbnailUrl?: boolean
    blobPath?: boolean
    caption?: boolean
    width?: boolean
    height?: boolean
    sizeBytes?: boolean
    order?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
    timelineItem?: boolean | Photo$timelineItemArgs<ExtArgs>
  }, ExtArgs["result"]["photo"]>

  export type PhotoSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    timelineItemId?: boolean
    url?: boolean
    thumbnailUrl?: boolean
    blobPath?: boolean
    caption?: boolean
    width?: boolean
    height?: boolean
    sizeBytes?: boolean
    order?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
    timelineItem?: boolean | Photo$timelineItemArgs<ExtArgs>
  }, ExtArgs["result"]["photo"]>

  export type PhotoSelectScalar = {
    id?: boolean
    userId?: boolean
    timelineItemId?: boolean
    url?: boolean
    thumbnailUrl?: boolean
    blobPath?: boolean
    caption?: boolean
    width?: boolean
    height?: boolean
    sizeBytes?: boolean
    order?: boolean
    createdAt?: boolean
  }

  export type PhotoOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "userId" | "timelineItemId" | "url" | "thumbnailUrl" | "blobPath" | "caption" | "width" | "height" | "sizeBytes" | "order" | "createdAt", ExtArgs["result"]["photo"]>
  export type PhotoInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
    timelineItem?: boolean | Photo$timelineItemArgs<ExtArgs>
  }
  export type PhotoIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
    timelineItem?: boolean | Photo$timelineItemArgs<ExtArgs>
  }
  export type PhotoIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
    timelineItem?: boolean | Photo$timelineItemArgs<ExtArgs>
  }

  export type $PhotoPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Photo"
    objects: {
      user: Prisma.$UserPayload<ExtArgs>
      timelineItem: Prisma.$TimelineItemPayload<ExtArgs> | null
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      userId: string
      timelineItemId: string | null
      url: string
      thumbnailUrl: string | null
      blobPath: string
      caption: string | null
      width: number | null
      height: number | null
      sizeBytes: number | null
      order: number
      createdAt: Date
    }, ExtArgs["result"]["photo"]>
    composites: {}
  }

  type PhotoGetPayload<S extends boolean | null | undefined | PhotoDefaultArgs> = $Result.GetResult<Prisma.$PhotoPayload, S>

  type PhotoCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<PhotoFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: PhotoCountAggregateInputType | true
    }

  export interface PhotoDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Photo'], meta: { name: 'Photo' } }
    /**
     * Find zero or one Photo that matches the filter.
     * @param {PhotoFindUniqueArgs} args - Arguments to find a Photo
     * @example
     * // Get one Photo
     * const photo = await prisma.photo.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends PhotoFindUniqueArgs>(args: SelectSubset<T, PhotoFindUniqueArgs<ExtArgs>>): Prisma__PhotoClient<$Result.GetResult<Prisma.$PhotoPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Photo that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {PhotoFindUniqueOrThrowArgs} args - Arguments to find a Photo
     * @example
     * // Get one Photo
     * const photo = await prisma.photo.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends PhotoFindUniqueOrThrowArgs>(args: SelectSubset<T, PhotoFindUniqueOrThrowArgs<ExtArgs>>): Prisma__PhotoClient<$Result.GetResult<Prisma.$PhotoPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Photo that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PhotoFindFirstArgs} args - Arguments to find a Photo
     * @example
     * // Get one Photo
     * const photo = await prisma.photo.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends PhotoFindFirstArgs>(args?: SelectSubset<T, PhotoFindFirstArgs<ExtArgs>>): Prisma__PhotoClient<$Result.GetResult<Prisma.$PhotoPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Photo that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PhotoFindFirstOrThrowArgs} args - Arguments to find a Photo
     * @example
     * // Get one Photo
     * const photo = await prisma.photo.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends PhotoFindFirstOrThrowArgs>(args?: SelectSubset<T, PhotoFindFirstOrThrowArgs<ExtArgs>>): Prisma__PhotoClient<$Result.GetResult<Prisma.$PhotoPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Photos that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PhotoFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Photos
     * const photos = await prisma.photo.findMany()
     * 
     * // Get first 10 Photos
     * const photos = await prisma.photo.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const photoWithIdOnly = await prisma.photo.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends PhotoFindManyArgs>(args?: SelectSubset<T, PhotoFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PhotoPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Photo.
     * @param {PhotoCreateArgs} args - Arguments to create a Photo.
     * @example
     * // Create one Photo
     * const Photo = await prisma.photo.create({
     *   data: {
     *     // ... data to create a Photo
     *   }
     * })
     * 
     */
    create<T extends PhotoCreateArgs>(args: SelectSubset<T, PhotoCreateArgs<ExtArgs>>): Prisma__PhotoClient<$Result.GetResult<Prisma.$PhotoPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Photos.
     * @param {PhotoCreateManyArgs} args - Arguments to create many Photos.
     * @example
     * // Create many Photos
     * const photo = await prisma.photo.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends PhotoCreateManyArgs>(args?: SelectSubset<T, PhotoCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Photos and returns the data saved in the database.
     * @param {PhotoCreateManyAndReturnArgs} args - Arguments to create many Photos.
     * @example
     * // Create many Photos
     * const photo = await prisma.photo.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Photos and only return the `id`
     * const photoWithIdOnly = await prisma.photo.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends PhotoCreateManyAndReturnArgs>(args?: SelectSubset<T, PhotoCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PhotoPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Photo.
     * @param {PhotoDeleteArgs} args - Arguments to delete one Photo.
     * @example
     * // Delete one Photo
     * const Photo = await prisma.photo.delete({
     *   where: {
     *     // ... filter to delete one Photo
     *   }
     * })
     * 
     */
    delete<T extends PhotoDeleteArgs>(args: SelectSubset<T, PhotoDeleteArgs<ExtArgs>>): Prisma__PhotoClient<$Result.GetResult<Prisma.$PhotoPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Photo.
     * @param {PhotoUpdateArgs} args - Arguments to update one Photo.
     * @example
     * // Update one Photo
     * const photo = await prisma.photo.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends PhotoUpdateArgs>(args: SelectSubset<T, PhotoUpdateArgs<ExtArgs>>): Prisma__PhotoClient<$Result.GetResult<Prisma.$PhotoPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Photos.
     * @param {PhotoDeleteManyArgs} args - Arguments to filter Photos to delete.
     * @example
     * // Delete a few Photos
     * const { count } = await prisma.photo.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends PhotoDeleteManyArgs>(args?: SelectSubset<T, PhotoDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Photos.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PhotoUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Photos
     * const photo = await prisma.photo.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends PhotoUpdateManyArgs>(args: SelectSubset<T, PhotoUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Photos and returns the data updated in the database.
     * @param {PhotoUpdateManyAndReturnArgs} args - Arguments to update many Photos.
     * @example
     * // Update many Photos
     * const photo = await prisma.photo.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Photos and only return the `id`
     * const photoWithIdOnly = await prisma.photo.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends PhotoUpdateManyAndReturnArgs>(args: SelectSubset<T, PhotoUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$PhotoPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Photo.
     * @param {PhotoUpsertArgs} args - Arguments to update or create a Photo.
     * @example
     * // Update or create a Photo
     * const photo = await prisma.photo.upsert({
     *   create: {
     *     // ... data to create a Photo
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Photo we want to update
     *   }
     * })
     */
    upsert<T extends PhotoUpsertArgs>(args: SelectSubset<T, PhotoUpsertArgs<ExtArgs>>): Prisma__PhotoClient<$Result.GetResult<Prisma.$PhotoPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Photos.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PhotoCountArgs} args - Arguments to filter Photos to count.
     * @example
     * // Count the number of Photos
     * const count = await prisma.photo.count({
     *   where: {
     *     // ... the filter for the Photos we want to count
     *   }
     * })
    **/
    count<T extends PhotoCountArgs>(
      args?: Subset<T, PhotoCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], PhotoCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Photo.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PhotoAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends PhotoAggregateArgs>(args: Subset<T, PhotoAggregateArgs>): Prisma.PrismaPromise<GetPhotoAggregateType<T>>

    /**
     * Group by Photo.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {PhotoGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends PhotoGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: PhotoGroupByArgs['orderBy'] }
        : { orderBy?: PhotoGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, PhotoGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetPhotoGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Photo model
   */
  readonly fields: PhotoFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Photo.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__PhotoClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    timelineItem<T extends Photo$timelineItemArgs<ExtArgs> = {}>(args?: Subset<T, Photo$timelineItemArgs<ExtArgs>>): Prisma__TimelineItemClient<$Result.GetResult<Prisma.$TimelineItemPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Photo model
   */
  interface PhotoFieldRefs {
    readonly id: FieldRef<"Photo", 'String'>
    readonly userId: FieldRef<"Photo", 'String'>
    readonly timelineItemId: FieldRef<"Photo", 'String'>
    readonly url: FieldRef<"Photo", 'String'>
    readonly thumbnailUrl: FieldRef<"Photo", 'String'>
    readonly blobPath: FieldRef<"Photo", 'String'>
    readonly caption: FieldRef<"Photo", 'String'>
    readonly width: FieldRef<"Photo", 'Int'>
    readonly height: FieldRef<"Photo", 'Int'>
    readonly sizeBytes: FieldRef<"Photo", 'Int'>
    readonly order: FieldRef<"Photo", 'Int'>
    readonly createdAt: FieldRef<"Photo", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Photo findUnique
   */
  export type PhotoFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Photo
     */
    select?: PhotoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Photo
     */
    omit?: PhotoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PhotoInclude<ExtArgs> | null
    /**
     * Filter, which Photo to fetch.
     */
    where: PhotoWhereUniqueInput
  }

  /**
   * Photo findUniqueOrThrow
   */
  export type PhotoFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Photo
     */
    select?: PhotoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Photo
     */
    omit?: PhotoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PhotoInclude<ExtArgs> | null
    /**
     * Filter, which Photo to fetch.
     */
    where: PhotoWhereUniqueInput
  }

  /**
   * Photo findFirst
   */
  export type PhotoFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Photo
     */
    select?: PhotoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Photo
     */
    omit?: PhotoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PhotoInclude<ExtArgs> | null
    /**
     * Filter, which Photo to fetch.
     */
    where?: PhotoWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Photos to fetch.
     */
    orderBy?: PhotoOrderByWithRelationInput | PhotoOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Photos.
     */
    cursor?: PhotoWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Photos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Photos.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Photos.
     */
    distinct?: PhotoScalarFieldEnum | PhotoScalarFieldEnum[]
  }

  /**
   * Photo findFirstOrThrow
   */
  export type PhotoFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Photo
     */
    select?: PhotoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Photo
     */
    omit?: PhotoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PhotoInclude<ExtArgs> | null
    /**
     * Filter, which Photo to fetch.
     */
    where?: PhotoWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Photos to fetch.
     */
    orderBy?: PhotoOrderByWithRelationInput | PhotoOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Photos.
     */
    cursor?: PhotoWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Photos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Photos.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Photos.
     */
    distinct?: PhotoScalarFieldEnum | PhotoScalarFieldEnum[]
  }

  /**
   * Photo findMany
   */
  export type PhotoFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Photo
     */
    select?: PhotoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Photo
     */
    omit?: PhotoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PhotoInclude<ExtArgs> | null
    /**
     * Filter, which Photos to fetch.
     */
    where?: PhotoWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Photos to fetch.
     */
    orderBy?: PhotoOrderByWithRelationInput | PhotoOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Photos.
     */
    cursor?: PhotoWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Photos from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Photos.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Photos.
     */
    distinct?: PhotoScalarFieldEnum | PhotoScalarFieldEnum[]
  }

  /**
   * Photo create
   */
  export type PhotoCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Photo
     */
    select?: PhotoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Photo
     */
    omit?: PhotoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PhotoInclude<ExtArgs> | null
    /**
     * The data needed to create a Photo.
     */
    data: XOR<PhotoCreateInput, PhotoUncheckedCreateInput>
  }

  /**
   * Photo createMany
   */
  export type PhotoCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Photos.
     */
    data: PhotoCreateManyInput | PhotoCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Photo createManyAndReturn
   */
  export type PhotoCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Photo
     */
    select?: PhotoSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Photo
     */
    omit?: PhotoOmit<ExtArgs> | null
    /**
     * The data used to create many Photos.
     */
    data: PhotoCreateManyInput | PhotoCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PhotoIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * Photo update
   */
  export type PhotoUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Photo
     */
    select?: PhotoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Photo
     */
    omit?: PhotoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PhotoInclude<ExtArgs> | null
    /**
     * The data needed to update a Photo.
     */
    data: XOR<PhotoUpdateInput, PhotoUncheckedUpdateInput>
    /**
     * Choose, which Photo to update.
     */
    where: PhotoWhereUniqueInput
  }

  /**
   * Photo updateMany
   */
  export type PhotoUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Photos.
     */
    data: XOR<PhotoUpdateManyMutationInput, PhotoUncheckedUpdateManyInput>
    /**
     * Filter which Photos to update
     */
    where?: PhotoWhereInput
    /**
     * Limit how many Photos to update.
     */
    limit?: number
  }

  /**
   * Photo updateManyAndReturn
   */
  export type PhotoUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Photo
     */
    select?: PhotoSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Photo
     */
    omit?: PhotoOmit<ExtArgs> | null
    /**
     * The data used to update Photos.
     */
    data: XOR<PhotoUpdateManyMutationInput, PhotoUncheckedUpdateManyInput>
    /**
     * Filter which Photos to update
     */
    where?: PhotoWhereInput
    /**
     * Limit how many Photos to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PhotoIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * Photo upsert
   */
  export type PhotoUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Photo
     */
    select?: PhotoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Photo
     */
    omit?: PhotoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PhotoInclude<ExtArgs> | null
    /**
     * The filter to search for the Photo to update in case it exists.
     */
    where: PhotoWhereUniqueInput
    /**
     * In case the Photo found by the `where` argument doesn't exist, create a new Photo with this data.
     */
    create: XOR<PhotoCreateInput, PhotoUncheckedCreateInput>
    /**
     * In case the Photo was found with the provided `where` argument, update it with this data.
     */
    update: XOR<PhotoUpdateInput, PhotoUncheckedUpdateInput>
  }

  /**
   * Photo delete
   */
  export type PhotoDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Photo
     */
    select?: PhotoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Photo
     */
    omit?: PhotoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PhotoInclude<ExtArgs> | null
    /**
     * Filter which Photo to delete.
     */
    where: PhotoWhereUniqueInput
  }

  /**
   * Photo deleteMany
   */
  export type PhotoDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Photos to delete
     */
    where?: PhotoWhereInput
    /**
     * Limit how many Photos to delete.
     */
    limit?: number
  }

  /**
   * Photo.timelineItem
   */
  export type Photo$timelineItemArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the TimelineItem
     */
    select?: TimelineItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the TimelineItem
     */
    omit?: TimelineItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: TimelineItemInclude<ExtArgs> | null
    where?: TimelineItemWhereInput
  }

  /**
   * Photo without action
   */
  export type PhotoDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Photo
     */
    select?: PhotoSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Photo
     */
    omit?: PhotoOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: PhotoInclude<ExtArgs> | null
  }


  /**
   * Model Arrangement
   */

  export type AggregateArrangement = {
    _count: ArrangementCountAggregateOutputType | null
    _min: ArrangementMinAggregateOutputType | null
    _max: ArrangementMaxAggregateOutputType | null
  }

  export type ArrangementMinAggregateOutputType = {
    id: string | null
    userId: string | null
    type: string | null
    vendor: string | null
    contact: string | null
    notes: string | null
    createdAt: Date | null
  }

  export type ArrangementMaxAggregateOutputType = {
    id: string | null
    userId: string | null
    type: string | null
    vendor: string | null
    contact: string | null
    notes: string | null
    createdAt: Date | null
  }

  export type ArrangementCountAggregateOutputType = {
    id: number
    userId: number
    type: number
    vendor: number
    contact: number
    notes: number
    createdAt: number
    _all: number
  }


  export type ArrangementMinAggregateInputType = {
    id?: true
    userId?: true
    type?: true
    vendor?: true
    contact?: true
    notes?: true
    createdAt?: true
  }

  export type ArrangementMaxAggregateInputType = {
    id?: true
    userId?: true
    type?: true
    vendor?: true
    contact?: true
    notes?: true
    createdAt?: true
  }

  export type ArrangementCountAggregateInputType = {
    id?: true
    userId?: true
    type?: true
    vendor?: true
    contact?: true
    notes?: true
    createdAt?: true
    _all?: true
  }

  export type ArrangementAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Arrangement to aggregate.
     */
    where?: ArrangementWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Arrangements to fetch.
     */
    orderBy?: ArrangementOrderByWithRelationInput | ArrangementOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: ArrangementWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Arrangements from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Arrangements.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Arrangements
    **/
    _count?: true | ArrangementCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: ArrangementMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: ArrangementMaxAggregateInputType
  }

  export type GetArrangementAggregateType<T extends ArrangementAggregateArgs> = {
        [P in keyof T & keyof AggregateArrangement]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateArrangement[P]>
      : GetScalarType<T[P], AggregateArrangement[P]>
  }




  export type ArrangementGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ArrangementWhereInput
    orderBy?: ArrangementOrderByWithAggregationInput | ArrangementOrderByWithAggregationInput[]
    by: ArrangementScalarFieldEnum[] | ArrangementScalarFieldEnum
    having?: ArrangementScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: ArrangementCountAggregateInputType | true
    _min?: ArrangementMinAggregateInputType
    _max?: ArrangementMaxAggregateInputType
  }

  export type ArrangementGroupByOutputType = {
    id: string
    userId: string
    type: string
    vendor: string
    contact: string | null
    notes: string | null
    createdAt: Date
    _count: ArrangementCountAggregateOutputType | null
    _min: ArrangementMinAggregateOutputType | null
    _max: ArrangementMaxAggregateOutputType | null
  }

  type GetArrangementGroupByPayload<T extends ArrangementGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<ArrangementGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof ArrangementGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], ArrangementGroupByOutputType[P]>
            : GetScalarType<T[P], ArrangementGroupByOutputType[P]>
        }
      >
    >


  export type ArrangementSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    type?: boolean
    vendor?: boolean
    contact?: boolean
    notes?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["arrangement"]>

  export type ArrangementSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    type?: boolean
    vendor?: boolean
    contact?: boolean
    notes?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["arrangement"]>

  export type ArrangementSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    type?: boolean
    vendor?: boolean
    contact?: boolean
    notes?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["arrangement"]>

  export type ArrangementSelectScalar = {
    id?: boolean
    userId?: boolean
    type?: boolean
    vendor?: boolean
    contact?: boolean
    notes?: boolean
    createdAt?: boolean
  }

  export type ArrangementOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "userId" | "type" | "vendor" | "contact" | "notes" | "createdAt", ExtArgs["result"]["arrangement"]>
  export type ArrangementInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }
  export type ArrangementIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }
  export type ArrangementIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }

  export type $ArrangementPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Arrangement"
    objects: {
      user: Prisma.$UserPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      userId: string
      type: string
      vendor: string
      contact: string | null
      notes: string | null
      createdAt: Date
    }, ExtArgs["result"]["arrangement"]>
    composites: {}
  }

  type ArrangementGetPayload<S extends boolean | null | undefined | ArrangementDefaultArgs> = $Result.GetResult<Prisma.$ArrangementPayload, S>

  type ArrangementCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<ArrangementFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: ArrangementCountAggregateInputType | true
    }

  export interface ArrangementDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Arrangement'], meta: { name: 'Arrangement' } }
    /**
     * Find zero or one Arrangement that matches the filter.
     * @param {ArrangementFindUniqueArgs} args - Arguments to find a Arrangement
     * @example
     * // Get one Arrangement
     * const arrangement = await prisma.arrangement.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends ArrangementFindUniqueArgs>(args: SelectSubset<T, ArrangementFindUniqueArgs<ExtArgs>>): Prisma__ArrangementClient<$Result.GetResult<Prisma.$ArrangementPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Arrangement that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {ArrangementFindUniqueOrThrowArgs} args - Arguments to find a Arrangement
     * @example
     * // Get one Arrangement
     * const arrangement = await prisma.arrangement.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends ArrangementFindUniqueOrThrowArgs>(args: SelectSubset<T, ArrangementFindUniqueOrThrowArgs<ExtArgs>>): Prisma__ArrangementClient<$Result.GetResult<Prisma.$ArrangementPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Arrangement that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ArrangementFindFirstArgs} args - Arguments to find a Arrangement
     * @example
     * // Get one Arrangement
     * const arrangement = await prisma.arrangement.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends ArrangementFindFirstArgs>(args?: SelectSubset<T, ArrangementFindFirstArgs<ExtArgs>>): Prisma__ArrangementClient<$Result.GetResult<Prisma.$ArrangementPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Arrangement that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ArrangementFindFirstOrThrowArgs} args - Arguments to find a Arrangement
     * @example
     * // Get one Arrangement
     * const arrangement = await prisma.arrangement.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends ArrangementFindFirstOrThrowArgs>(args?: SelectSubset<T, ArrangementFindFirstOrThrowArgs<ExtArgs>>): Prisma__ArrangementClient<$Result.GetResult<Prisma.$ArrangementPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Arrangements that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ArrangementFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Arrangements
     * const arrangements = await prisma.arrangement.findMany()
     * 
     * // Get first 10 Arrangements
     * const arrangements = await prisma.arrangement.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const arrangementWithIdOnly = await prisma.arrangement.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends ArrangementFindManyArgs>(args?: SelectSubset<T, ArrangementFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ArrangementPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Arrangement.
     * @param {ArrangementCreateArgs} args - Arguments to create a Arrangement.
     * @example
     * // Create one Arrangement
     * const Arrangement = await prisma.arrangement.create({
     *   data: {
     *     // ... data to create a Arrangement
     *   }
     * })
     * 
     */
    create<T extends ArrangementCreateArgs>(args: SelectSubset<T, ArrangementCreateArgs<ExtArgs>>): Prisma__ArrangementClient<$Result.GetResult<Prisma.$ArrangementPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Arrangements.
     * @param {ArrangementCreateManyArgs} args - Arguments to create many Arrangements.
     * @example
     * // Create many Arrangements
     * const arrangement = await prisma.arrangement.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends ArrangementCreateManyArgs>(args?: SelectSubset<T, ArrangementCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Arrangements and returns the data saved in the database.
     * @param {ArrangementCreateManyAndReturnArgs} args - Arguments to create many Arrangements.
     * @example
     * // Create many Arrangements
     * const arrangement = await prisma.arrangement.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Arrangements and only return the `id`
     * const arrangementWithIdOnly = await prisma.arrangement.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends ArrangementCreateManyAndReturnArgs>(args?: SelectSubset<T, ArrangementCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ArrangementPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Arrangement.
     * @param {ArrangementDeleteArgs} args - Arguments to delete one Arrangement.
     * @example
     * // Delete one Arrangement
     * const Arrangement = await prisma.arrangement.delete({
     *   where: {
     *     // ... filter to delete one Arrangement
     *   }
     * })
     * 
     */
    delete<T extends ArrangementDeleteArgs>(args: SelectSubset<T, ArrangementDeleteArgs<ExtArgs>>): Prisma__ArrangementClient<$Result.GetResult<Prisma.$ArrangementPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Arrangement.
     * @param {ArrangementUpdateArgs} args - Arguments to update one Arrangement.
     * @example
     * // Update one Arrangement
     * const arrangement = await prisma.arrangement.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends ArrangementUpdateArgs>(args: SelectSubset<T, ArrangementUpdateArgs<ExtArgs>>): Prisma__ArrangementClient<$Result.GetResult<Prisma.$ArrangementPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Arrangements.
     * @param {ArrangementDeleteManyArgs} args - Arguments to filter Arrangements to delete.
     * @example
     * // Delete a few Arrangements
     * const { count } = await prisma.arrangement.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends ArrangementDeleteManyArgs>(args?: SelectSubset<T, ArrangementDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Arrangements.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ArrangementUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Arrangements
     * const arrangement = await prisma.arrangement.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends ArrangementUpdateManyArgs>(args: SelectSubset<T, ArrangementUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Arrangements and returns the data updated in the database.
     * @param {ArrangementUpdateManyAndReturnArgs} args - Arguments to update many Arrangements.
     * @example
     * // Update many Arrangements
     * const arrangement = await prisma.arrangement.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Arrangements and only return the `id`
     * const arrangementWithIdOnly = await prisma.arrangement.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends ArrangementUpdateManyAndReturnArgs>(args: SelectSubset<T, ArrangementUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ArrangementPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Arrangement.
     * @param {ArrangementUpsertArgs} args - Arguments to update or create a Arrangement.
     * @example
     * // Update or create a Arrangement
     * const arrangement = await prisma.arrangement.upsert({
     *   create: {
     *     // ... data to create a Arrangement
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Arrangement we want to update
     *   }
     * })
     */
    upsert<T extends ArrangementUpsertArgs>(args: SelectSubset<T, ArrangementUpsertArgs<ExtArgs>>): Prisma__ArrangementClient<$Result.GetResult<Prisma.$ArrangementPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Arrangements.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ArrangementCountArgs} args - Arguments to filter Arrangements to count.
     * @example
     * // Count the number of Arrangements
     * const count = await prisma.arrangement.count({
     *   where: {
     *     // ... the filter for the Arrangements we want to count
     *   }
     * })
    **/
    count<T extends ArrangementCountArgs>(
      args?: Subset<T, ArrangementCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], ArrangementCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Arrangement.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ArrangementAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ArrangementAggregateArgs>(args: Subset<T, ArrangementAggregateArgs>): Prisma.PrismaPromise<GetArrangementAggregateType<T>>

    /**
     * Group by Arrangement.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ArrangementGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends ArrangementGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: ArrangementGroupByArgs['orderBy'] }
        : { orderBy?: ArrangementGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, ArrangementGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetArrangementGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Arrangement model
   */
  readonly fields: ArrangementFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Arrangement.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__ArrangementClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Arrangement model
   */
  interface ArrangementFieldRefs {
    readonly id: FieldRef<"Arrangement", 'String'>
    readonly userId: FieldRef<"Arrangement", 'String'>
    readonly type: FieldRef<"Arrangement", 'String'>
    readonly vendor: FieldRef<"Arrangement", 'String'>
    readonly contact: FieldRef<"Arrangement", 'String'>
    readonly notes: FieldRef<"Arrangement", 'String'>
    readonly createdAt: FieldRef<"Arrangement", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Arrangement findUnique
   */
  export type ArrangementFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Arrangement
     */
    select?: ArrangementSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Arrangement
     */
    omit?: ArrangementOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ArrangementInclude<ExtArgs> | null
    /**
     * Filter, which Arrangement to fetch.
     */
    where: ArrangementWhereUniqueInput
  }

  /**
   * Arrangement findUniqueOrThrow
   */
  export type ArrangementFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Arrangement
     */
    select?: ArrangementSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Arrangement
     */
    omit?: ArrangementOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ArrangementInclude<ExtArgs> | null
    /**
     * Filter, which Arrangement to fetch.
     */
    where: ArrangementWhereUniqueInput
  }

  /**
   * Arrangement findFirst
   */
  export type ArrangementFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Arrangement
     */
    select?: ArrangementSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Arrangement
     */
    omit?: ArrangementOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ArrangementInclude<ExtArgs> | null
    /**
     * Filter, which Arrangement to fetch.
     */
    where?: ArrangementWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Arrangements to fetch.
     */
    orderBy?: ArrangementOrderByWithRelationInput | ArrangementOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Arrangements.
     */
    cursor?: ArrangementWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Arrangements from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Arrangements.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Arrangements.
     */
    distinct?: ArrangementScalarFieldEnum | ArrangementScalarFieldEnum[]
  }

  /**
   * Arrangement findFirstOrThrow
   */
  export type ArrangementFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Arrangement
     */
    select?: ArrangementSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Arrangement
     */
    omit?: ArrangementOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ArrangementInclude<ExtArgs> | null
    /**
     * Filter, which Arrangement to fetch.
     */
    where?: ArrangementWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Arrangements to fetch.
     */
    orderBy?: ArrangementOrderByWithRelationInput | ArrangementOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Arrangements.
     */
    cursor?: ArrangementWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Arrangements from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Arrangements.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Arrangements.
     */
    distinct?: ArrangementScalarFieldEnum | ArrangementScalarFieldEnum[]
  }

  /**
   * Arrangement findMany
   */
  export type ArrangementFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Arrangement
     */
    select?: ArrangementSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Arrangement
     */
    omit?: ArrangementOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ArrangementInclude<ExtArgs> | null
    /**
     * Filter, which Arrangements to fetch.
     */
    where?: ArrangementWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Arrangements to fetch.
     */
    orderBy?: ArrangementOrderByWithRelationInput | ArrangementOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Arrangements.
     */
    cursor?: ArrangementWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Arrangements from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Arrangements.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Arrangements.
     */
    distinct?: ArrangementScalarFieldEnum | ArrangementScalarFieldEnum[]
  }

  /**
   * Arrangement create
   */
  export type ArrangementCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Arrangement
     */
    select?: ArrangementSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Arrangement
     */
    omit?: ArrangementOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ArrangementInclude<ExtArgs> | null
    /**
     * The data needed to create a Arrangement.
     */
    data: XOR<ArrangementCreateInput, ArrangementUncheckedCreateInput>
  }

  /**
   * Arrangement createMany
   */
  export type ArrangementCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Arrangements.
     */
    data: ArrangementCreateManyInput | ArrangementCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Arrangement createManyAndReturn
   */
  export type ArrangementCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Arrangement
     */
    select?: ArrangementSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Arrangement
     */
    omit?: ArrangementOmit<ExtArgs> | null
    /**
     * The data used to create many Arrangements.
     */
    data: ArrangementCreateManyInput | ArrangementCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ArrangementIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * Arrangement update
   */
  export type ArrangementUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Arrangement
     */
    select?: ArrangementSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Arrangement
     */
    omit?: ArrangementOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ArrangementInclude<ExtArgs> | null
    /**
     * The data needed to update a Arrangement.
     */
    data: XOR<ArrangementUpdateInput, ArrangementUncheckedUpdateInput>
    /**
     * Choose, which Arrangement to update.
     */
    where: ArrangementWhereUniqueInput
  }

  /**
   * Arrangement updateMany
   */
  export type ArrangementUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Arrangements.
     */
    data: XOR<ArrangementUpdateManyMutationInput, ArrangementUncheckedUpdateManyInput>
    /**
     * Filter which Arrangements to update
     */
    where?: ArrangementWhereInput
    /**
     * Limit how many Arrangements to update.
     */
    limit?: number
  }

  /**
   * Arrangement updateManyAndReturn
   */
  export type ArrangementUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Arrangement
     */
    select?: ArrangementSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Arrangement
     */
    omit?: ArrangementOmit<ExtArgs> | null
    /**
     * The data used to update Arrangements.
     */
    data: XOR<ArrangementUpdateManyMutationInput, ArrangementUncheckedUpdateManyInput>
    /**
     * Filter which Arrangements to update
     */
    where?: ArrangementWhereInput
    /**
     * Limit how many Arrangements to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ArrangementIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * Arrangement upsert
   */
  export type ArrangementUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Arrangement
     */
    select?: ArrangementSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Arrangement
     */
    omit?: ArrangementOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ArrangementInclude<ExtArgs> | null
    /**
     * The filter to search for the Arrangement to update in case it exists.
     */
    where: ArrangementWhereUniqueInput
    /**
     * In case the Arrangement found by the `where` argument doesn't exist, create a new Arrangement with this data.
     */
    create: XOR<ArrangementCreateInput, ArrangementUncheckedCreateInput>
    /**
     * In case the Arrangement was found with the provided `where` argument, update it with this data.
     */
    update: XOR<ArrangementUpdateInput, ArrangementUncheckedUpdateInput>
  }

  /**
   * Arrangement delete
   */
  export type ArrangementDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Arrangement
     */
    select?: ArrangementSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Arrangement
     */
    omit?: ArrangementOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ArrangementInclude<ExtArgs> | null
    /**
     * Filter which Arrangement to delete.
     */
    where: ArrangementWhereUniqueInput
  }

  /**
   * Arrangement deleteMany
   */
  export type ArrangementDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Arrangements to delete
     */
    where?: ArrangementWhereInput
    /**
     * Limit how many Arrangements to delete.
     */
    limit?: number
  }

  /**
   * Arrangement without action
   */
  export type ArrangementDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Arrangement
     */
    select?: ArrangementSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Arrangement
     */
    omit?: ArrangementOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ArrangementInclude<ExtArgs> | null
  }


  /**
   * Model VaultItem
   */

  export type AggregateVaultItem = {
    _count: VaultItemCountAggregateOutputType | null
    _min: VaultItemMinAggregateOutputType | null
    _max: VaultItemMaxAggregateOutputType | null
  }

  export type VaultItemMinAggregateOutputType = {
    id: string | null
    userId: string | null
    label: string | null
    encryptedData: string | null
    createdAt: Date | null
  }

  export type VaultItemMaxAggregateOutputType = {
    id: string | null
    userId: string | null
    label: string | null
    encryptedData: string | null
    createdAt: Date | null
  }

  export type VaultItemCountAggregateOutputType = {
    id: number
    userId: number
    label: number
    encryptedData: number
    createdAt: number
    _all: number
  }


  export type VaultItemMinAggregateInputType = {
    id?: true
    userId?: true
    label?: true
    encryptedData?: true
    createdAt?: true
  }

  export type VaultItemMaxAggregateInputType = {
    id?: true
    userId?: true
    label?: true
    encryptedData?: true
    createdAt?: true
  }

  export type VaultItemCountAggregateInputType = {
    id?: true
    userId?: true
    label?: true
    encryptedData?: true
    createdAt?: true
    _all?: true
  }

  export type VaultItemAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which VaultItem to aggregate.
     */
    where?: VaultItemWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of VaultItems to fetch.
     */
    orderBy?: VaultItemOrderByWithRelationInput | VaultItemOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: VaultItemWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` VaultItems from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` VaultItems.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned VaultItems
    **/
    _count?: true | VaultItemCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: VaultItemMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: VaultItemMaxAggregateInputType
  }

  export type GetVaultItemAggregateType<T extends VaultItemAggregateArgs> = {
        [P in keyof T & keyof AggregateVaultItem]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateVaultItem[P]>
      : GetScalarType<T[P], AggregateVaultItem[P]>
  }




  export type VaultItemGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: VaultItemWhereInput
    orderBy?: VaultItemOrderByWithAggregationInput | VaultItemOrderByWithAggregationInput[]
    by: VaultItemScalarFieldEnum[] | VaultItemScalarFieldEnum
    having?: VaultItemScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: VaultItemCountAggregateInputType | true
    _min?: VaultItemMinAggregateInputType
    _max?: VaultItemMaxAggregateInputType
  }

  export type VaultItemGroupByOutputType = {
    id: string
    userId: string
    label: string
    encryptedData: string
    createdAt: Date
    _count: VaultItemCountAggregateOutputType | null
    _min: VaultItemMinAggregateOutputType | null
    _max: VaultItemMaxAggregateOutputType | null
  }

  type GetVaultItemGroupByPayload<T extends VaultItemGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<VaultItemGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof VaultItemGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], VaultItemGroupByOutputType[P]>
            : GetScalarType<T[P], VaultItemGroupByOutputType[P]>
        }
      >
    >


  export type VaultItemSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    label?: boolean
    encryptedData?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["vaultItem"]>

  export type VaultItemSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    label?: boolean
    encryptedData?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["vaultItem"]>

  export type VaultItemSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    label?: boolean
    encryptedData?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["vaultItem"]>

  export type VaultItemSelectScalar = {
    id?: boolean
    userId?: boolean
    label?: boolean
    encryptedData?: boolean
    createdAt?: boolean
  }

  export type VaultItemOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "userId" | "label" | "encryptedData" | "createdAt", ExtArgs["result"]["vaultItem"]>
  export type VaultItemInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }
  export type VaultItemIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }
  export type VaultItemIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }

  export type $VaultItemPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "VaultItem"
    objects: {
      user: Prisma.$UserPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      userId: string
      label: string
      encryptedData: string
      createdAt: Date
    }, ExtArgs["result"]["vaultItem"]>
    composites: {}
  }

  type VaultItemGetPayload<S extends boolean | null | undefined | VaultItemDefaultArgs> = $Result.GetResult<Prisma.$VaultItemPayload, S>

  type VaultItemCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<VaultItemFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: VaultItemCountAggregateInputType | true
    }

  export interface VaultItemDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['VaultItem'], meta: { name: 'VaultItem' } }
    /**
     * Find zero or one VaultItem that matches the filter.
     * @param {VaultItemFindUniqueArgs} args - Arguments to find a VaultItem
     * @example
     * // Get one VaultItem
     * const vaultItem = await prisma.vaultItem.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends VaultItemFindUniqueArgs>(args: SelectSubset<T, VaultItemFindUniqueArgs<ExtArgs>>): Prisma__VaultItemClient<$Result.GetResult<Prisma.$VaultItemPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one VaultItem that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {VaultItemFindUniqueOrThrowArgs} args - Arguments to find a VaultItem
     * @example
     * // Get one VaultItem
     * const vaultItem = await prisma.vaultItem.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends VaultItemFindUniqueOrThrowArgs>(args: SelectSubset<T, VaultItemFindUniqueOrThrowArgs<ExtArgs>>): Prisma__VaultItemClient<$Result.GetResult<Prisma.$VaultItemPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first VaultItem that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VaultItemFindFirstArgs} args - Arguments to find a VaultItem
     * @example
     * // Get one VaultItem
     * const vaultItem = await prisma.vaultItem.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends VaultItemFindFirstArgs>(args?: SelectSubset<T, VaultItemFindFirstArgs<ExtArgs>>): Prisma__VaultItemClient<$Result.GetResult<Prisma.$VaultItemPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first VaultItem that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VaultItemFindFirstOrThrowArgs} args - Arguments to find a VaultItem
     * @example
     * // Get one VaultItem
     * const vaultItem = await prisma.vaultItem.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends VaultItemFindFirstOrThrowArgs>(args?: SelectSubset<T, VaultItemFindFirstOrThrowArgs<ExtArgs>>): Prisma__VaultItemClient<$Result.GetResult<Prisma.$VaultItemPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more VaultItems that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VaultItemFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all VaultItems
     * const vaultItems = await prisma.vaultItem.findMany()
     * 
     * // Get first 10 VaultItems
     * const vaultItems = await prisma.vaultItem.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const vaultItemWithIdOnly = await prisma.vaultItem.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends VaultItemFindManyArgs>(args?: SelectSubset<T, VaultItemFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$VaultItemPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a VaultItem.
     * @param {VaultItemCreateArgs} args - Arguments to create a VaultItem.
     * @example
     * // Create one VaultItem
     * const VaultItem = await prisma.vaultItem.create({
     *   data: {
     *     // ... data to create a VaultItem
     *   }
     * })
     * 
     */
    create<T extends VaultItemCreateArgs>(args: SelectSubset<T, VaultItemCreateArgs<ExtArgs>>): Prisma__VaultItemClient<$Result.GetResult<Prisma.$VaultItemPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many VaultItems.
     * @param {VaultItemCreateManyArgs} args - Arguments to create many VaultItems.
     * @example
     * // Create many VaultItems
     * const vaultItem = await prisma.vaultItem.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends VaultItemCreateManyArgs>(args?: SelectSubset<T, VaultItemCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many VaultItems and returns the data saved in the database.
     * @param {VaultItemCreateManyAndReturnArgs} args - Arguments to create many VaultItems.
     * @example
     * // Create many VaultItems
     * const vaultItem = await prisma.vaultItem.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many VaultItems and only return the `id`
     * const vaultItemWithIdOnly = await prisma.vaultItem.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends VaultItemCreateManyAndReturnArgs>(args?: SelectSubset<T, VaultItemCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$VaultItemPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a VaultItem.
     * @param {VaultItemDeleteArgs} args - Arguments to delete one VaultItem.
     * @example
     * // Delete one VaultItem
     * const VaultItem = await prisma.vaultItem.delete({
     *   where: {
     *     // ... filter to delete one VaultItem
     *   }
     * })
     * 
     */
    delete<T extends VaultItemDeleteArgs>(args: SelectSubset<T, VaultItemDeleteArgs<ExtArgs>>): Prisma__VaultItemClient<$Result.GetResult<Prisma.$VaultItemPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one VaultItem.
     * @param {VaultItemUpdateArgs} args - Arguments to update one VaultItem.
     * @example
     * // Update one VaultItem
     * const vaultItem = await prisma.vaultItem.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends VaultItemUpdateArgs>(args: SelectSubset<T, VaultItemUpdateArgs<ExtArgs>>): Prisma__VaultItemClient<$Result.GetResult<Prisma.$VaultItemPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more VaultItems.
     * @param {VaultItemDeleteManyArgs} args - Arguments to filter VaultItems to delete.
     * @example
     * // Delete a few VaultItems
     * const { count } = await prisma.vaultItem.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends VaultItemDeleteManyArgs>(args?: SelectSubset<T, VaultItemDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more VaultItems.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VaultItemUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many VaultItems
     * const vaultItem = await prisma.vaultItem.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends VaultItemUpdateManyArgs>(args: SelectSubset<T, VaultItemUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more VaultItems and returns the data updated in the database.
     * @param {VaultItemUpdateManyAndReturnArgs} args - Arguments to update many VaultItems.
     * @example
     * // Update many VaultItems
     * const vaultItem = await prisma.vaultItem.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more VaultItems and only return the `id`
     * const vaultItemWithIdOnly = await prisma.vaultItem.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends VaultItemUpdateManyAndReturnArgs>(args: SelectSubset<T, VaultItemUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$VaultItemPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one VaultItem.
     * @param {VaultItemUpsertArgs} args - Arguments to update or create a VaultItem.
     * @example
     * // Update or create a VaultItem
     * const vaultItem = await prisma.vaultItem.upsert({
     *   create: {
     *     // ... data to create a VaultItem
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the VaultItem we want to update
     *   }
     * })
     */
    upsert<T extends VaultItemUpsertArgs>(args: SelectSubset<T, VaultItemUpsertArgs<ExtArgs>>): Prisma__VaultItemClient<$Result.GetResult<Prisma.$VaultItemPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of VaultItems.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VaultItemCountArgs} args - Arguments to filter VaultItems to count.
     * @example
     * // Count the number of VaultItems
     * const count = await prisma.vaultItem.count({
     *   where: {
     *     // ... the filter for the VaultItems we want to count
     *   }
     * })
    **/
    count<T extends VaultItemCountArgs>(
      args?: Subset<T, VaultItemCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], VaultItemCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a VaultItem.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VaultItemAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends VaultItemAggregateArgs>(args: Subset<T, VaultItemAggregateArgs>): Prisma.PrismaPromise<GetVaultItemAggregateType<T>>

    /**
     * Group by VaultItem.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {VaultItemGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends VaultItemGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: VaultItemGroupByArgs['orderBy'] }
        : { orderBy?: VaultItemGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, VaultItemGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetVaultItemGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the VaultItem model
   */
  readonly fields: VaultItemFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for VaultItem.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__VaultItemClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the VaultItem model
   */
  interface VaultItemFieldRefs {
    readonly id: FieldRef<"VaultItem", 'String'>
    readonly userId: FieldRef<"VaultItem", 'String'>
    readonly label: FieldRef<"VaultItem", 'String'>
    readonly encryptedData: FieldRef<"VaultItem", 'String'>
    readonly createdAt: FieldRef<"VaultItem", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * VaultItem findUnique
   */
  export type VaultItemFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VaultItem
     */
    select?: VaultItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VaultItem
     */
    omit?: VaultItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VaultItemInclude<ExtArgs> | null
    /**
     * Filter, which VaultItem to fetch.
     */
    where: VaultItemWhereUniqueInput
  }

  /**
   * VaultItem findUniqueOrThrow
   */
  export type VaultItemFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VaultItem
     */
    select?: VaultItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VaultItem
     */
    omit?: VaultItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VaultItemInclude<ExtArgs> | null
    /**
     * Filter, which VaultItem to fetch.
     */
    where: VaultItemWhereUniqueInput
  }

  /**
   * VaultItem findFirst
   */
  export type VaultItemFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VaultItem
     */
    select?: VaultItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VaultItem
     */
    omit?: VaultItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VaultItemInclude<ExtArgs> | null
    /**
     * Filter, which VaultItem to fetch.
     */
    where?: VaultItemWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of VaultItems to fetch.
     */
    orderBy?: VaultItemOrderByWithRelationInput | VaultItemOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for VaultItems.
     */
    cursor?: VaultItemWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` VaultItems from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` VaultItems.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of VaultItems.
     */
    distinct?: VaultItemScalarFieldEnum | VaultItemScalarFieldEnum[]
  }

  /**
   * VaultItem findFirstOrThrow
   */
  export type VaultItemFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VaultItem
     */
    select?: VaultItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VaultItem
     */
    omit?: VaultItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VaultItemInclude<ExtArgs> | null
    /**
     * Filter, which VaultItem to fetch.
     */
    where?: VaultItemWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of VaultItems to fetch.
     */
    orderBy?: VaultItemOrderByWithRelationInput | VaultItemOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for VaultItems.
     */
    cursor?: VaultItemWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` VaultItems from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` VaultItems.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of VaultItems.
     */
    distinct?: VaultItemScalarFieldEnum | VaultItemScalarFieldEnum[]
  }

  /**
   * VaultItem findMany
   */
  export type VaultItemFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VaultItem
     */
    select?: VaultItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VaultItem
     */
    omit?: VaultItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VaultItemInclude<ExtArgs> | null
    /**
     * Filter, which VaultItems to fetch.
     */
    where?: VaultItemWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of VaultItems to fetch.
     */
    orderBy?: VaultItemOrderByWithRelationInput | VaultItemOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing VaultItems.
     */
    cursor?: VaultItemWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` VaultItems from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` VaultItems.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of VaultItems.
     */
    distinct?: VaultItemScalarFieldEnum | VaultItemScalarFieldEnum[]
  }

  /**
   * VaultItem create
   */
  export type VaultItemCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VaultItem
     */
    select?: VaultItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VaultItem
     */
    omit?: VaultItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VaultItemInclude<ExtArgs> | null
    /**
     * The data needed to create a VaultItem.
     */
    data: XOR<VaultItemCreateInput, VaultItemUncheckedCreateInput>
  }

  /**
   * VaultItem createMany
   */
  export type VaultItemCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many VaultItems.
     */
    data: VaultItemCreateManyInput | VaultItemCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * VaultItem createManyAndReturn
   */
  export type VaultItemCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VaultItem
     */
    select?: VaultItemSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the VaultItem
     */
    omit?: VaultItemOmit<ExtArgs> | null
    /**
     * The data used to create many VaultItems.
     */
    data: VaultItemCreateManyInput | VaultItemCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VaultItemIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * VaultItem update
   */
  export type VaultItemUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VaultItem
     */
    select?: VaultItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VaultItem
     */
    omit?: VaultItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VaultItemInclude<ExtArgs> | null
    /**
     * The data needed to update a VaultItem.
     */
    data: XOR<VaultItemUpdateInput, VaultItemUncheckedUpdateInput>
    /**
     * Choose, which VaultItem to update.
     */
    where: VaultItemWhereUniqueInput
  }

  /**
   * VaultItem updateMany
   */
  export type VaultItemUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update VaultItems.
     */
    data: XOR<VaultItemUpdateManyMutationInput, VaultItemUncheckedUpdateManyInput>
    /**
     * Filter which VaultItems to update
     */
    where?: VaultItemWhereInput
    /**
     * Limit how many VaultItems to update.
     */
    limit?: number
  }

  /**
   * VaultItem updateManyAndReturn
   */
  export type VaultItemUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VaultItem
     */
    select?: VaultItemSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the VaultItem
     */
    omit?: VaultItemOmit<ExtArgs> | null
    /**
     * The data used to update VaultItems.
     */
    data: XOR<VaultItemUpdateManyMutationInput, VaultItemUncheckedUpdateManyInput>
    /**
     * Filter which VaultItems to update
     */
    where?: VaultItemWhereInput
    /**
     * Limit how many VaultItems to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VaultItemIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * VaultItem upsert
   */
  export type VaultItemUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VaultItem
     */
    select?: VaultItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VaultItem
     */
    omit?: VaultItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VaultItemInclude<ExtArgs> | null
    /**
     * The filter to search for the VaultItem to update in case it exists.
     */
    where: VaultItemWhereUniqueInput
    /**
     * In case the VaultItem found by the `where` argument doesn't exist, create a new VaultItem with this data.
     */
    create: XOR<VaultItemCreateInput, VaultItemUncheckedCreateInput>
    /**
     * In case the VaultItem was found with the provided `where` argument, update it with this data.
     */
    update: XOR<VaultItemUpdateInput, VaultItemUncheckedUpdateInput>
  }

  /**
   * VaultItem delete
   */
  export type VaultItemDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VaultItem
     */
    select?: VaultItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VaultItem
     */
    omit?: VaultItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VaultItemInclude<ExtArgs> | null
    /**
     * Filter which VaultItem to delete.
     */
    where: VaultItemWhereUniqueInput
  }

  /**
   * VaultItem deleteMany
   */
  export type VaultItemDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which VaultItems to delete
     */
    where?: VaultItemWhereInput
    /**
     * Limit how many VaultItems to delete.
     */
    limit?: number
  }

  /**
   * VaultItem without action
   */
  export type VaultItemDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the VaultItem
     */
    select?: VaultItemSelect<ExtArgs> | null
    /**
     * Omit specific fields from the VaultItem
     */
    omit?: VaultItemOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: VaultItemInclude<ExtArgs> | null
  }


  /**
   * Model Executor
   */

  export type AggregateExecutor = {
    _count: ExecutorCountAggregateOutputType | null
    _min: ExecutorMinAggregateOutputType | null
    _max: ExecutorMaxAggregateOutputType | null
  }

  export type ExecutorMinAggregateOutputType = {
    id: string | null
    userId: string | null
    name: string | null
    email: string | null
    phone: string | null
    verified: boolean | null
    certUploadedAt: Date | null
    unlockedAt: Date | null
    createdAt: Date | null
  }

  export type ExecutorMaxAggregateOutputType = {
    id: string | null
    userId: string | null
    name: string | null
    email: string | null
    phone: string | null
    verified: boolean | null
    certUploadedAt: Date | null
    unlockedAt: Date | null
    createdAt: Date | null
  }

  export type ExecutorCountAggregateOutputType = {
    id: number
    userId: number
    name: number
    email: number
    phone: number
    verified: number
    certUploadedAt: number
    unlockedAt: number
    createdAt: number
    _all: number
  }


  export type ExecutorMinAggregateInputType = {
    id?: true
    userId?: true
    name?: true
    email?: true
    phone?: true
    verified?: true
    certUploadedAt?: true
    unlockedAt?: true
    createdAt?: true
  }

  export type ExecutorMaxAggregateInputType = {
    id?: true
    userId?: true
    name?: true
    email?: true
    phone?: true
    verified?: true
    certUploadedAt?: true
    unlockedAt?: true
    createdAt?: true
  }

  export type ExecutorCountAggregateInputType = {
    id?: true
    userId?: true
    name?: true
    email?: true
    phone?: true
    verified?: true
    certUploadedAt?: true
    unlockedAt?: true
    createdAt?: true
    _all?: true
  }

  export type ExecutorAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Executor to aggregate.
     */
    where?: ExecutorWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Executors to fetch.
     */
    orderBy?: ExecutorOrderByWithRelationInput | ExecutorOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: ExecutorWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Executors from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Executors.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Executors
    **/
    _count?: true | ExecutorCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: ExecutorMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: ExecutorMaxAggregateInputType
  }

  export type GetExecutorAggregateType<T extends ExecutorAggregateArgs> = {
        [P in keyof T & keyof AggregateExecutor]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateExecutor[P]>
      : GetScalarType<T[P], AggregateExecutor[P]>
  }




  export type ExecutorGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: ExecutorWhereInput
    orderBy?: ExecutorOrderByWithAggregationInput | ExecutorOrderByWithAggregationInput[]
    by: ExecutorScalarFieldEnum[] | ExecutorScalarFieldEnum
    having?: ExecutorScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: ExecutorCountAggregateInputType | true
    _min?: ExecutorMinAggregateInputType
    _max?: ExecutorMaxAggregateInputType
  }

  export type ExecutorGroupByOutputType = {
    id: string
    userId: string
    name: string
    email: string
    phone: string | null
    verified: boolean
    certUploadedAt: Date | null
    unlockedAt: Date | null
    createdAt: Date
    _count: ExecutorCountAggregateOutputType | null
    _min: ExecutorMinAggregateOutputType | null
    _max: ExecutorMaxAggregateOutputType | null
  }

  type GetExecutorGroupByPayload<T extends ExecutorGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<ExecutorGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof ExecutorGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], ExecutorGroupByOutputType[P]>
            : GetScalarType<T[P], ExecutorGroupByOutputType[P]>
        }
      >
    >


  export type ExecutorSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    name?: boolean
    email?: boolean
    phone?: boolean
    verified?: boolean
    certUploadedAt?: boolean
    unlockedAt?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["executor"]>

  export type ExecutorSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    name?: boolean
    email?: boolean
    phone?: boolean
    verified?: boolean
    certUploadedAt?: boolean
    unlockedAt?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["executor"]>

  export type ExecutorSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    name?: boolean
    email?: boolean
    phone?: boolean
    verified?: boolean
    certUploadedAt?: boolean
    unlockedAt?: boolean
    createdAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["executor"]>

  export type ExecutorSelectScalar = {
    id?: boolean
    userId?: boolean
    name?: boolean
    email?: boolean
    phone?: boolean
    verified?: boolean
    certUploadedAt?: boolean
    unlockedAt?: boolean
    createdAt?: boolean
  }

  export type ExecutorOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "userId" | "name" | "email" | "phone" | "verified" | "certUploadedAt" | "unlockedAt" | "createdAt", ExtArgs["result"]["executor"]>
  export type ExecutorInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }
  export type ExecutorIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }
  export type ExecutorIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }

  export type $ExecutorPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Executor"
    objects: {
      user: Prisma.$UserPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      userId: string
      name: string
      email: string
      phone: string | null
      verified: boolean
      certUploadedAt: Date | null
      unlockedAt: Date | null
      createdAt: Date
    }, ExtArgs["result"]["executor"]>
    composites: {}
  }

  type ExecutorGetPayload<S extends boolean | null | undefined | ExecutorDefaultArgs> = $Result.GetResult<Prisma.$ExecutorPayload, S>

  type ExecutorCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<ExecutorFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: ExecutorCountAggregateInputType | true
    }

  export interface ExecutorDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Executor'], meta: { name: 'Executor' } }
    /**
     * Find zero or one Executor that matches the filter.
     * @param {ExecutorFindUniqueArgs} args - Arguments to find a Executor
     * @example
     * // Get one Executor
     * const executor = await prisma.executor.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends ExecutorFindUniqueArgs>(args: SelectSubset<T, ExecutorFindUniqueArgs<ExtArgs>>): Prisma__ExecutorClient<$Result.GetResult<Prisma.$ExecutorPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Executor that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {ExecutorFindUniqueOrThrowArgs} args - Arguments to find a Executor
     * @example
     * // Get one Executor
     * const executor = await prisma.executor.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends ExecutorFindUniqueOrThrowArgs>(args: SelectSubset<T, ExecutorFindUniqueOrThrowArgs<ExtArgs>>): Prisma__ExecutorClient<$Result.GetResult<Prisma.$ExecutorPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Executor that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExecutorFindFirstArgs} args - Arguments to find a Executor
     * @example
     * // Get one Executor
     * const executor = await prisma.executor.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends ExecutorFindFirstArgs>(args?: SelectSubset<T, ExecutorFindFirstArgs<ExtArgs>>): Prisma__ExecutorClient<$Result.GetResult<Prisma.$ExecutorPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Executor that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExecutorFindFirstOrThrowArgs} args - Arguments to find a Executor
     * @example
     * // Get one Executor
     * const executor = await prisma.executor.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends ExecutorFindFirstOrThrowArgs>(args?: SelectSubset<T, ExecutorFindFirstOrThrowArgs<ExtArgs>>): Prisma__ExecutorClient<$Result.GetResult<Prisma.$ExecutorPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Executors that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExecutorFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Executors
     * const executors = await prisma.executor.findMany()
     * 
     * // Get first 10 Executors
     * const executors = await prisma.executor.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const executorWithIdOnly = await prisma.executor.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends ExecutorFindManyArgs>(args?: SelectSubset<T, ExecutorFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ExecutorPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Executor.
     * @param {ExecutorCreateArgs} args - Arguments to create a Executor.
     * @example
     * // Create one Executor
     * const Executor = await prisma.executor.create({
     *   data: {
     *     // ... data to create a Executor
     *   }
     * })
     * 
     */
    create<T extends ExecutorCreateArgs>(args: SelectSubset<T, ExecutorCreateArgs<ExtArgs>>): Prisma__ExecutorClient<$Result.GetResult<Prisma.$ExecutorPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Executors.
     * @param {ExecutorCreateManyArgs} args - Arguments to create many Executors.
     * @example
     * // Create many Executors
     * const executor = await prisma.executor.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends ExecutorCreateManyArgs>(args?: SelectSubset<T, ExecutorCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Executors and returns the data saved in the database.
     * @param {ExecutorCreateManyAndReturnArgs} args - Arguments to create many Executors.
     * @example
     * // Create many Executors
     * const executor = await prisma.executor.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Executors and only return the `id`
     * const executorWithIdOnly = await prisma.executor.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends ExecutorCreateManyAndReturnArgs>(args?: SelectSubset<T, ExecutorCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ExecutorPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Executor.
     * @param {ExecutorDeleteArgs} args - Arguments to delete one Executor.
     * @example
     * // Delete one Executor
     * const Executor = await prisma.executor.delete({
     *   where: {
     *     // ... filter to delete one Executor
     *   }
     * })
     * 
     */
    delete<T extends ExecutorDeleteArgs>(args: SelectSubset<T, ExecutorDeleteArgs<ExtArgs>>): Prisma__ExecutorClient<$Result.GetResult<Prisma.$ExecutorPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Executor.
     * @param {ExecutorUpdateArgs} args - Arguments to update one Executor.
     * @example
     * // Update one Executor
     * const executor = await prisma.executor.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends ExecutorUpdateArgs>(args: SelectSubset<T, ExecutorUpdateArgs<ExtArgs>>): Prisma__ExecutorClient<$Result.GetResult<Prisma.$ExecutorPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Executors.
     * @param {ExecutorDeleteManyArgs} args - Arguments to filter Executors to delete.
     * @example
     * // Delete a few Executors
     * const { count } = await prisma.executor.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends ExecutorDeleteManyArgs>(args?: SelectSubset<T, ExecutorDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Executors.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExecutorUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Executors
     * const executor = await prisma.executor.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends ExecutorUpdateManyArgs>(args: SelectSubset<T, ExecutorUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Executors and returns the data updated in the database.
     * @param {ExecutorUpdateManyAndReturnArgs} args - Arguments to update many Executors.
     * @example
     * // Update many Executors
     * const executor = await prisma.executor.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Executors and only return the `id`
     * const executorWithIdOnly = await prisma.executor.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends ExecutorUpdateManyAndReturnArgs>(args: SelectSubset<T, ExecutorUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$ExecutorPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Executor.
     * @param {ExecutorUpsertArgs} args - Arguments to update or create a Executor.
     * @example
     * // Update or create a Executor
     * const executor = await prisma.executor.upsert({
     *   create: {
     *     // ... data to create a Executor
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Executor we want to update
     *   }
     * })
     */
    upsert<T extends ExecutorUpsertArgs>(args: SelectSubset<T, ExecutorUpsertArgs<ExtArgs>>): Prisma__ExecutorClient<$Result.GetResult<Prisma.$ExecutorPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Executors.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExecutorCountArgs} args - Arguments to filter Executors to count.
     * @example
     * // Count the number of Executors
     * const count = await prisma.executor.count({
     *   where: {
     *     // ... the filter for the Executors we want to count
     *   }
     * })
    **/
    count<T extends ExecutorCountArgs>(
      args?: Subset<T, ExecutorCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], ExecutorCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Executor.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExecutorAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends ExecutorAggregateArgs>(args: Subset<T, ExecutorAggregateArgs>): Prisma.PrismaPromise<GetExecutorAggregateType<T>>

    /**
     * Group by Executor.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {ExecutorGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends ExecutorGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: ExecutorGroupByArgs['orderBy'] }
        : { orderBy?: ExecutorGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, ExecutorGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetExecutorGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Executor model
   */
  readonly fields: ExecutorFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Executor.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__ExecutorClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Executor model
   */
  interface ExecutorFieldRefs {
    readonly id: FieldRef<"Executor", 'String'>
    readonly userId: FieldRef<"Executor", 'String'>
    readonly name: FieldRef<"Executor", 'String'>
    readonly email: FieldRef<"Executor", 'String'>
    readonly phone: FieldRef<"Executor", 'String'>
    readonly verified: FieldRef<"Executor", 'Boolean'>
    readonly certUploadedAt: FieldRef<"Executor", 'DateTime'>
    readonly unlockedAt: FieldRef<"Executor", 'DateTime'>
    readonly createdAt: FieldRef<"Executor", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Executor findUnique
   */
  export type ExecutorFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Executor
     */
    select?: ExecutorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Executor
     */
    omit?: ExecutorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExecutorInclude<ExtArgs> | null
    /**
     * Filter, which Executor to fetch.
     */
    where: ExecutorWhereUniqueInput
  }

  /**
   * Executor findUniqueOrThrow
   */
  export type ExecutorFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Executor
     */
    select?: ExecutorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Executor
     */
    omit?: ExecutorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExecutorInclude<ExtArgs> | null
    /**
     * Filter, which Executor to fetch.
     */
    where: ExecutorWhereUniqueInput
  }

  /**
   * Executor findFirst
   */
  export type ExecutorFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Executor
     */
    select?: ExecutorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Executor
     */
    omit?: ExecutorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExecutorInclude<ExtArgs> | null
    /**
     * Filter, which Executor to fetch.
     */
    where?: ExecutorWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Executors to fetch.
     */
    orderBy?: ExecutorOrderByWithRelationInput | ExecutorOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Executors.
     */
    cursor?: ExecutorWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Executors from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Executors.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Executors.
     */
    distinct?: ExecutorScalarFieldEnum | ExecutorScalarFieldEnum[]
  }

  /**
   * Executor findFirstOrThrow
   */
  export type ExecutorFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Executor
     */
    select?: ExecutorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Executor
     */
    omit?: ExecutorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExecutorInclude<ExtArgs> | null
    /**
     * Filter, which Executor to fetch.
     */
    where?: ExecutorWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Executors to fetch.
     */
    orderBy?: ExecutorOrderByWithRelationInput | ExecutorOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Executors.
     */
    cursor?: ExecutorWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Executors from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Executors.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Executors.
     */
    distinct?: ExecutorScalarFieldEnum | ExecutorScalarFieldEnum[]
  }

  /**
   * Executor findMany
   */
  export type ExecutorFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Executor
     */
    select?: ExecutorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Executor
     */
    omit?: ExecutorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExecutorInclude<ExtArgs> | null
    /**
     * Filter, which Executors to fetch.
     */
    where?: ExecutorWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Executors to fetch.
     */
    orderBy?: ExecutorOrderByWithRelationInput | ExecutorOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Executors.
     */
    cursor?: ExecutorWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Executors from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Executors.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Executors.
     */
    distinct?: ExecutorScalarFieldEnum | ExecutorScalarFieldEnum[]
  }

  /**
   * Executor create
   */
  export type ExecutorCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Executor
     */
    select?: ExecutorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Executor
     */
    omit?: ExecutorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExecutorInclude<ExtArgs> | null
    /**
     * The data needed to create a Executor.
     */
    data: XOR<ExecutorCreateInput, ExecutorUncheckedCreateInput>
  }

  /**
   * Executor createMany
   */
  export type ExecutorCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Executors.
     */
    data: ExecutorCreateManyInput | ExecutorCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Executor createManyAndReturn
   */
  export type ExecutorCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Executor
     */
    select?: ExecutorSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Executor
     */
    omit?: ExecutorOmit<ExtArgs> | null
    /**
     * The data used to create many Executors.
     */
    data: ExecutorCreateManyInput | ExecutorCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExecutorIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * Executor update
   */
  export type ExecutorUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Executor
     */
    select?: ExecutorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Executor
     */
    omit?: ExecutorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExecutorInclude<ExtArgs> | null
    /**
     * The data needed to update a Executor.
     */
    data: XOR<ExecutorUpdateInput, ExecutorUncheckedUpdateInput>
    /**
     * Choose, which Executor to update.
     */
    where: ExecutorWhereUniqueInput
  }

  /**
   * Executor updateMany
   */
  export type ExecutorUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Executors.
     */
    data: XOR<ExecutorUpdateManyMutationInput, ExecutorUncheckedUpdateManyInput>
    /**
     * Filter which Executors to update
     */
    where?: ExecutorWhereInput
    /**
     * Limit how many Executors to update.
     */
    limit?: number
  }

  /**
   * Executor updateManyAndReturn
   */
  export type ExecutorUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Executor
     */
    select?: ExecutorSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Executor
     */
    omit?: ExecutorOmit<ExtArgs> | null
    /**
     * The data used to update Executors.
     */
    data: XOR<ExecutorUpdateManyMutationInput, ExecutorUncheckedUpdateManyInput>
    /**
     * Filter which Executors to update
     */
    where?: ExecutorWhereInput
    /**
     * Limit how many Executors to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExecutorIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * Executor upsert
   */
  export type ExecutorUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Executor
     */
    select?: ExecutorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Executor
     */
    omit?: ExecutorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExecutorInclude<ExtArgs> | null
    /**
     * The filter to search for the Executor to update in case it exists.
     */
    where: ExecutorWhereUniqueInput
    /**
     * In case the Executor found by the `where` argument doesn't exist, create a new Executor with this data.
     */
    create: XOR<ExecutorCreateInput, ExecutorUncheckedCreateInput>
    /**
     * In case the Executor was found with the provided `where` argument, update it with this data.
     */
    update: XOR<ExecutorUpdateInput, ExecutorUncheckedUpdateInput>
  }

  /**
   * Executor delete
   */
  export type ExecutorDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Executor
     */
    select?: ExecutorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Executor
     */
    omit?: ExecutorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExecutorInclude<ExtArgs> | null
    /**
     * Filter which Executor to delete.
     */
    where: ExecutorWhereUniqueInput
  }

  /**
   * Executor deleteMany
   */
  export type ExecutorDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Executors to delete
     */
    where?: ExecutorWhereInput
    /**
     * Limit how many Executors to delete.
     */
    limit?: number
  }

  /**
   * Executor without action
   */
  export type ExecutorDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Executor
     */
    select?: ExecutorSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Executor
     */
    omit?: ExecutorOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: ExecutorInclude<ExtArgs> | null
  }


  /**
   * Model Settings
   */

  export type AggregateSettings = {
    _count: SettingsCountAggregateOutputType | null
    _min: SettingsMinAggregateOutputType | null
    _max: SettingsMaxAggregateOutputType | null
  }

  export type SettingsMinAggregateOutputType = {
    id: string | null
    userId: string | null
    pageTurnStyle: string | null
    fontScale: string | null
    highContrast: boolean | null
    ttsEnabled: boolean | null
    sttEnabled: boolean | null
    reducedMotion: boolean | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type SettingsMaxAggregateOutputType = {
    id: string | null
    userId: string | null
    pageTurnStyle: string | null
    fontScale: string | null
    highContrast: boolean | null
    ttsEnabled: boolean | null
    sttEnabled: boolean | null
    reducedMotion: boolean | null
    createdAt: Date | null
    updatedAt: Date | null
  }

  export type SettingsCountAggregateOutputType = {
    id: number
    userId: number
    pageTurnStyle: number
    fontScale: number
    highContrast: number
    ttsEnabled: number
    sttEnabled: number
    reducedMotion: number
    createdAt: number
    updatedAt: number
    _all: number
  }


  export type SettingsMinAggregateInputType = {
    id?: true
    userId?: true
    pageTurnStyle?: true
    fontScale?: true
    highContrast?: true
    ttsEnabled?: true
    sttEnabled?: true
    reducedMotion?: true
    createdAt?: true
    updatedAt?: true
  }

  export type SettingsMaxAggregateInputType = {
    id?: true
    userId?: true
    pageTurnStyle?: true
    fontScale?: true
    highContrast?: true
    ttsEnabled?: true
    sttEnabled?: true
    reducedMotion?: true
    createdAt?: true
    updatedAt?: true
  }

  export type SettingsCountAggregateInputType = {
    id?: true
    userId?: true
    pageTurnStyle?: true
    fontScale?: true
    highContrast?: true
    ttsEnabled?: true
    sttEnabled?: true
    reducedMotion?: true
    createdAt?: true
    updatedAt?: true
    _all?: true
  }

  export type SettingsAggregateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Settings to aggregate.
     */
    where?: SettingsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Settings to fetch.
     */
    orderBy?: SettingsOrderByWithRelationInput | SettingsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the start position
     */
    cursor?: SettingsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Settings from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Settings.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Count returned Settings
    **/
    _count?: true | SettingsCountAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the minimum value
    **/
    _min?: SettingsMinAggregateInputType
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/aggregations Aggregation Docs}
     * 
     * Select which fields to find the maximum value
    **/
    _max?: SettingsMaxAggregateInputType
  }

  export type GetSettingsAggregateType<T extends SettingsAggregateArgs> = {
        [P in keyof T & keyof AggregateSettings]: P extends '_count' | 'count'
      ? T[P] extends true
        ? number
        : GetScalarType<T[P], AggregateSettings[P]>
      : GetScalarType<T[P], AggregateSettings[P]>
  }




  export type SettingsGroupByArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    where?: SettingsWhereInput
    orderBy?: SettingsOrderByWithAggregationInput | SettingsOrderByWithAggregationInput[]
    by: SettingsScalarFieldEnum[] | SettingsScalarFieldEnum
    having?: SettingsScalarWhereWithAggregatesInput
    take?: number
    skip?: number
    _count?: SettingsCountAggregateInputType | true
    _min?: SettingsMinAggregateInputType
    _max?: SettingsMaxAggregateInputType
  }

  export type SettingsGroupByOutputType = {
    id: string
    userId: string
    pageTurnStyle: string
    fontScale: string
    highContrast: boolean
    ttsEnabled: boolean
    sttEnabled: boolean
    reducedMotion: boolean
    createdAt: Date
    updatedAt: Date
    _count: SettingsCountAggregateOutputType | null
    _min: SettingsMinAggregateOutputType | null
    _max: SettingsMaxAggregateOutputType | null
  }

  type GetSettingsGroupByPayload<T extends SettingsGroupByArgs> = Prisma.PrismaPromise<
    Array<
      PickEnumerable<SettingsGroupByOutputType, T['by']> &
        {
          [P in ((keyof T) & (keyof SettingsGroupByOutputType))]: P extends '_count'
            ? T[P] extends boolean
              ? number
              : GetScalarType<T[P], SettingsGroupByOutputType[P]>
            : GetScalarType<T[P], SettingsGroupByOutputType[P]>
        }
      >
    >


  export type SettingsSelect<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    pageTurnStyle?: boolean
    fontScale?: boolean
    highContrast?: boolean
    ttsEnabled?: boolean
    sttEnabled?: boolean
    reducedMotion?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["settings"]>

  export type SettingsSelectCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    pageTurnStyle?: boolean
    fontScale?: boolean
    highContrast?: boolean
    ttsEnabled?: boolean
    sttEnabled?: boolean
    reducedMotion?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["settings"]>

  export type SettingsSelectUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetSelect<{
    id?: boolean
    userId?: boolean
    pageTurnStyle?: boolean
    fontScale?: boolean
    highContrast?: boolean
    ttsEnabled?: boolean
    sttEnabled?: boolean
    reducedMotion?: boolean
    createdAt?: boolean
    updatedAt?: boolean
    user?: boolean | UserDefaultArgs<ExtArgs>
  }, ExtArgs["result"]["settings"]>

  export type SettingsSelectScalar = {
    id?: boolean
    userId?: boolean
    pageTurnStyle?: boolean
    fontScale?: boolean
    highContrast?: boolean
    ttsEnabled?: boolean
    sttEnabled?: boolean
    reducedMotion?: boolean
    createdAt?: boolean
    updatedAt?: boolean
  }

  export type SettingsOmit<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = $Extensions.GetOmit<"id" | "userId" | "pageTurnStyle" | "fontScale" | "highContrast" | "ttsEnabled" | "sttEnabled" | "reducedMotion" | "createdAt" | "updatedAt", ExtArgs["result"]["settings"]>
  export type SettingsInclude<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }
  export type SettingsIncludeCreateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }
  export type SettingsIncludeUpdateManyAndReturn<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    user?: boolean | UserDefaultArgs<ExtArgs>
  }

  export type $SettingsPayload<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    name: "Settings"
    objects: {
      user: Prisma.$UserPayload<ExtArgs>
    }
    scalars: $Extensions.GetPayloadResult<{
      id: string
      userId: string
      pageTurnStyle: string
      fontScale: string
      highContrast: boolean
      ttsEnabled: boolean
      sttEnabled: boolean
      reducedMotion: boolean
      createdAt: Date
      updatedAt: Date
    }, ExtArgs["result"]["settings"]>
    composites: {}
  }

  type SettingsGetPayload<S extends boolean | null | undefined | SettingsDefaultArgs> = $Result.GetResult<Prisma.$SettingsPayload, S>

  type SettingsCountArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> =
    Omit<SettingsFindManyArgs, 'select' | 'include' | 'distinct' | 'omit'> & {
      select?: SettingsCountAggregateInputType | true
    }

  export interface SettingsDelegate<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> {
    [K: symbol]: { types: Prisma.TypeMap<ExtArgs>['model']['Settings'], meta: { name: 'Settings' } }
    /**
     * Find zero or one Settings that matches the filter.
     * @param {SettingsFindUniqueArgs} args - Arguments to find a Settings
     * @example
     * // Get one Settings
     * const settings = await prisma.settings.findUnique({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUnique<T extends SettingsFindUniqueArgs>(args: SelectSubset<T, SettingsFindUniqueArgs<ExtArgs>>): Prisma__SettingsClient<$Result.GetResult<Prisma.$SettingsPayload<ExtArgs>, T, "findUnique", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find one Settings that matches the filter or throw an error with `error.code='P2025'`
     * if no matches were found.
     * @param {SettingsFindUniqueOrThrowArgs} args - Arguments to find a Settings
     * @example
     * // Get one Settings
     * const settings = await prisma.settings.findUniqueOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findUniqueOrThrow<T extends SettingsFindUniqueOrThrowArgs>(args: SelectSubset<T, SettingsFindUniqueOrThrowArgs<ExtArgs>>): Prisma__SettingsClient<$Result.GetResult<Prisma.$SettingsPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Settings that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SettingsFindFirstArgs} args - Arguments to find a Settings
     * @example
     * // Get one Settings
     * const settings = await prisma.settings.findFirst({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirst<T extends SettingsFindFirstArgs>(args?: SelectSubset<T, SettingsFindFirstArgs<ExtArgs>>): Prisma__SettingsClient<$Result.GetResult<Prisma.$SettingsPayload<ExtArgs>, T, "findFirst", GlobalOmitOptions> | null, null, ExtArgs, GlobalOmitOptions>

    /**
     * Find the first Settings that matches the filter or
     * throw `PrismaKnownClientError` with `P2025` code if no matches were found.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SettingsFindFirstOrThrowArgs} args - Arguments to find a Settings
     * @example
     * // Get one Settings
     * const settings = await prisma.settings.findFirstOrThrow({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     */
    findFirstOrThrow<T extends SettingsFindFirstOrThrowArgs>(args?: SelectSubset<T, SettingsFindFirstOrThrowArgs<ExtArgs>>): Prisma__SettingsClient<$Result.GetResult<Prisma.$SettingsPayload<ExtArgs>, T, "findFirstOrThrow", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Find zero or more Settings that matches the filter.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SettingsFindManyArgs} args - Arguments to filter and select certain fields only.
     * @example
     * // Get all Settings
     * const settings = await prisma.settings.findMany()
     * 
     * // Get first 10 Settings
     * const settings = await prisma.settings.findMany({ take: 10 })
     * 
     * // Only select the `id`
     * const settingsWithIdOnly = await prisma.settings.findMany({ select: { id: true } })
     * 
     */
    findMany<T extends SettingsFindManyArgs>(args?: SelectSubset<T, SettingsFindManyArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SettingsPayload<ExtArgs>, T, "findMany", GlobalOmitOptions>>

    /**
     * Create a Settings.
     * @param {SettingsCreateArgs} args - Arguments to create a Settings.
     * @example
     * // Create one Settings
     * const Settings = await prisma.settings.create({
     *   data: {
     *     // ... data to create a Settings
     *   }
     * })
     * 
     */
    create<T extends SettingsCreateArgs>(args: SelectSubset<T, SettingsCreateArgs<ExtArgs>>): Prisma__SettingsClient<$Result.GetResult<Prisma.$SettingsPayload<ExtArgs>, T, "create", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Create many Settings.
     * @param {SettingsCreateManyArgs} args - Arguments to create many Settings.
     * @example
     * // Create many Settings
     * const settings = await prisma.settings.createMany({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     *     
     */
    createMany<T extends SettingsCreateManyArgs>(args?: SelectSubset<T, SettingsCreateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Create many Settings and returns the data saved in the database.
     * @param {SettingsCreateManyAndReturnArgs} args - Arguments to create many Settings.
     * @example
     * // Create many Settings
     * const settings = await prisma.settings.createManyAndReturn({
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Create many Settings and only return the `id`
     * const settingsWithIdOnly = await prisma.settings.createManyAndReturn({
     *   select: { id: true },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    createManyAndReturn<T extends SettingsCreateManyAndReturnArgs>(args?: SelectSubset<T, SettingsCreateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SettingsPayload<ExtArgs>, T, "createManyAndReturn", GlobalOmitOptions>>

    /**
     * Delete a Settings.
     * @param {SettingsDeleteArgs} args - Arguments to delete one Settings.
     * @example
     * // Delete one Settings
     * const Settings = await prisma.settings.delete({
     *   where: {
     *     // ... filter to delete one Settings
     *   }
     * })
     * 
     */
    delete<T extends SettingsDeleteArgs>(args: SelectSubset<T, SettingsDeleteArgs<ExtArgs>>): Prisma__SettingsClient<$Result.GetResult<Prisma.$SettingsPayload<ExtArgs>, T, "delete", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Update one Settings.
     * @param {SettingsUpdateArgs} args - Arguments to update one Settings.
     * @example
     * // Update one Settings
     * const settings = await prisma.settings.update({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    update<T extends SettingsUpdateArgs>(args: SelectSubset<T, SettingsUpdateArgs<ExtArgs>>): Prisma__SettingsClient<$Result.GetResult<Prisma.$SettingsPayload<ExtArgs>, T, "update", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>

    /**
     * Delete zero or more Settings.
     * @param {SettingsDeleteManyArgs} args - Arguments to filter Settings to delete.
     * @example
     * // Delete a few Settings
     * const { count } = await prisma.settings.deleteMany({
     *   where: {
     *     // ... provide filter here
     *   }
     * })
     * 
     */
    deleteMany<T extends SettingsDeleteManyArgs>(args?: SelectSubset<T, SettingsDeleteManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Settings.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SettingsUpdateManyArgs} args - Arguments to update one or more rows.
     * @example
     * // Update many Settings
     * const settings = await prisma.settings.updateMany({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: {
     *     // ... provide data here
     *   }
     * })
     * 
     */
    updateMany<T extends SettingsUpdateManyArgs>(args: SelectSubset<T, SettingsUpdateManyArgs<ExtArgs>>): Prisma.PrismaPromise<BatchPayload>

    /**
     * Update zero or more Settings and returns the data updated in the database.
     * @param {SettingsUpdateManyAndReturnArgs} args - Arguments to update many Settings.
     * @example
     * // Update many Settings
     * const settings = await prisma.settings.updateManyAndReturn({
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * 
     * // Update zero or more Settings and only return the `id`
     * const settingsWithIdOnly = await prisma.settings.updateManyAndReturn({
     *   select: { id: true },
     *   where: {
     *     // ... provide filter here
     *   },
     *   data: [
     *     // ... provide data here
     *   ]
     * })
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * 
     */
    updateManyAndReturn<T extends SettingsUpdateManyAndReturnArgs>(args: SelectSubset<T, SettingsUpdateManyAndReturnArgs<ExtArgs>>): Prisma.PrismaPromise<$Result.GetResult<Prisma.$SettingsPayload<ExtArgs>, T, "updateManyAndReturn", GlobalOmitOptions>>

    /**
     * Create or update one Settings.
     * @param {SettingsUpsertArgs} args - Arguments to update or create a Settings.
     * @example
     * // Update or create a Settings
     * const settings = await prisma.settings.upsert({
     *   create: {
     *     // ... data to create a Settings
     *   },
     *   update: {
     *     // ... in case it already exists, update
     *   },
     *   where: {
     *     // ... the filter for the Settings we want to update
     *   }
     * })
     */
    upsert<T extends SettingsUpsertArgs>(args: SelectSubset<T, SettingsUpsertArgs<ExtArgs>>): Prisma__SettingsClient<$Result.GetResult<Prisma.$SettingsPayload<ExtArgs>, T, "upsert", GlobalOmitOptions>, never, ExtArgs, GlobalOmitOptions>


    /**
     * Count the number of Settings.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SettingsCountArgs} args - Arguments to filter Settings to count.
     * @example
     * // Count the number of Settings
     * const count = await prisma.settings.count({
     *   where: {
     *     // ... the filter for the Settings we want to count
     *   }
     * })
    **/
    count<T extends SettingsCountArgs>(
      args?: Subset<T, SettingsCountArgs>,
    ): Prisma.PrismaPromise<
      T extends $Utils.Record<'select', any>
        ? T['select'] extends true
          ? number
          : GetScalarType<T['select'], SettingsCountAggregateOutputType>
        : number
    >

    /**
     * Allows you to perform aggregations operations on a Settings.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SettingsAggregateArgs} args - Select which aggregations you would like to apply and on what fields.
     * @example
     * // Ordered by age ascending
     * // Where email contains prisma.io
     * // Limited to the 10 users
     * const aggregations = await prisma.user.aggregate({
     *   _avg: {
     *     age: true,
     *   },
     *   where: {
     *     email: {
     *       contains: "prisma.io",
     *     },
     *   },
     *   orderBy: {
     *     age: "asc",
     *   },
     *   take: 10,
     * })
    **/
    aggregate<T extends SettingsAggregateArgs>(args: Subset<T, SettingsAggregateArgs>): Prisma.PrismaPromise<GetSettingsAggregateType<T>>

    /**
     * Group by Settings.
     * Note, that providing `undefined` is treated as the value not being there.
     * Read more here: https://pris.ly/d/null-undefined
     * @param {SettingsGroupByArgs} args - Group by arguments.
     * @example
     * // Group by city, order by createdAt, get count
     * const result = await prisma.user.groupBy({
     *   by: ['city', 'createdAt'],
     *   orderBy: {
     *     createdAt: true
     *   },
     *   _count: {
     *     _all: true
     *   },
     * })
     * 
    **/
    groupBy<
      T extends SettingsGroupByArgs,
      HasSelectOrTake extends Or<
        Extends<'skip', Keys<T>>,
        Extends<'take', Keys<T>>
      >,
      OrderByArg extends True extends HasSelectOrTake
        ? { orderBy: SettingsGroupByArgs['orderBy'] }
        : { orderBy?: SettingsGroupByArgs['orderBy'] },
      OrderFields extends ExcludeUnderscoreKeys<Keys<MaybeTupleToUnion<T['orderBy']>>>,
      ByFields extends MaybeTupleToUnion<T['by']>,
      ByValid extends Has<ByFields, OrderFields>,
      HavingFields extends GetHavingFields<T['having']>,
      HavingValid extends Has<ByFields, HavingFields>,
      ByEmpty extends T['by'] extends never[] ? True : False,
      InputErrors extends ByEmpty extends True
      ? `Error: "by" must not be empty.`
      : HavingValid extends False
      ? {
          [P in HavingFields]: P extends ByFields
            ? never
            : P extends string
            ? `Error: Field "${P}" used in "having" needs to be provided in "by".`
            : [
                Error,
                'Field ',
                P,
                ` in "having" needs to be provided in "by"`,
              ]
        }[HavingFields]
      : 'take' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "take", you also need to provide "orderBy"'
      : 'skip' extends Keys<T>
      ? 'orderBy' extends Keys<T>
        ? ByValid extends True
          ? {}
          : {
              [P in OrderFields]: P extends ByFields
                ? never
                : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
            }[OrderFields]
        : 'Error: If you provide "skip", you also need to provide "orderBy"'
      : ByValid extends True
      ? {}
      : {
          [P in OrderFields]: P extends ByFields
            ? never
            : `Error: Field "${P}" in "orderBy" needs to be provided in "by"`
        }[OrderFields]
    >(args: SubsetIntersection<T, SettingsGroupByArgs, OrderByArg> & InputErrors): {} extends InputErrors ? GetSettingsGroupByPayload<T> : Prisma.PrismaPromise<InputErrors>
  /**
   * Fields of the Settings model
   */
  readonly fields: SettingsFieldRefs;
  }

  /**
   * The delegate class that acts as a "Promise-like" for Settings.
   * Why is this prefixed with `Prisma__`?
   * Because we want to prevent naming conflicts as mentioned in
   * https://github.com/prisma/prisma-client-js/issues/707
   */
  export interface Prisma__SettingsClient<T, Null = never, ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs, GlobalOmitOptions = {}> extends Prisma.PrismaPromise<T> {
    readonly [Symbol.toStringTag]: "PrismaPromise"
    user<T extends UserDefaultArgs<ExtArgs> = {}>(args?: Subset<T, UserDefaultArgs<ExtArgs>>): Prisma__UserClient<$Result.GetResult<Prisma.$UserPayload<ExtArgs>, T, "findUniqueOrThrow", GlobalOmitOptions> | Null, Null, ExtArgs, GlobalOmitOptions>
    /**
     * Attaches callbacks for the resolution and/or rejection of the Promise.
     * @param onfulfilled The callback to execute when the Promise is resolved.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of which ever callback is executed.
     */
    then<TResult1 = T, TResult2 = never>(onfulfilled?: ((value: T) => TResult1 | PromiseLike<TResult1>) | undefined | null, onrejected?: ((reason: any) => TResult2 | PromiseLike<TResult2>) | undefined | null): $Utils.JsPromise<TResult1 | TResult2>
    /**
     * Attaches a callback for only the rejection of the Promise.
     * @param onrejected The callback to execute when the Promise is rejected.
     * @returns A Promise for the completion of the callback.
     */
    catch<TResult = never>(onrejected?: ((reason: any) => TResult | PromiseLike<TResult>) | undefined | null): $Utils.JsPromise<T | TResult>
    /**
     * Attaches a callback that is invoked when the Promise is settled (fulfilled or rejected). The
     * resolved value cannot be modified from the callback.
     * @param onfinally The callback to execute when the Promise is settled (fulfilled or rejected).
     * @returns A Promise for the completion of the callback.
     */
    finally(onfinally?: (() => void) | undefined | null): $Utils.JsPromise<T>
  }




  /**
   * Fields of the Settings model
   */
  interface SettingsFieldRefs {
    readonly id: FieldRef<"Settings", 'String'>
    readonly userId: FieldRef<"Settings", 'String'>
    readonly pageTurnStyle: FieldRef<"Settings", 'String'>
    readonly fontScale: FieldRef<"Settings", 'String'>
    readonly highContrast: FieldRef<"Settings", 'Boolean'>
    readonly ttsEnabled: FieldRef<"Settings", 'Boolean'>
    readonly sttEnabled: FieldRef<"Settings", 'Boolean'>
    readonly reducedMotion: FieldRef<"Settings", 'Boolean'>
    readonly createdAt: FieldRef<"Settings", 'DateTime'>
    readonly updatedAt: FieldRef<"Settings", 'DateTime'>
  }
    

  // Custom InputTypes
  /**
   * Settings findUnique
   */
  export type SettingsFindUniqueArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Settings
     */
    select?: SettingsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Settings
     */
    omit?: SettingsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SettingsInclude<ExtArgs> | null
    /**
     * Filter, which Settings to fetch.
     */
    where: SettingsWhereUniqueInput
  }

  /**
   * Settings findUniqueOrThrow
   */
  export type SettingsFindUniqueOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Settings
     */
    select?: SettingsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Settings
     */
    omit?: SettingsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SettingsInclude<ExtArgs> | null
    /**
     * Filter, which Settings to fetch.
     */
    where: SettingsWhereUniqueInput
  }

  /**
   * Settings findFirst
   */
  export type SettingsFindFirstArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Settings
     */
    select?: SettingsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Settings
     */
    omit?: SettingsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SettingsInclude<ExtArgs> | null
    /**
     * Filter, which Settings to fetch.
     */
    where?: SettingsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Settings to fetch.
     */
    orderBy?: SettingsOrderByWithRelationInput | SettingsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Settings.
     */
    cursor?: SettingsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Settings from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Settings.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Settings.
     */
    distinct?: SettingsScalarFieldEnum | SettingsScalarFieldEnum[]
  }

  /**
   * Settings findFirstOrThrow
   */
  export type SettingsFindFirstOrThrowArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Settings
     */
    select?: SettingsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Settings
     */
    omit?: SettingsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SettingsInclude<ExtArgs> | null
    /**
     * Filter, which Settings to fetch.
     */
    where?: SettingsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Settings to fetch.
     */
    orderBy?: SettingsOrderByWithRelationInput | SettingsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for searching for Settings.
     */
    cursor?: SettingsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Settings from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Settings.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Settings.
     */
    distinct?: SettingsScalarFieldEnum | SettingsScalarFieldEnum[]
  }

  /**
   * Settings findMany
   */
  export type SettingsFindManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Settings
     */
    select?: SettingsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Settings
     */
    omit?: SettingsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SettingsInclude<ExtArgs> | null
    /**
     * Filter, which Settings to fetch.
     */
    where?: SettingsWhereInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/sorting Sorting Docs}
     * 
     * Determine the order of Settings to fetch.
     */
    orderBy?: SettingsOrderByWithRelationInput | SettingsOrderByWithRelationInput[]
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination#cursor-based-pagination Cursor Docs}
     * 
     * Sets the position for listing Settings.
     */
    cursor?: SettingsWhereUniqueInput
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Take `±n` Settings from the position of the cursor.
     */
    take?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/pagination Pagination Docs}
     * 
     * Skip the first `n` Settings.
     */
    skip?: number
    /**
     * {@link https://www.prisma.io/docs/concepts/components/prisma-client/distinct Distinct Docs}
     * 
     * Filter by unique combinations of Settings.
     */
    distinct?: SettingsScalarFieldEnum | SettingsScalarFieldEnum[]
  }

  /**
   * Settings create
   */
  export type SettingsCreateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Settings
     */
    select?: SettingsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Settings
     */
    omit?: SettingsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SettingsInclude<ExtArgs> | null
    /**
     * The data needed to create a Settings.
     */
    data: XOR<SettingsCreateInput, SettingsUncheckedCreateInput>
  }

  /**
   * Settings createMany
   */
  export type SettingsCreateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to create many Settings.
     */
    data: SettingsCreateManyInput | SettingsCreateManyInput[]
    skipDuplicates?: boolean
  }

  /**
   * Settings createManyAndReturn
   */
  export type SettingsCreateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Settings
     */
    select?: SettingsSelectCreateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Settings
     */
    omit?: SettingsOmit<ExtArgs> | null
    /**
     * The data used to create many Settings.
     */
    data: SettingsCreateManyInput | SettingsCreateManyInput[]
    skipDuplicates?: boolean
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SettingsIncludeCreateManyAndReturn<ExtArgs> | null
  }

  /**
   * Settings update
   */
  export type SettingsUpdateArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Settings
     */
    select?: SettingsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Settings
     */
    omit?: SettingsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SettingsInclude<ExtArgs> | null
    /**
     * The data needed to update a Settings.
     */
    data: XOR<SettingsUpdateInput, SettingsUncheckedUpdateInput>
    /**
     * Choose, which Settings to update.
     */
    where: SettingsWhereUniqueInput
  }

  /**
   * Settings updateMany
   */
  export type SettingsUpdateManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * The data used to update Settings.
     */
    data: XOR<SettingsUpdateManyMutationInput, SettingsUncheckedUpdateManyInput>
    /**
     * Filter which Settings to update
     */
    where?: SettingsWhereInput
    /**
     * Limit how many Settings to update.
     */
    limit?: number
  }

  /**
   * Settings updateManyAndReturn
   */
  export type SettingsUpdateManyAndReturnArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Settings
     */
    select?: SettingsSelectUpdateManyAndReturn<ExtArgs> | null
    /**
     * Omit specific fields from the Settings
     */
    omit?: SettingsOmit<ExtArgs> | null
    /**
     * The data used to update Settings.
     */
    data: XOR<SettingsUpdateManyMutationInput, SettingsUncheckedUpdateManyInput>
    /**
     * Filter which Settings to update
     */
    where?: SettingsWhereInput
    /**
     * Limit how many Settings to update.
     */
    limit?: number
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SettingsIncludeUpdateManyAndReturn<ExtArgs> | null
  }

  /**
   * Settings upsert
   */
  export type SettingsUpsertArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Settings
     */
    select?: SettingsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Settings
     */
    omit?: SettingsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SettingsInclude<ExtArgs> | null
    /**
     * The filter to search for the Settings to update in case it exists.
     */
    where: SettingsWhereUniqueInput
    /**
     * In case the Settings found by the `where` argument doesn't exist, create a new Settings with this data.
     */
    create: XOR<SettingsCreateInput, SettingsUncheckedCreateInput>
    /**
     * In case the Settings was found with the provided `where` argument, update it with this data.
     */
    update: XOR<SettingsUpdateInput, SettingsUncheckedUpdateInput>
  }

  /**
   * Settings delete
   */
  export type SettingsDeleteArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Settings
     */
    select?: SettingsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Settings
     */
    omit?: SettingsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SettingsInclude<ExtArgs> | null
    /**
     * Filter which Settings to delete.
     */
    where: SettingsWhereUniqueInput
  }

  /**
   * Settings deleteMany
   */
  export type SettingsDeleteManyArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Filter which Settings to delete
     */
    where?: SettingsWhereInput
    /**
     * Limit how many Settings to delete.
     */
    limit?: number
  }

  /**
   * Settings without action
   */
  export type SettingsDefaultArgs<ExtArgs extends $Extensions.InternalArgs = $Extensions.DefaultArgs> = {
    /**
     * Select specific fields to fetch from the Settings
     */
    select?: SettingsSelect<ExtArgs> | null
    /**
     * Omit specific fields from the Settings
     */
    omit?: SettingsOmit<ExtArgs> | null
    /**
     * Choose, which related nodes to fetch as well
     */
    include?: SettingsInclude<ExtArgs> | null
  }


  /**
   * Enums
   */

  export const TransactionIsolationLevel: {
    ReadUncommitted: 'ReadUncommitted',
    ReadCommitted: 'ReadCommitted',
    RepeatableRead: 'RepeatableRead',
    Serializable: 'Serializable'
  };

  export type TransactionIsolationLevel = (typeof TransactionIsolationLevel)[keyof typeof TransactionIsolationLevel]


  export const UserScalarFieldEnum: {
    id: 'id',
    email: 'email',
    name: 'name',
    plan: 'plan',
    pendingDeathVerificationAt: 'pendingDeathVerificationAt',
    deceasedAt: 'deceasedAt',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type UserScalarFieldEnum = (typeof UserScalarFieldEnum)[keyof typeof UserScalarFieldEnum]


  export const ContactScalarFieldEnum: {
    id: 'id',
    userId: 'userId',
    name: 'name',
    email: 'email',
    phone: 'phone',
    relationship: 'relationship',
    isExecutor: 'isExecutor',
    isBackup: 'isBackup',
    createdAt: 'createdAt'
  };

  export type ContactScalarFieldEnum = (typeof ContactScalarFieldEnum)[keyof typeof ContactScalarFieldEnum]


  export const MessageScalarFieldEnum: {
    id: 'id',
    userId: 'userId',
    recipientName: 'recipientName',
    recipientEmail: 'recipientEmail',
    type: 'type',
    subject: 'subject',
    content: 'content',
    mediaUrl: 'mediaUrl',
    mediaBlobPath: 'mediaBlobPath',
    mediaDurationSec: 'mediaDurationSec',
    triggerDate: 'triggerDate',
    state: 'state',
    approvalPromptedAt: 'approvalPromptedAt',
    approvalExpiresAt: 'approvalExpiresAt',
    sentAt: 'sentAt',
    archivedAt: 'archivedAt',
    deliveryToken: 'deliveryToken',
    approvalToken: 'approvalToken',
    approvalRemindersSent: 'approvalRemindersSent',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type MessageScalarFieldEnum = (typeof MessageScalarFieldEnum)[keyof typeof MessageScalarFieldEnum]


  export const MessageInviteScalarFieldEnum: {
    id: 'id',
    userId: 'userId',
    token: 'token',
    contributorName: 'contributorName',
    contributorEmail: 'contributorEmail',
    message: 'message',
    expiresAt: 'expiresAt',
    revokedAt: 'revokedAt',
    lastUsedAt: 'lastUsedAt',
    useCount: 'useCount',
    createdAt: 'createdAt'
  };

  export type MessageInviteScalarFieldEnum = (typeof MessageInviteScalarFieldEnum)[keyof typeof MessageInviteScalarFieldEnum]


  export const ContributionScalarFieldEnum: {
    id: 'id',
    userId: 'userId',
    inviteId: 'inviteId',
    contributorName: 'contributorName',
    contributorNote: 'contributorNote',
    type: 'type',
    content: 'content',
    mediaUrl: 'mediaUrl',
    mediaBlobPath: 'mediaBlobPath',
    viewedByUser: 'viewedByUser',
    importedToTimelineItemId: 'importedToTimelineItemId',
    archivedAt: 'archivedAt',
    createdAt: 'createdAt'
  };

  export type ContributionScalarFieldEnum = (typeof ContributionScalarFieldEnum)[keyof typeof ContributionScalarFieldEnum]


  export const TimelineItemScalarFieldEnum: {
    id: 'id',
    userId: 'userId',
    date: 'date',
    title: 'title',
    story: 'story',
    mediaUrl: 'mediaUrl',
    createdAt: 'createdAt'
  };

  export type TimelineItemScalarFieldEnum = (typeof TimelineItemScalarFieldEnum)[keyof typeof TimelineItemScalarFieldEnum]


  export const PhotoScalarFieldEnum: {
    id: 'id',
    userId: 'userId',
    timelineItemId: 'timelineItemId',
    url: 'url',
    thumbnailUrl: 'thumbnailUrl',
    blobPath: 'blobPath',
    caption: 'caption',
    width: 'width',
    height: 'height',
    sizeBytes: 'sizeBytes',
    order: 'order',
    createdAt: 'createdAt'
  };

  export type PhotoScalarFieldEnum = (typeof PhotoScalarFieldEnum)[keyof typeof PhotoScalarFieldEnum]


  export const ArrangementScalarFieldEnum: {
    id: 'id',
    userId: 'userId',
    type: 'type',
    vendor: 'vendor',
    contact: 'contact',
    notes: 'notes',
    createdAt: 'createdAt'
  };

  export type ArrangementScalarFieldEnum = (typeof ArrangementScalarFieldEnum)[keyof typeof ArrangementScalarFieldEnum]


  export const VaultItemScalarFieldEnum: {
    id: 'id',
    userId: 'userId',
    label: 'label',
    encryptedData: 'encryptedData',
    createdAt: 'createdAt'
  };

  export type VaultItemScalarFieldEnum = (typeof VaultItemScalarFieldEnum)[keyof typeof VaultItemScalarFieldEnum]


  export const ExecutorScalarFieldEnum: {
    id: 'id',
    userId: 'userId',
    name: 'name',
    email: 'email',
    phone: 'phone',
    verified: 'verified',
    certUploadedAt: 'certUploadedAt',
    unlockedAt: 'unlockedAt',
    createdAt: 'createdAt'
  };

  export type ExecutorScalarFieldEnum = (typeof ExecutorScalarFieldEnum)[keyof typeof ExecutorScalarFieldEnum]


  export const SettingsScalarFieldEnum: {
    id: 'id',
    userId: 'userId',
    pageTurnStyle: 'pageTurnStyle',
    fontScale: 'fontScale',
    highContrast: 'highContrast',
    ttsEnabled: 'ttsEnabled',
    sttEnabled: 'sttEnabled',
    reducedMotion: 'reducedMotion',
    createdAt: 'createdAt',
    updatedAt: 'updatedAt'
  };

  export type SettingsScalarFieldEnum = (typeof SettingsScalarFieldEnum)[keyof typeof SettingsScalarFieldEnum]


  export const SortOrder: {
    asc: 'asc',
    desc: 'desc'
  };

  export type SortOrder = (typeof SortOrder)[keyof typeof SortOrder]


  export const QueryMode: {
    default: 'default',
    insensitive: 'insensitive'
  };

  export type QueryMode = (typeof QueryMode)[keyof typeof QueryMode]


  export const NullsOrder: {
    first: 'first',
    last: 'last'
  };

  export type NullsOrder = (typeof NullsOrder)[keyof typeof NullsOrder]


  /**
   * Field references
   */


  /**
   * Reference to a field of type 'String'
   */
  export type StringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String'>
    


  /**
   * Reference to a field of type 'String[]'
   */
  export type ListStringFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'String[]'>
    


  /**
   * Reference to a field of type 'DateTime'
   */
  export type DateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime'>
    


  /**
   * Reference to a field of type 'DateTime[]'
   */
  export type ListDateTimeFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'DateTime[]'>
    


  /**
   * Reference to a field of type 'Boolean'
   */
  export type BooleanFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Boolean'>
    


  /**
   * Reference to a field of type 'Int'
   */
  export type IntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int'>
    


  /**
   * Reference to a field of type 'Int[]'
   */
  export type ListIntFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Int[]'>
    


  /**
   * Reference to a field of type 'Float'
   */
  export type FloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float'>
    


  /**
   * Reference to a field of type 'Float[]'
   */
  export type ListFloatFieldRefInput<$PrismaModel> = FieldRefInputType<$PrismaModel, 'Float[]'>
    
  /**
   * Deep Input Types
   */


  export type UserWhereInput = {
    AND?: UserWhereInput | UserWhereInput[]
    OR?: UserWhereInput[]
    NOT?: UserWhereInput | UserWhereInput[]
    id?: StringFilter<"User"> | string
    email?: StringFilter<"User"> | string
    name?: StringNullableFilter<"User"> | string | null
    plan?: StringFilter<"User"> | string
    pendingDeathVerificationAt?: DateTimeNullableFilter<"User"> | Date | string | null
    deceasedAt?: DateTimeNullableFilter<"User"> | Date | string | null
    createdAt?: DateTimeFilter<"User"> | Date | string
    updatedAt?: DateTimeFilter<"User"> | Date | string
    contacts?: ContactListRelationFilter
    messages?: MessageListRelationFilter
    arrangements?: ArrangementListRelationFilter
    timelineItems?: TimelineItemListRelationFilter
    vaultItems?: VaultItemListRelationFilter
    executor?: XOR<ExecutorNullableScalarRelationFilter, ExecutorWhereInput> | null
    photos?: PhotoListRelationFilter
    settings?: XOR<SettingsNullableScalarRelationFilter, SettingsWhereInput> | null
    messageInvites?: MessageInviteListRelationFilter
    contributions?: ContributionListRelationFilter
  }

  export type UserOrderByWithRelationInput = {
    id?: SortOrder
    email?: SortOrder
    name?: SortOrderInput | SortOrder
    plan?: SortOrder
    pendingDeathVerificationAt?: SortOrderInput | SortOrder
    deceasedAt?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    contacts?: ContactOrderByRelationAggregateInput
    messages?: MessageOrderByRelationAggregateInput
    arrangements?: ArrangementOrderByRelationAggregateInput
    timelineItems?: TimelineItemOrderByRelationAggregateInput
    vaultItems?: VaultItemOrderByRelationAggregateInput
    executor?: ExecutorOrderByWithRelationInput
    photos?: PhotoOrderByRelationAggregateInput
    settings?: SettingsOrderByWithRelationInput
    messageInvites?: MessageInviteOrderByRelationAggregateInput
    contributions?: ContributionOrderByRelationAggregateInput
  }

  export type UserWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    email?: string
    AND?: UserWhereInput | UserWhereInput[]
    OR?: UserWhereInput[]
    NOT?: UserWhereInput | UserWhereInput[]
    name?: StringNullableFilter<"User"> | string | null
    plan?: StringFilter<"User"> | string
    pendingDeathVerificationAt?: DateTimeNullableFilter<"User"> | Date | string | null
    deceasedAt?: DateTimeNullableFilter<"User"> | Date | string | null
    createdAt?: DateTimeFilter<"User"> | Date | string
    updatedAt?: DateTimeFilter<"User"> | Date | string
    contacts?: ContactListRelationFilter
    messages?: MessageListRelationFilter
    arrangements?: ArrangementListRelationFilter
    timelineItems?: TimelineItemListRelationFilter
    vaultItems?: VaultItemListRelationFilter
    executor?: XOR<ExecutorNullableScalarRelationFilter, ExecutorWhereInput> | null
    photos?: PhotoListRelationFilter
    settings?: XOR<SettingsNullableScalarRelationFilter, SettingsWhereInput> | null
    messageInvites?: MessageInviteListRelationFilter
    contributions?: ContributionListRelationFilter
  }, "id" | "email">

  export type UserOrderByWithAggregationInput = {
    id?: SortOrder
    email?: SortOrder
    name?: SortOrderInput | SortOrder
    plan?: SortOrder
    pendingDeathVerificationAt?: SortOrderInput | SortOrder
    deceasedAt?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: UserCountOrderByAggregateInput
    _max?: UserMaxOrderByAggregateInput
    _min?: UserMinOrderByAggregateInput
  }

  export type UserScalarWhereWithAggregatesInput = {
    AND?: UserScalarWhereWithAggregatesInput | UserScalarWhereWithAggregatesInput[]
    OR?: UserScalarWhereWithAggregatesInput[]
    NOT?: UserScalarWhereWithAggregatesInput | UserScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"User"> | string
    email?: StringWithAggregatesFilter<"User"> | string
    name?: StringNullableWithAggregatesFilter<"User"> | string | null
    plan?: StringWithAggregatesFilter<"User"> | string
    pendingDeathVerificationAt?: DateTimeNullableWithAggregatesFilter<"User"> | Date | string | null
    deceasedAt?: DateTimeNullableWithAggregatesFilter<"User"> | Date | string | null
    createdAt?: DateTimeWithAggregatesFilter<"User"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"User"> | Date | string
  }

  export type ContactWhereInput = {
    AND?: ContactWhereInput | ContactWhereInput[]
    OR?: ContactWhereInput[]
    NOT?: ContactWhereInput | ContactWhereInput[]
    id?: StringFilter<"Contact"> | string
    userId?: StringFilter<"Contact"> | string
    name?: StringFilter<"Contact"> | string
    email?: StringNullableFilter<"Contact"> | string | null
    phone?: StringNullableFilter<"Contact"> | string | null
    relationship?: StringNullableFilter<"Contact"> | string | null
    isExecutor?: BoolFilter<"Contact"> | boolean
    isBackup?: BoolFilter<"Contact"> | boolean
    createdAt?: DateTimeFilter<"Contact"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
  }

  export type ContactOrderByWithRelationInput = {
    id?: SortOrder
    userId?: SortOrder
    name?: SortOrder
    email?: SortOrderInput | SortOrder
    phone?: SortOrderInput | SortOrder
    relationship?: SortOrderInput | SortOrder
    isExecutor?: SortOrder
    isBackup?: SortOrder
    createdAt?: SortOrder
    user?: UserOrderByWithRelationInput
  }

  export type ContactWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: ContactWhereInput | ContactWhereInput[]
    OR?: ContactWhereInput[]
    NOT?: ContactWhereInput | ContactWhereInput[]
    userId?: StringFilter<"Contact"> | string
    name?: StringFilter<"Contact"> | string
    email?: StringNullableFilter<"Contact"> | string | null
    phone?: StringNullableFilter<"Contact"> | string | null
    relationship?: StringNullableFilter<"Contact"> | string | null
    isExecutor?: BoolFilter<"Contact"> | boolean
    isBackup?: BoolFilter<"Contact"> | boolean
    createdAt?: DateTimeFilter<"Contact"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
  }, "id">

  export type ContactOrderByWithAggregationInput = {
    id?: SortOrder
    userId?: SortOrder
    name?: SortOrder
    email?: SortOrderInput | SortOrder
    phone?: SortOrderInput | SortOrder
    relationship?: SortOrderInput | SortOrder
    isExecutor?: SortOrder
    isBackup?: SortOrder
    createdAt?: SortOrder
    _count?: ContactCountOrderByAggregateInput
    _max?: ContactMaxOrderByAggregateInput
    _min?: ContactMinOrderByAggregateInput
  }

  export type ContactScalarWhereWithAggregatesInput = {
    AND?: ContactScalarWhereWithAggregatesInput | ContactScalarWhereWithAggregatesInput[]
    OR?: ContactScalarWhereWithAggregatesInput[]
    NOT?: ContactScalarWhereWithAggregatesInput | ContactScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Contact"> | string
    userId?: StringWithAggregatesFilter<"Contact"> | string
    name?: StringWithAggregatesFilter<"Contact"> | string
    email?: StringNullableWithAggregatesFilter<"Contact"> | string | null
    phone?: StringNullableWithAggregatesFilter<"Contact"> | string | null
    relationship?: StringNullableWithAggregatesFilter<"Contact"> | string | null
    isExecutor?: BoolWithAggregatesFilter<"Contact"> | boolean
    isBackup?: BoolWithAggregatesFilter<"Contact"> | boolean
    createdAt?: DateTimeWithAggregatesFilter<"Contact"> | Date | string
  }

  export type MessageWhereInput = {
    AND?: MessageWhereInput | MessageWhereInput[]
    OR?: MessageWhereInput[]
    NOT?: MessageWhereInput | MessageWhereInput[]
    id?: StringFilter<"Message"> | string
    userId?: StringFilter<"Message"> | string
    recipientName?: StringFilter<"Message"> | string
    recipientEmail?: StringNullableFilter<"Message"> | string | null
    type?: StringFilter<"Message"> | string
    subject?: StringNullableFilter<"Message"> | string | null
    content?: StringNullableFilter<"Message"> | string | null
    mediaUrl?: StringNullableFilter<"Message"> | string | null
    mediaBlobPath?: StringNullableFilter<"Message"> | string | null
    mediaDurationSec?: IntNullableFilter<"Message"> | number | null
    triggerDate?: DateTimeNullableFilter<"Message"> | Date | string | null
    state?: StringFilter<"Message"> | string
    approvalPromptedAt?: DateTimeNullableFilter<"Message"> | Date | string | null
    approvalExpiresAt?: DateTimeNullableFilter<"Message"> | Date | string | null
    sentAt?: DateTimeNullableFilter<"Message"> | Date | string | null
    archivedAt?: DateTimeNullableFilter<"Message"> | Date | string | null
    deliveryToken?: StringNullableFilter<"Message"> | string | null
    approvalToken?: StringNullableFilter<"Message"> | string | null
    approvalRemindersSent?: IntFilter<"Message"> | number
    createdAt?: DateTimeFilter<"Message"> | Date | string
    updatedAt?: DateTimeFilter<"Message"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
  }

  export type MessageOrderByWithRelationInput = {
    id?: SortOrder
    userId?: SortOrder
    recipientName?: SortOrder
    recipientEmail?: SortOrderInput | SortOrder
    type?: SortOrder
    subject?: SortOrderInput | SortOrder
    content?: SortOrderInput | SortOrder
    mediaUrl?: SortOrderInput | SortOrder
    mediaBlobPath?: SortOrderInput | SortOrder
    mediaDurationSec?: SortOrderInput | SortOrder
    triggerDate?: SortOrderInput | SortOrder
    state?: SortOrder
    approvalPromptedAt?: SortOrderInput | SortOrder
    approvalExpiresAt?: SortOrderInput | SortOrder
    sentAt?: SortOrderInput | SortOrder
    archivedAt?: SortOrderInput | SortOrder
    deliveryToken?: SortOrderInput | SortOrder
    approvalToken?: SortOrderInput | SortOrder
    approvalRemindersSent?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    user?: UserOrderByWithRelationInput
  }

  export type MessageWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    deliveryToken?: string
    approvalToken?: string
    AND?: MessageWhereInput | MessageWhereInput[]
    OR?: MessageWhereInput[]
    NOT?: MessageWhereInput | MessageWhereInput[]
    userId?: StringFilter<"Message"> | string
    recipientName?: StringFilter<"Message"> | string
    recipientEmail?: StringNullableFilter<"Message"> | string | null
    type?: StringFilter<"Message"> | string
    subject?: StringNullableFilter<"Message"> | string | null
    content?: StringNullableFilter<"Message"> | string | null
    mediaUrl?: StringNullableFilter<"Message"> | string | null
    mediaBlobPath?: StringNullableFilter<"Message"> | string | null
    mediaDurationSec?: IntNullableFilter<"Message"> | number | null
    triggerDate?: DateTimeNullableFilter<"Message"> | Date | string | null
    state?: StringFilter<"Message"> | string
    approvalPromptedAt?: DateTimeNullableFilter<"Message"> | Date | string | null
    approvalExpiresAt?: DateTimeNullableFilter<"Message"> | Date | string | null
    sentAt?: DateTimeNullableFilter<"Message"> | Date | string | null
    archivedAt?: DateTimeNullableFilter<"Message"> | Date | string | null
    approvalRemindersSent?: IntFilter<"Message"> | number
    createdAt?: DateTimeFilter<"Message"> | Date | string
    updatedAt?: DateTimeFilter<"Message"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
  }, "id" | "deliveryToken" | "approvalToken">

  export type MessageOrderByWithAggregationInput = {
    id?: SortOrder
    userId?: SortOrder
    recipientName?: SortOrder
    recipientEmail?: SortOrderInput | SortOrder
    type?: SortOrder
    subject?: SortOrderInput | SortOrder
    content?: SortOrderInput | SortOrder
    mediaUrl?: SortOrderInput | SortOrder
    mediaBlobPath?: SortOrderInput | SortOrder
    mediaDurationSec?: SortOrderInput | SortOrder
    triggerDate?: SortOrderInput | SortOrder
    state?: SortOrder
    approvalPromptedAt?: SortOrderInput | SortOrder
    approvalExpiresAt?: SortOrderInput | SortOrder
    sentAt?: SortOrderInput | SortOrder
    archivedAt?: SortOrderInput | SortOrder
    deliveryToken?: SortOrderInput | SortOrder
    approvalToken?: SortOrderInput | SortOrder
    approvalRemindersSent?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: MessageCountOrderByAggregateInput
    _avg?: MessageAvgOrderByAggregateInput
    _max?: MessageMaxOrderByAggregateInput
    _min?: MessageMinOrderByAggregateInput
    _sum?: MessageSumOrderByAggregateInput
  }

  export type MessageScalarWhereWithAggregatesInput = {
    AND?: MessageScalarWhereWithAggregatesInput | MessageScalarWhereWithAggregatesInput[]
    OR?: MessageScalarWhereWithAggregatesInput[]
    NOT?: MessageScalarWhereWithAggregatesInput | MessageScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Message"> | string
    userId?: StringWithAggregatesFilter<"Message"> | string
    recipientName?: StringWithAggregatesFilter<"Message"> | string
    recipientEmail?: StringNullableWithAggregatesFilter<"Message"> | string | null
    type?: StringWithAggregatesFilter<"Message"> | string
    subject?: StringNullableWithAggregatesFilter<"Message"> | string | null
    content?: StringNullableWithAggregatesFilter<"Message"> | string | null
    mediaUrl?: StringNullableWithAggregatesFilter<"Message"> | string | null
    mediaBlobPath?: StringNullableWithAggregatesFilter<"Message"> | string | null
    mediaDurationSec?: IntNullableWithAggregatesFilter<"Message"> | number | null
    triggerDate?: DateTimeNullableWithAggregatesFilter<"Message"> | Date | string | null
    state?: StringWithAggregatesFilter<"Message"> | string
    approvalPromptedAt?: DateTimeNullableWithAggregatesFilter<"Message"> | Date | string | null
    approvalExpiresAt?: DateTimeNullableWithAggregatesFilter<"Message"> | Date | string | null
    sentAt?: DateTimeNullableWithAggregatesFilter<"Message"> | Date | string | null
    archivedAt?: DateTimeNullableWithAggregatesFilter<"Message"> | Date | string | null
    deliveryToken?: StringNullableWithAggregatesFilter<"Message"> | string | null
    approvalToken?: StringNullableWithAggregatesFilter<"Message"> | string | null
    approvalRemindersSent?: IntWithAggregatesFilter<"Message"> | number
    createdAt?: DateTimeWithAggregatesFilter<"Message"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"Message"> | Date | string
  }

  export type MessageInviteWhereInput = {
    AND?: MessageInviteWhereInput | MessageInviteWhereInput[]
    OR?: MessageInviteWhereInput[]
    NOT?: MessageInviteWhereInput | MessageInviteWhereInput[]
    id?: StringFilter<"MessageInvite"> | string
    userId?: StringFilter<"MessageInvite"> | string
    token?: StringFilter<"MessageInvite"> | string
    contributorName?: StringFilter<"MessageInvite"> | string
    contributorEmail?: StringNullableFilter<"MessageInvite"> | string | null
    message?: StringNullableFilter<"MessageInvite"> | string | null
    expiresAt?: DateTimeFilter<"MessageInvite"> | Date | string
    revokedAt?: DateTimeNullableFilter<"MessageInvite"> | Date | string | null
    lastUsedAt?: DateTimeNullableFilter<"MessageInvite"> | Date | string | null
    useCount?: IntFilter<"MessageInvite"> | number
    createdAt?: DateTimeFilter<"MessageInvite"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    contributions?: ContributionListRelationFilter
  }

  export type MessageInviteOrderByWithRelationInput = {
    id?: SortOrder
    userId?: SortOrder
    token?: SortOrder
    contributorName?: SortOrder
    contributorEmail?: SortOrderInput | SortOrder
    message?: SortOrderInput | SortOrder
    expiresAt?: SortOrder
    revokedAt?: SortOrderInput | SortOrder
    lastUsedAt?: SortOrderInput | SortOrder
    useCount?: SortOrder
    createdAt?: SortOrder
    user?: UserOrderByWithRelationInput
    contributions?: ContributionOrderByRelationAggregateInput
  }

  export type MessageInviteWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    token?: string
    AND?: MessageInviteWhereInput | MessageInviteWhereInput[]
    OR?: MessageInviteWhereInput[]
    NOT?: MessageInviteWhereInput | MessageInviteWhereInput[]
    userId?: StringFilter<"MessageInvite"> | string
    contributorName?: StringFilter<"MessageInvite"> | string
    contributorEmail?: StringNullableFilter<"MessageInvite"> | string | null
    message?: StringNullableFilter<"MessageInvite"> | string | null
    expiresAt?: DateTimeFilter<"MessageInvite"> | Date | string
    revokedAt?: DateTimeNullableFilter<"MessageInvite"> | Date | string | null
    lastUsedAt?: DateTimeNullableFilter<"MessageInvite"> | Date | string | null
    useCount?: IntFilter<"MessageInvite"> | number
    createdAt?: DateTimeFilter<"MessageInvite"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    contributions?: ContributionListRelationFilter
  }, "id" | "token">

  export type MessageInviteOrderByWithAggregationInput = {
    id?: SortOrder
    userId?: SortOrder
    token?: SortOrder
    contributorName?: SortOrder
    contributorEmail?: SortOrderInput | SortOrder
    message?: SortOrderInput | SortOrder
    expiresAt?: SortOrder
    revokedAt?: SortOrderInput | SortOrder
    lastUsedAt?: SortOrderInput | SortOrder
    useCount?: SortOrder
    createdAt?: SortOrder
    _count?: MessageInviteCountOrderByAggregateInput
    _avg?: MessageInviteAvgOrderByAggregateInput
    _max?: MessageInviteMaxOrderByAggregateInput
    _min?: MessageInviteMinOrderByAggregateInput
    _sum?: MessageInviteSumOrderByAggregateInput
  }

  export type MessageInviteScalarWhereWithAggregatesInput = {
    AND?: MessageInviteScalarWhereWithAggregatesInput | MessageInviteScalarWhereWithAggregatesInput[]
    OR?: MessageInviteScalarWhereWithAggregatesInput[]
    NOT?: MessageInviteScalarWhereWithAggregatesInput | MessageInviteScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"MessageInvite"> | string
    userId?: StringWithAggregatesFilter<"MessageInvite"> | string
    token?: StringWithAggregatesFilter<"MessageInvite"> | string
    contributorName?: StringWithAggregatesFilter<"MessageInvite"> | string
    contributorEmail?: StringNullableWithAggregatesFilter<"MessageInvite"> | string | null
    message?: StringNullableWithAggregatesFilter<"MessageInvite"> | string | null
    expiresAt?: DateTimeWithAggregatesFilter<"MessageInvite"> | Date | string
    revokedAt?: DateTimeNullableWithAggregatesFilter<"MessageInvite"> | Date | string | null
    lastUsedAt?: DateTimeNullableWithAggregatesFilter<"MessageInvite"> | Date | string | null
    useCount?: IntWithAggregatesFilter<"MessageInvite"> | number
    createdAt?: DateTimeWithAggregatesFilter<"MessageInvite"> | Date | string
  }

  export type ContributionWhereInput = {
    AND?: ContributionWhereInput | ContributionWhereInput[]
    OR?: ContributionWhereInput[]
    NOT?: ContributionWhereInput | ContributionWhereInput[]
    id?: StringFilter<"Contribution"> | string
    userId?: StringFilter<"Contribution"> | string
    inviteId?: StringFilter<"Contribution"> | string
    contributorName?: StringFilter<"Contribution"> | string
    contributorNote?: StringNullableFilter<"Contribution"> | string | null
    type?: StringFilter<"Contribution"> | string
    content?: StringNullableFilter<"Contribution"> | string | null
    mediaUrl?: StringNullableFilter<"Contribution"> | string | null
    mediaBlobPath?: StringNullableFilter<"Contribution"> | string | null
    viewedByUser?: BoolFilter<"Contribution"> | boolean
    importedToTimelineItemId?: StringNullableFilter<"Contribution"> | string | null
    archivedAt?: DateTimeNullableFilter<"Contribution"> | Date | string | null
    createdAt?: DateTimeFilter<"Contribution"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    invite?: XOR<MessageInviteScalarRelationFilter, MessageInviteWhereInput>
  }

  export type ContributionOrderByWithRelationInput = {
    id?: SortOrder
    userId?: SortOrder
    inviteId?: SortOrder
    contributorName?: SortOrder
    contributorNote?: SortOrderInput | SortOrder
    type?: SortOrder
    content?: SortOrderInput | SortOrder
    mediaUrl?: SortOrderInput | SortOrder
    mediaBlobPath?: SortOrderInput | SortOrder
    viewedByUser?: SortOrder
    importedToTimelineItemId?: SortOrderInput | SortOrder
    archivedAt?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    user?: UserOrderByWithRelationInput
    invite?: MessageInviteOrderByWithRelationInput
  }

  export type ContributionWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: ContributionWhereInput | ContributionWhereInput[]
    OR?: ContributionWhereInput[]
    NOT?: ContributionWhereInput | ContributionWhereInput[]
    userId?: StringFilter<"Contribution"> | string
    inviteId?: StringFilter<"Contribution"> | string
    contributorName?: StringFilter<"Contribution"> | string
    contributorNote?: StringNullableFilter<"Contribution"> | string | null
    type?: StringFilter<"Contribution"> | string
    content?: StringNullableFilter<"Contribution"> | string | null
    mediaUrl?: StringNullableFilter<"Contribution"> | string | null
    mediaBlobPath?: StringNullableFilter<"Contribution"> | string | null
    viewedByUser?: BoolFilter<"Contribution"> | boolean
    importedToTimelineItemId?: StringNullableFilter<"Contribution"> | string | null
    archivedAt?: DateTimeNullableFilter<"Contribution"> | Date | string | null
    createdAt?: DateTimeFilter<"Contribution"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    invite?: XOR<MessageInviteScalarRelationFilter, MessageInviteWhereInput>
  }, "id">

  export type ContributionOrderByWithAggregationInput = {
    id?: SortOrder
    userId?: SortOrder
    inviteId?: SortOrder
    contributorName?: SortOrder
    contributorNote?: SortOrderInput | SortOrder
    type?: SortOrder
    content?: SortOrderInput | SortOrder
    mediaUrl?: SortOrderInput | SortOrder
    mediaBlobPath?: SortOrderInput | SortOrder
    viewedByUser?: SortOrder
    importedToTimelineItemId?: SortOrderInput | SortOrder
    archivedAt?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    _count?: ContributionCountOrderByAggregateInput
    _max?: ContributionMaxOrderByAggregateInput
    _min?: ContributionMinOrderByAggregateInput
  }

  export type ContributionScalarWhereWithAggregatesInput = {
    AND?: ContributionScalarWhereWithAggregatesInput | ContributionScalarWhereWithAggregatesInput[]
    OR?: ContributionScalarWhereWithAggregatesInput[]
    NOT?: ContributionScalarWhereWithAggregatesInput | ContributionScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Contribution"> | string
    userId?: StringWithAggregatesFilter<"Contribution"> | string
    inviteId?: StringWithAggregatesFilter<"Contribution"> | string
    contributorName?: StringWithAggregatesFilter<"Contribution"> | string
    contributorNote?: StringNullableWithAggregatesFilter<"Contribution"> | string | null
    type?: StringWithAggregatesFilter<"Contribution"> | string
    content?: StringNullableWithAggregatesFilter<"Contribution"> | string | null
    mediaUrl?: StringNullableWithAggregatesFilter<"Contribution"> | string | null
    mediaBlobPath?: StringNullableWithAggregatesFilter<"Contribution"> | string | null
    viewedByUser?: BoolWithAggregatesFilter<"Contribution"> | boolean
    importedToTimelineItemId?: StringNullableWithAggregatesFilter<"Contribution"> | string | null
    archivedAt?: DateTimeNullableWithAggregatesFilter<"Contribution"> | Date | string | null
    createdAt?: DateTimeWithAggregatesFilter<"Contribution"> | Date | string
  }

  export type TimelineItemWhereInput = {
    AND?: TimelineItemWhereInput | TimelineItemWhereInput[]
    OR?: TimelineItemWhereInput[]
    NOT?: TimelineItemWhereInput | TimelineItemWhereInput[]
    id?: StringFilter<"TimelineItem"> | string
    userId?: StringFilter<"TimelineItem"> | string
    date?: DateTimeFilter<"TimelineItem"> | Date | string
    title?: StringFilter<"TimelineItem"> | string
    story?: StringNullableFilter<"TimelineItem"> | string | null
    mediaUrl?: StringNullableFilter<"TimelineItem"> | string | null
    createdAt?: DateTimeFilter<"TimelineItem"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    photos?: PhotoListRelationFilter
  }

  export type TimelineItemOrderByWithRelationInput = {
    id?: SortOrder
    userId?: SortOrder
    date?: SortOrder
    title?: SortOrder
    story?: SortOrderInput | SortOrder
    mediaUrl?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    user?: UserOrderByWithRelationInput
    photos?: PhotoOrderByRelationAggregateInput
  }

  export type TimelineItemWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: TimelineItemWhereInput | TimelineItemWhereInput[]
    OR?: TimelineItemWhereInput[]
    NOT?: TimelineItemWhereInput | TimelineItemWhereInput[]
    userId?: StringFilter<"TimelineItem"> | string
    date?: DateTimeFilter<"TimelineItem"> | Date | string
    title?: StringFilter<"TimelineItem"> | string
    story?: StringNullableFilter<"TimelineItem"> | string | null
    mediaUrl?: StringNullableFilter<"TimelineItem"> | string | null
    createdAt?: DateTimeFilter<"TimelineItem"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    photos?: PhotoListRelationFilter
  }, "id">

  export type TimelineItemOrderByWithAggregationInput = {
    id?: SortOrder
    userId?: SortOrder
    date?: SortOrder
    title?: SortOrder
    story?: SortOrderInput | SortOrder
    mediaUrl?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    _count?: TimelineItemCountOrderByAggregateInput
    _max?: TimelineItemMaxOrderByAggregateInput
    _min?: TimelineItemMinOrderByAggregateInput
  }

  export type TimelineItemScalarWhereWithAggregatesInput = {
    AND?: TimelineItemScalarWhereWithAggregatesInput | TimelineItemScalarWhereWithAggregatesInput[]
    OR?: TimelineItemScalarWhereWithAggregatesInput[]
    NOT?: TimelineItemScalarWhereWithAggregatesInput | TimelineItemScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"TimelineItem"> | string
    userId?: StringWithAggregatesFilter<"TimelineItem"> | string
    date?: DateTimeWithAggregatesFilter<"TimelineItem"> | Date | string
    title?: StringWithAggregatesFilter<"TimelineItem"> | string
    story?: StringNullableWithAggregatesFilter<"TimelineItem"> | string | null
    mediaUrl?: StringNullableWithAggregatesFilter<"TimelineItem"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"TimelineItem"> | Date | string
  }

  export type PhotoWhereInput = {
    AND?: PhotoWhereInput | PhotoWhereInput[]
    OR?: PhotoWhereInput[]
    NOT?: PhotoWhereInput | PhotoWhereInput[]
    id?: StringFilter<"Photo"> | string
    userId?: StringFilter<"Photo"> | string
    timelineItemId?: StringNullableFilter<"Photo"> | string | null
    url?: StringFilter<"Photo"> | string
    thumbnailUrl?: StringNullableFilter<"Photo"> | string | null
    blobPath?: StringFilter<"Photo"> | string
    caption?: StringNullableFilter<"Photo"> | string | null
    width?: IntNullableFilter<"Photo"> | number | null
    height?: IntNullableFilter<"Photo"> | number | null
    sizeBytes?: IntNullableFilter<"Photo"> | number | null
    order?: IntFilter<"Photo"> | number
    createdAt?: DateTimeFilter<"Photo"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    timelineItem?: XOR<TimelineItemNullableScalarRelationFilter, TimelineItemWhereInput> | null
  }

  export type PhotoOrderByWithRelationInput = {
    id?: SortOrder
    userId?: SortOrder
    timelineItemId?: SortOrderInput | SortOrder
    url?: SortOrder
    thumbnailUrl?: SortOrderInput | SortOrder
    blobPath?: SortOrder
    caption?: SortOrderInput | SortOrder
    width?: SortOrderInput | SortOrder
    height?: SortOrderInput | SortOrder
    sizeBytes?: SortOrderInput | SortOrder
    order?: SortOrder
    createdAt?: SortOrder
    user?: UserOrderByWithRelationInput
    timelineItem?: TimelineItemOrderByWithRelationInput
  }

  export type PhotoWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: PhotoWhereInput | PhotoWhereInput[]
    OR?: PhotoWhereInput[]
    NOT?: PhotoWhereInput | PhotoWhereInput[]
    userId?: StringFilter<"Photo"> | string
    timelineItemId?: StringNullableFilter<"Photo"> | string | null
    url?: StringFilter<"Photo"> | string
    thumbnailUrl?: StringNullableFilter<"Photo"> | string | null
    blobPath?: StringFilter<"Photo"> | string
    caption?: StringNullableFilter<"Photo"> | string | null
    width?: IntNullableFilter<"Photo"> | number | null
    height?: IntNullableFilter<"Photo"> | number | null
    sizeBytes?: IntNullableFilter<"Photo"> | number | null
    order?: IntFilter<"Photo"> | number
    createdAt?: DateTimeFilter<"Photo"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
    timelineItem?: XOR<TimelineItemNullableScalarRelationFilter, TimelineItemWhereInput> | null
  }, "id">

  export type PhotoOrderByWithAggregationInput = {
    id?: SortOrder
    userId?: SortOrder
    timelineItemId?: SortOrderInput | SortOrder
    url?: SortOrder
    thumbnailUrl?: SortOrderInput | SortOrder
    blobPath?: SortOrder
    caption?: SortOrderInput | SortOrder
    width?: SortOrderInput | SortOrder
    height?: SortOrderInput | SortOrder
    sizeBytes?: SortOrderInput | SortOrder
    order?: SortOrder
    createdAt?: SortOrder
    _count?: PhotoCountOrderByAggregateInput
    _avg?: PhotoAvgOrderByAggregateInput
    _max?: PhotoMaxOrderByAggregateInput
    _min?: PhotoMinOrderByAggregateInput
    _sum?: PhotoSumOrderByAggregateInput
  }

  export type PhotoScalarWhereWithAggregatesInput = {
    AND?: PhotoScalarWhereWithAggregatesInput | PhotoScalarWhereWithAggregatesInput[]
    OR?: PhotoScalarWhereWithAggregatesInput[]
    NOT?: PhotoScalarWhereWithAggregatesInput | PhotoScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Photo"> | string
    userId?: StringWithAggregatesFilter<"Photo"> | string
    timelineItemId?: StringNullableWithAggregatesFilter<"Photo"> | string | null
    url?: StringWithAggregatesFilter<"Photo"> | string
    thumbnailUrl?: StringNullableWithAggregatesFilter<"Photo"> | string | null
    blobPath?: StringWithAggregatesFilter<"Photo"> | string
    caption?: StringNullableWithAggregatesFilter<"Photo"> | string | null
    width?: IntNullableWithAggregatesFilter<"Photo"> | number | null
    height?: IntNullableWithAggregatesFilter<"Photo"> | number | null
    sizeBytes?: IntNullableWithAggregatesFilter<"Photo"> | number | null
    order?: IntWithAggregatesFilter<"Photo"> | number
    createdAt?: DateTimeWithAggregatesFilter<"Photo"> | Date | string
  }

  export type ArrangementWhereInput = {
    AND?: ArrangementWhereInput | ArrangementWhereInput[]
    OR?: ArrangementWhereInput[]
    NOT?: ArrangementWhereInput | ArrangementWhereInput[]
    id?: StringFilter<"Arrangement"> | string
    userId?: StringFilter<"Arrangement"> | string
    type?: StringFilter<"Arrangement"> | string
    vendor?: StringFilter<"Arrangement"> | string
    contact?: StringNullableFilter<"Arrangement"> | string | null
    notes?: StringNullableFilter<"Arrangement"> | string | null
    createdAt?: DateTimeFilter<"Arrangement"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
  }

  export type ArrangementOrderByWithRelationInput = {
    id?: SortOrder
    userId?: SortOrder
    type?: SortOrder
    vendor?: SortOrder
    contact?: SortOrderInput | SortOrder
    notes?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    user?: UserOrderByWithRelationInput
  }

  export type ArrangementWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: ArrangementWhereInput | ArrangementWhereInput[]
    OR?: ArrangementWhereInput[]
    NOT?: ArrangementWhereInput | ArrangementWhereInput[]
    userId?: StringFilter<"Arrangement"> | string
    type?: StringFilter<"Arrangement"> | string
    vendor?: StringFilter<"Arrangement"> | string
    contact?: StringNullableFilter<"Arrangement"> | string | null
    notes?: StringNullableFilter<"Arrangement"> | string | null
    createdAt?: DateTimeFilter<"Arrangement"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
  }, "id">

  export type ArrangementOrderByWithAggregationInput = {
    id?: SortOrder
    userId?: SortOrder
    type?: SortOrder
    vendor?: SortOrder
    contact?: SortOrderInput | SortOrder
    notes?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    _count?: ArrangementCountOrderByAggregateInput
    _max?: ArrangementMaxOrderByAggregateInput
    _min?: ArrangementMinOrderByAggregateInput
  }

  export type ArrangementScalarWhereWithAggregatesInput = {
    AND?: ArrangementScalarWhereWithAggregatesInput | ArrangementScalarWhereWithAggregatesInput[]
    OR?: ArrangementScalarWhereWithAggregatesInput[]
    NOT?: ArrangementScalarWhereWithAggregatesInput | ArrangementScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Arrangement"> | string
    userId?: StringWithAggregatesFilter<"Arrangement"> | string
    type?: StringWithAggregatesFilter<"Arrangement"> | string
    vendor?: StringWithAggregatesFilter<"Arrangement"> | string
    contact?: StringNullableWithAggregatesFilter<"Arrangement"> | string | null
    notes?: StringNullableWithAggregatesFilter<"Arrangement"> | string | null
    createdAt?: DateTimeWithAggregatesFilter<"Arrangement"> | Date | string
  }

  export type VaultItemWhereInput = {
    AND?: VaultItemWhereInput | VaultItemWhereInput[]
    OR?: VaultItemWhereInput[]
    NOT?: VaultItemWhereInput | VaultItemWhereInput[]
    id?: StringFilter<"VaultItem"> | string
    userId?: StringFilter<"VaultItem"> | string
    label?: StringFilter<"VaultItem"> | string
    encryptedData?: StringFilter<"VaultItem"> | string
    createdAt?: DateTimeFilter<"VaultItem"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
  }

  export type VaultItemOrderByWithRelationInput = {
    id?: SortOrder
    userId?: SortOrder
    label?: SortOrder
    encryptedData?: SortOrder
    createdAt?: SortOrder
    user?: UserOrderByWithRelationInput
  }

  export type VaultItemWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    AND?: VaultItemWhereInput | VaultItemWhereInput[]
    OR?: VaultItemWhereInput[]
    NOT?: VaultItemWhereInput | VaultItemWhereInput[]
    userId?: StringFilter<"VaultItem"> | string
    label?: StringFilter<"VaultItem"> | string
    encryptedData?: StringFilter<"VaultItem"> | string
    createdAt?: DateTimeFilter<"VaultItem"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
  }, "id">

  export type VaultItemOrderByWithAggregationInput = {
    id?: SortOrder
    userId?: SortOrder
    label?: SortOrder
    encryptedData?: SortOrder
    createdAt?: SortOrder
    _count?: VaultItemCountOrderByAggregateInput
    _max?: VaultItemMaxOrderByAggregateInput
    _min?: VaultItemMinOrderByAggregateInput
  }

  export type VaultItemScalarWhereWithAggregatesInput = {
    AND?: VaultItemScalarWhereWithAggregatesInput | VaultItemScalarWhereWithAggregatesInput[]
    OR?: VaultItemScalarWhereWithAggregatesInput[]
    NOT?: VaultItemScalarWhereWithAggregatesInput | VaultItemScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"VaultItem"> | string
    userId?: StringWithAggregatesFilter<"VaultItem"> | string
    label?: StringWithAggregatesFilter<"VaultItem"> | string
    encryptedData?: StringWithAggregatesFilter<"VaultItem"> | string
    createdAt?: DateTimeWithAggregatesFilter<"VaultItem"> | Date | string
  }

  export type ExecutorWhereInput = {
    AND?: ExecutorWhereInput | ExecutorWhereInput[]
    OR?: ExecutorWhereInput[]
    NOT?: ExecutorWhereInput | ExecutorWhereInput[]
    id?: StringFilter<"Executor"> | string
    userId?: StringFilter<"Executor"> | string
    name?: StringFilter<"Executor"> | string
    email?: StringFilter<"Executor"> | string
    phone?: StringNullableFilter<"Executor"> | string | null
    verified?: BoolFilter<"Executor"> | boolean
    certUploadedAt?: DateTimeNullableFilter<"Executor"> | Date | string | null
    unlockedAt?: DateTimeNullableFilter<"Executor"> | Date | string | null
    createdAt?: DateTimeFilter<"Executor"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
  }

  export type ExecutorOrderByWithRelationInput = {
    id?: SortOrder
    userId?: SortOrder
    name?: SortOrder
    email?: SortOrder
    phone?: SortOrderInput | SortOrder
    verified?: SortOrder
    certUploadedAt?: SortOrderInput | SortOrder
    unlockedAt?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    user?: UserOrderByWithRelationInput
  }

  export type ExecutorWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    userId?: string
    AND?: ExecutorWhereInput | ExecutorWhereInput[]
    OR?: ExecutorWhereInput[]
    NOT?: ExecutorWhereInput | ExecutorWhereInput[]
    name?: StringFilter<"Executor"> | string
    email?: StringFilter<"Executor"> | string
    phone?: StringNullableFilter<"Executor"> | string | null
    verified?: BoolFilter<"Executor"> | boolean
    certUploadedAt?: DateTimeNullableFilter<"Executor"> | Date | string | null
    unlockedAt?: DateTimeNullableFilter<"Executor"> | Date | string | null
    createdAt?: DateTimeFilter<"Executor"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
  }, "id" | "userId">

  export type ExecutorOrderByWithAggregationInput = {
    id?: SortOrder
    userId?: SortOrder
    name?: SortOrder
    email?: SortOrder
    phone?: SortOrderInput | SortOrder
    verified?: SortOrder
    certUploadedAt?: SortOrderInput | SortOrder
    unlockedAt?: SortOrderInput | SortOrder
    createdAt?: SortOrder
    _count?: ExecutorCountOrderByAggregateInput
    _max?: ExecutorMaxOrderByAggregateInput
    _min?: ExecutorMinOrderByAggregateInput
  }

  export type ExecutorScalarWhereWithAggregatesInput = {
    AND?: ExecutorScalarWhereWithAggregatesInput | ExecutorScalarWhereWithAggregatesInput[]
    OR?: ExecutorScalarWhereWithAggregatesInput[]
    NOT?: ExecutorScalarWhereWithAggregatesInput | ExecutorScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Executor"> | string
    userId?: StringWithAggregatesFilter<"Executor"> | string
    name?: StringWithAggregatesFilter<"Executor"> | string
    email?: StringWithAggregatesFilter<"Executor"> | string
    phone?: StringNullableWithAggregatesFilter<"Executor"> | string | null
    verified?: BoolWithAggregatesFilter<"Executor"> | boolean
    certUploadedAt?: DateTimeNullableWithAggregatesFilter<"Executor"> | Date | string | null
    unlockedAt?: DateTimeNullableWithAggregatesFilter<"Executor"> | Date | string | null
    createdAt?: DateTimeWithAggregatesFilter<"Executor"> | Date | string
  }

  export type SettingsWhereInput = {
    AND?: SettingsWhereInput | SettingsWhereInput[]
    OR?: SettingsWhereInput[]
    NOT?: SettingsWhereInput | SettingsWhereInput[]
    id?: StringFilter<"Settings"> | string
    userId?: StringFilter<"Settings"> | string
    pageTurnStyle?: StringFilter<"Settings"> | string
    fontScale?: StringFilter<"Settings"> | string
    highContrast?: BoolFilter<"Settings"> | boolean
    ttsEnabled?: BoolFilter<"Settings"> | boolean
    sttEnabled?: BoolFilter<"Settings"> | boolean
    reducedMotion?: BoolFilter<"Settings"> | boolean
    createdAt?: DateTimeFilter<"Settings"> | Date | string
    updatedAt?: DateTimeFilter<"Settings"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
  }

  export type SettingsOrderByWithRelationInput = {
    id?: SortOrder
    userId?: SortOrder
    pageTurnStyle?: SortOrder
    fontScale?: SortOrder
    highContrast?: SortOrder
    ttsEnabled?: SortOrder
    sttEnabled?: SortOrder
    reducedMotion?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    user?: UserOrderByWithRelationInput
  }

  export type SettingsWhereUniqueInput = Prisma.AtLeast<{
    id?: string
    userId?: string
    AND?: SettingsWhereInput | SettingsWhereInput[]
    OR?: SettingsWhereInput[]
    NOT?: SettingsWhereInput | SettingsWhereInput[]
    pageTurnStyle?: StringFilter<"Settings"> | string
    fontScale?: StringFilter<"Settings"> | string
    highContrast?: BoolFilter<"Settings"> | boolean
    ttsEnabled?: BoolFilter<"Settings"> | boolean
    sttEnabled?: BoolFilter<"Settings"> | boolean
    reducedMotion?: BoolFilter<"Settings"> | boolean
    createdAt?: DateTimeFilter<"Settings"> | Date | string
    updatedAt?: DateTimeFilter<"Settings"> | Date | string
    user?: XOR<UserScalarRelationFilter, UserWhereInput>
  }, "id" | "userId">

  export type SettingsOrderByWithAggregationInput = {
    id?: SortOrder
    userId?: SortOrder
    pageTurnStyle?: SortOrder
    fontScale?: SortOrder
    highContrast?: SortOrder
    ttsEnabled?: SortOrder
    sttEnabled?: SortOrder
    reducedMotion?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
    _count?: SettingsCountOrderByAggregateInput
    _max?: SettingsMaxOrderByAggregateInput
    _min?: SettingsMinOrderByAggregateInput
  }

  export type SettingsScalarWhereWithAggregatesInput = {
    AND?: SettingsScalarWhereWithAggregatesInput | SettingsScalarWhereWithAggregatesInput[]
    OR?: SettingsScalarWhereWithAggregatesInput[]
    NOT?: SettingsScalarWhereWithAggregatesInput | SettingsScalarWhereWithAggregatesInput[]
    id?: StringWithAggregatesFilter<"Settings"> | string
    userId?: StringWithAggregatesFilter<"Settings"> | string
    pageTurnStyle?: StringWithAggregatesFilter<"Settings"> | string
    fontScale?: StringWithAggregatesFilter<"Settings"> | string
    highContrast?: BoolWithAggregatesFilter<"Settings"> | boolean
    ttsEnabled?: BoolWithAggregatesFilter<"Settings"> | boolean
    sttEnabled?: BoolWithAggregatesFilter<"Settings"> | boolean
    reducedMotion?: BoolWithAggregatesFilter<"Settings"> | boolean
    createdAt?: DateTimeWithAggregatesFilter<"Settings"> | Date | string
    updatedAt?: DateTimeWithAggregatesFilter<"Settings"> | Date | string
  }

  export type UserCreateInput = {
    id?: string
    email: string
    name?: string | null
    plan?: string
    pendingDeathVerificationAt?: Date | string | null
    deceasedAt?: Date | string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    contacts?: ContactCreateNestedManyWithoutUserInput
    messages?: MessageCreateNestedManyWithoutUserInput
    arrangements?: ArrangementCreateNestedManyWithoutUserInput
    timelineItems?: TimelineItemCreateNestedManyWithoutUserInput
    vaultItems?: VaultItemCreateNestedManyWithoutUserInput
    executor?: ExecutorCreateNestedOneWithoutUserInput
    photos?: PhotoCreateNestedManyWithoutUserInput
    settings?: SettingsCreateNestedOneWithoutUserInput
    messageInvites?: MessageInviteCreateNestedManyWithoutUserInput
    contributions?: ContributionCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateInput = {
    id?: string
    email: string
    name?: string | null
    plan?: string
    pendingDeathVerificationAt?: Date | string | null
    deceasedAt?: Date | string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    contacts?: ContactUncheckedCreateNestedManyWithoutUserInput
    messages?: MessageUncheckedCreateNestedManyWithoutUserInput
    arrangements?: ArrangementUncheckedCreateNestedManyWithoutUserInput
    timelineItems?: TimelineItemUncheckedCreateNestedManyWithoutUserInput
    vaultItems?: VaultItemUncheckedCreateNestedManyWithoutUserInput
    executor?: ExecutorUncheckedCreateNestedOneWithoutUserInput
    photos?: PhotoUncheckedCreateNestedManyWithoutUserInput
    settings?: SettingsUncheckedCreateNestedOneWithoutUserInput
    messageInvites?: MessageInviteUncheckedCreateNestedManyWithoutUserInput
    contributions?: ContributionUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    plan?: StringFieldUpdateOperationsInput | string
    pendingDeathVerificationAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    deceasedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    contacts?: ContactUpdateManyWithoutUserNestedInput
    messages?: MessageUpdateManyWithoutUserNestedInput
    arrangements?: ArrangementUpdateManyWithoutUserNestedInput
    timelineItems?: TimelineItemUpdateManyWithoutUserNestedInput
    vaultItems?: VaultItemUpdateManyWithoutUserNestedInput
    executor?: ExecutorUpdateOneWithoutUserNestedInput
    photos?: PhotoUpdateManyWithoutUserNestedInput
    settings?: SettingsUpdateOneWithoutUserNestedInput
    messageInvites?: MessageInviteUpdateManyWithoutUserNestedInput
    contributions?: ContributionUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    plan?: StringFieldUpdateOperationsInput | string
    pendingDeathVerificationAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    deceasedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    contacts?: ContactUncheckedUpdateManyWithoutUserNestedInput
    messages?: MessageUncheckedUpdateManyWithoutUserNestedInput
    arrangements?: ArrangementUncheckedUpdateManyWithoutUserNestedInput
    timelineItems?: TimelineItemUncheckedUpdateManyWithoutUserNestedInput
    vaultItems?: VaultItemUncheckedUpdateManyWithoutUserNestedInput
    executor?: ExecutorUncheckedUpdateOneWithoutUserNestedInput
    photos?: PhotoUncheckedUpdateManyWithoutUserNestedInput
    settings?: SettingsUncheckedUpdateOneWithoutUserNestedInput
    messageInvites?: MessageInviteUncheckedUpdateManyWithoutUserNestedInput
    contributions?: ContributionUncheckedUpdateManyWithoutUserNestedInput
  }

  export type UserCreateManyInput = {
    id?: string
    email: string
    name?: string | null
    plan?: string
    pendingDeathVerificationAt?: Date | string | null
    deceasedAt?: Date | string | null
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type UserUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    plan?: StringFieldUpdateOperationsInput | string
    pendingDeathVerificationAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    deceasedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type UserUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    plan?: StringFieldUpdateOperationsInput | string
    pendingDeathVerificationAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    deceasedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ContactCreateInput = {
    id?: string
    name: string
    email?: string | null
    phone?: string | null
    relationship?: string | null
    isExecutor?: boolean
    isBackup?: boolean
    createdAt?: Date | string
    user: UserCreateNestedOneWithoutContactsInput
  }

  export type ContactUncheckedCreateInput = {
    id?: string
    userId: string
    name: string
    email?: string | null
    phone?: string | null
    relationship?: string | null
    isExecutor?: boolean
    isBackup?: boolean
    createdAt?: Date | string
  }

  export type ContactUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    relationship?: NullableStringFieldUpdateOperationsInput | string | null
    isExecutor?: BoolFieldUpdateOperationsInput | boolean
    isBackup?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutContactsNestedInput
  }

  export type ContactUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    relationship?: NullableStringFieldUpdateOperationsInput | string | null
    isExecutor?: BoolFieldUpdateOperationsInput | boolean
    isBackup?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ContactCreateManyInput = {
    id?: string
    userId: string
    name: string
    email?: string | null
    phone?: string | null
    relationship?: string | null
    isExecutor?: boolean
    isBackup?: boolean
    createdAt?: Date | string
  }

  export type ContactUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    relationship?: NullableStringFieldUpdateOperationsInput | string | null
    isExecutor?: BoolFieldUpdateOperationsInput | boolean
    isBackup?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ContactUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    relationship?: NullableStringFieldUpdateOperationsInput | string | null
    isExecutor?: BoolFieldUpdateOperationsInput | boolean
    isBackup?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type MessageCreateInput = {
    id?: string
    recipientName: string
    recipientEmail?: string | null
    type?: string
    subject?: string | null
    content?: string | null
    mediaUrl?: string | null
    mediaBlobPath?: string | null
    mediaDurationSec?: number | null
    triggerDate?: Date | string | null
    state?: string
    approvalPromptedAt?: Date | string | null
    approvalExpiresAt?: Date | string | null
    sentAt?: Date | string | null
    archivedAt?: Date | string | null
    deliveryToken?: string | null
    approvalToken?: string | null
    approvalRemindersSent?: number
    createdAt?: Date | string
    updatedAt?: Date | string
    user: UserCreateNestedOneWithoutMessagesInput
  }

  export type MessageUncheckedCreateInput = {
    id?: string
    userId: string
    recipientName: string
    recipientEmail?: string | null
    type?: string
    subject?: string | null
    content?: string | null
    mediaUrl?: string | null
    mediaBlobPath?: string | null
    mediaDurationSec?: number | null
    triggerDate?: Date | string | null
    state?: string
    approvalPromptedAt?: Date | string | null
    approvalExpiresAt?: Date | string | null
    sentAt?: Date | string | null
    archivedAt?: Date | string | null
    deliveryToken?: string | null
    approvalToken?: string | null
    approvalRemindersSent?: number
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type MessageUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    recipientName?: StringFieldUpdateOperationsInput | string
    recipientEmail?: NullableStringFieldUpdateOperationsInput | string | null
    type?: StringFieldUpdateOperationsInput | string
    subject?: NullableStringFieldUpdateOperationsInput | string | null
    content?: NullableStringFieldUpdateOperationsInput | string | null
    mediaUrl?: NullableStringFieldUpdateOperationsInput | string | null
    mediaBlobPath?: NullableStringFieldUpdateOperationsInput | string | null
    mediaDurationSec?: NullableIntFieldUpdateOperationsInput | number | null
    triggerDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    state?: StringFieldUpdateOperationsInput | string
    approvalPromptedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    approvalExpiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    sentAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    archivedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    deliveryToken?: NullableStringFieldUpdateOperationsInput | string | null
    approvalToken?: NullableStringFieldUpdateOperationsInput | string | null
    approvalRemindersSent?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutMessagesNestedInput
  }

  export type MessageUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    recipientName?: StringFieldUpdateOperationsInput | string
    recipientEmail?: NullableStringFieldUpdateOperationsInput | string | null
    type?: StringFieldUpdateOperationsInput | string
    subject?: NullableStringFieldUpdateOperationsInput | string | null
    content?: NullableStringFieldUpdateOperationsInput | string | null
    mediaUrl?: NullableStringFieldUpdateOperationsInput | string | null
    mediaBlobPath?: NullableStringFieldUpdateOperationsInput | string | null
    mediaDurationSec?: NullableIntFieldUpdateOperationsInput | number | null
    triggerDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    state?: StringFieldUpdateOperationsInput | string
    approvalPromptedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    approvalExpiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    sentAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    archivedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    deliveryToken?: NullableStringFieldUpdateOperationsInput | string | null
    approvalToken?: NullableStringFieldUpdateOperationsInput | string | null
    approvalRemindersSent?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type MessageCreateManyInput = {
    id?: string
    userId: string
    recipientName: string
    recipientEmail?: string | null
    type?: string
    subject?: string | null
    content?: string | null
    mediaUrl?: string | null
    mediaBlobPath?: string | null
    mediaDurationSec?: number | null
    triggerDate?: Date | string | null
    state?: string
    approvalPromptedAt?: Date | string | null
    approvalExpiresAt?: Date | string | null
    sentAt?: Date | string | null
    archivedAt?: Date | string | null
    deliveryToken?: string | null
    approvalToken?: string | null
    approvalRemindersSent?: number
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type MessageUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    recipientName?: StringFieldUpdateOperationsInput | string
    recipientEmail?: NullableStringFieldUpdateOperationsInput | string | null
    type?: StringFieldUpdateOperationsInput | string
    subject?: NullableStringFieldUpdateOperationsInput | string | null
    content?: NullableStringFieldUpdateOperationsInput | string | null
    mediaUrl?: NullableStringFieldUpdateOperationsInput | string | null
    mediaBlobPath?: NullableStringFieldUpdateOperationsInput | string | null
    mediaDurationSec?: NullableIntFieldUpdateOperationsInput | number | null
    triggerDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    state?: StringFieldUpdateOperationsInput | string
    approvalPromptedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    approvalExpiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    sentAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    archivedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    deliveryToken?: NullableStringFieldUpdateOperationsInput | string | null
    approvalToken?: NullableStringFieldUpdateOperationsInput | string | null
    approvalRemindersSent?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type MessageUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    recipientName?: StringFieldUpdateOperationsInput | string
    recipientEmail?: NullableStringFieldUpdateOperationsInput | string | null
    type?: StringFieldUpdateOperationsInput | string
    subject?: NullableStringFieldUpdateOperationsInput | string | null
    content?: NullableStringFieldUpdateOperationsInput | string | null
    mediaUrl?: NullableStringFieldUpdateOperationsInput | string | null
    mediaBlobPath?: NullableStringFieldUpdateOperationsInput | string | null
    mediaDurationSec?: NullableIntFieldUpdateOperationsInput | number | null
    triggerDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    state?: StringFieldUpdateOperationsInput | string
    approvalPromptedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    approvalExpiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    sentAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    archivedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    deliveryToken?: NullableStringFieldUpdateOperationsInput | string | null
    approvalToken?: NullableStringFieldUpdateOperationsInput | string | null
    approvalRemindersSent?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type MessageInviteCreateInput = {
    id?: string
    token: string
    contributorName: string
    contributorEmail?: string | null
    message?: string | null
    expiresAt: Date | string
    revokedAt?: Date | string | null
    lastUsedAt?: Date | string | null
    useCount?: number
    createdAt?: Date | string
    user: UserCreateNestedOneWithoutMessageInvitesInput
    contributions?: ContributionCreateNestedManyWithoutInviteInput
  }

  export type MessageInviteUncheckedCreateInput = {
    id?: string
    userId: string
    token: string
    contributorName: string
    contributorEmail?: string | null
    message?: string | null
    expiresAt: Date | string
    revokedAt?: Date | string | null
    lastUsedAt?: Date | string | null
    useCount?: number
    createdAt?: Date | string
    contributions?: ContributionUncheckedCreateNestedManyWithoutInviteInput
  }

  export type MessageInviteUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    contributorName?: StringFieldUpdateOperationsInput | string
    contributorEmail?: NullableStringFieldUpdateOperationsInput | string | null
    message?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: DateTimeFieldUpdateOperationsInput | Date | string
    revokedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    lastUsedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    useCount?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutMessageInvitesNestedInput
    contributions?: ContributionUpdateManyWithoutInviteNestedInput
  }

  export type MessageInviteUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    contributorName?: StringFieldUpdateOperationsInput | string
    contributorEmail?: NullableStringFieldUpdateOperationsInput | string | null
    message?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: DateTimeFieldUpdateOperationsInput | Date | string
    revokedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    lastUsedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    useCount?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    contributions?: ContributionUncheckedUpdateManyWithoutInviteNestedInput
  }

  export type MessageInviteCreateManyInput = {
    id?: string
    userId: string
    token: string
    contributorName: string
    contributorEmail?: string | null
    message?: string | null
    expiresAt: Date | string
    revokedAt?: Date | string | null
    lastUsedAt?: Date | string | null
    useCount?: number
    createdAt?: Date | string
  }

  export type MessageInviteUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    contributorName?: StringFieldUpdateOperationsInput | string
    contributorEmail?: NullableStringFieldUpdateOperationsInput | string | null
    message?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: DateTimeFieldUpdateOperationsInput | Date | string
    revokedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    lastUsedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    useCount?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type MessageInviteUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    contributorName?: StringFieldUpdateOperationsInput | string
    contributorEmail?: NullableStringFieldUpdateOperationsInput | string | null
    message?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: DateTimeFieldUpdateOperationsInput | Date | string
    revokedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    lastUsedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    useCount?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ContributionCreateInput = {
    id?: string
    contributorName: string
    contributorNote?: string | null
    type: string
    content?: string | null
    mediaUrl?: string | null
    mediaBlobPath?: string | null
    viewedByUser?: boolean
    importedToTimelineItemId?: string | null
    archivedAt?: Date | string | null
    createdAt?: Date | string
    user: UserCreateNestedOneWithoutContributionsInput
    invite: MessageInviteCreateNestedOneWithoutContributionsInput
  }

  export type ContributionUncheckedCreateInput = {
    id?: string
    userId: string
    inviteId: string
    contributorName: string
    contributorNote?: string | null
    type: string
    content?: string | null
    mediaUrl?: string | null
    mediaBlobPath?: string | null
    viewedByUser?: boolean
    importedToTimelineItemId?: string | null
    archivedAt?: Date | string | null
    createdAt?: Date | string
  }

  export type ContributionUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    contributorName?: StringFieldUpdateOperationsInput | string
    contributorNote?: NullableStringFieldUpdateOperationsInput | string | null
    type?: StringFieldUpdateOperationsInput | string
    content?: NullableStringFieldUpdateOperationsInput | string | null
    mediaUrl?: NullableStringFieldUpdateOperationsInput | string | null
    mediaBlobPath?: NullableStringFieldUpdateOperationsInput | string | null
    viewedByUser?: BoolFieldUpdateOperationsInput | boolean
    importedToTimelineItemId?: NullableStringFieldUpdateOperationsInput | string | null
    archivedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutContributionsNestedInput
    invite?: MessageInviteUpdateOneRequiredWithoutContributionsNestedInput
  }

  export type ContributionUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    inviteId?: StringFieldUpdateOperationsInput | string
    contributorName?: StringFieldUpdateOperationsInput | string
    contributorNote?: NullableStringFieldUpdateOperationsInput | string | null
    type?: StringFieldUpdateOperationsInput | string
    content?: NullableStringFieldUpdateOperationsInput | string | null
    mediaUrl?: NullableStringFieldUpdateOperationsInput | string | null
    mediaBlobPath?: NullableStringFieldUpdateOperationsInput | string | null
    viewedByUser?: BoolFieldUpdateOperationsInput | boolean
    importedToTimelineItemId?: NullableStringFieldUpdateOperationsInput | string | null
    archivedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ContributionCreateManyInput = {
    id?: string
    userId: string
    inviteId: string
    contributorName: string
    contributorNote?: string | null
    type: string
    content?: string | null
    mediaUrl?: string | null
    mediaBlobPath?: string | null
    viewedByUser?: boolean
    importedToTimelineItemId?: string | null
    archivedAt?: Date | string | null
    createdAt?: Date | string
  }

  export type ContributionUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    contributorName?: StringFieldUpdateOperationsInput | string
    contributorNote?: NullableStringFieldUpdateOperationsInput | string | null
    type?: StringFieldUpdateOperationsInput | string
    content?: NullableStringFieldUpdateOperationsInput | string | null
    mediaUrl?: NullableStringFieldUpdateOperationsInput | string | null
    mediaBlobPath?: NullableStringFieldUpdateOperationsInput | string | null
    viewedByUser?: BoolFieldUpdateOperationsInput | boolean
    importedToTimelineItemId?: NullableStringFieldUpdateOperationsInput | string | null
    archivedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ContributionUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    inviteId?: StringFieldUpdateOperationsInput | string
    contributorName?: StringFieldUpdateOperationsInput | string
    contributorNote?: NullableStringFieldUpdateOperationsInput | string | null
    type?: StringFieldUpdateOperationsInput | string
    content?: NullableStringFieldUpdateOperationsInput | string | null
    mediaUrl?: NullableStringFieldUpdateOperationsInput | string | null
    mediaBlobPath?: NullableStringFieldUpdateOperationsInput | string | null
    viewedByUser?: BoolFieldUpdateOperationsInput | boolean
    importedToTimelineItemId?: NullableStringFieldUpdateOperationsInput | string | null
    archivedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type TimelineItemCreateInput = {
    id?: string
    date: Date | string
    title: string
    story?: string | null
    mediaUrl?: string | null
    createdAt?: Date | string
    user: UserCreateNestedOneWithoutTimelineItemsInput
    photos?: PhotoCreateNestedManyWithoutTimelineItemInput
  }

  export type TimelineItemUncheckedCreateInput = {
    id?: string
    userId: string
    date: Date | string
    title: string
    story?: string | null
    mediaUrl?: string | null
    createdAt?: Date | string
    photos?: PhotoUncheckedCreateNestedManyWithoutTimelineItemInput
  }

  export type TimelineItemUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    date?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    story?: NullableStringFieldUpdateOperationsInput | string | null
    mediaUrl?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutTimelineItemsNestedInput
    photos?: PhotoUpdateManyWithoutTimelineItemNestedInput
  }

  export type TimelineItemUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    date?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    story?: NullableStringFieldUpdateOperationsInput | string | null
    mediaUrl?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    photos?: PhotoUncheckedUpdateManyWithoutTimelineItemNestedInput
  }

  export type TimelineItemCreateManyInput = {
    id?: string
    userId: string
    date: Date | string
    title: string
    story?: string | null
    mediaUrl?: string | null
    createdAt?: Date | string
  }

  export type TimelineItemUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    date?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    story?: NullableStringFieldUpdateOperationsInput | string | null
    mediaUrl?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type TimelineItemUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    date?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    story?: NullableStringFieldUpdateOperationsInput | string | null
    mediaUrl?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PhotoCreateInput = {
    id?: string
    url: string
    thumbnailUrl?: string | null
    blobPath: string
    caption?: string | null
    width?: number | null
    height?: number | null
    sizeBytes?: number | null
    order?: number
    createdAt?: Date | string
    user: UserCreateNestedOneWithoutPhotosInput
    timelineItem?: TimelineItemCreateNestedOneWithoutPhotosInput
  }

  export type PhotoUncheckedCreateInput = {
    id?: string
    userId: string
    timelineItemId?: string | null
    url: string
    thumbnailUrl?: string | null
    blobPath: string
    caption?: string | null
    width?: number | null
    height?: number | null
    sizeBytes?: number | null
    order?: number
    createdAt?: Date | string
  }

  export type PhotoUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    url?: StringFieldUpdateOperationsInput | string
    thumbnailUrl?: NullableStringFieldUpdateOperationsInput | string | null
    blobPath?: StringFieldUpdateOperationsInput | string
    caption?: NullableStringFieldUpdateOperationsInput | string | null
    width?: NullableIntFieldUpdateOperationsInput | number | null
    height?: NullableIntFieldUpdateOperationsInput | number | null
    sizeBytes?: NullableIntFieldUpdateOperationsInput | number | null
    order?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutPhotosNestedInput
    timelineItem?: TimelineItemUpdateOneWithoutPhotosNestedInput
  }

  export type PhotoUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    timelineItemId?: NullableStringFieldUpdateOperationsInput | string | null
    url?: StringFieldUpdateOperationsInput | string
    thumbnailUrl?: NullableStringFieldUpdateOperationsInput | string | null
    blobPath?: StringFieldUpdateOperationsInput | string
    caption?: NullableStringFieldUpdateOperationsInput | string | null
    width?: NullableIntFieldUpdateOperationsInput | number | null
    height?: NullableIntFieldUpdateOperationsInput | number | null
    sizeBytes?: NullableIntFieldUpdateOperationsInput | number | null
    order?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PhotoCreateManyInput = {
    id?: string
    userId: string
    timelineItemId?: string | null
    url: string
    thumbnailUrl?: string | null
    blobPath: string
    caption?: string | null
    width?: number | null
    height?: number | null
    sizeBytes?: number | null
    order?: number
    createdAt?: Date | string
  }

  export type PhotoUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    url?: StringFieldUpdateOperationsInput | string
    thumbnailUrl?: NullableStringFieldUpdateOperationsInput | string | null
    blobPath?: StringFieldUpdateOperationsInput | string
    caption?: NullableStringFieldUpdateOperationsInput | string | null
    width?: NullableIntFieldUpdateOperationsInput | number | null
    height?: NullableIntFieldUpdateOperationsInput | number | null
    sizeBytes?: NullableIntFieldUpdateOperationsInput | number | null
    order?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PhotoUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    timelineItemId?: NullableStringFieldUpdateOperationsInput | string | null
    url?: StringFieldUpdateOperationsInput | string
    thumbnailUrl?: NullableStringFieldUpdateOperationsInput | string | null
    blobPath?: StringFieldUpdateOperationsInput | string
    caption?: NullableStringFieldUpdateOperationsInput | string | null
    width?: NullableIntFieldUpdateOperationsInput | number | null
    height?: NullableIntFieldUpdateOperationsInput | number | null
    sizeBytes?: NullableIntFieldUpdateOperationsInput | number | null
    order?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ArrangementCreateInput = {
    id?: string
    type: string
    vendor: string
    contact?: string | null
    notes?: string | null
    createdAt?: Date | string
    user: UserCreateNestedOneWithoutArrangementsInput
  }

  export type ArrangementUncheckedCreateInput = {
    id?: string
    userId: string
    type: string
    vendor: string
    contact?: string | null
    notes?: string | null
    createdAt?: Date | string
  }

  export type ArrangementUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    type?: StringFieldUpdateOperationsInput | string
    vendor?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutArrangementsNestedInput
  }

  export type ArrangementUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    type?: StringFieldUpdateOperationsInput | string
    vendor?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ArrangementCreateManyInput = {
    id?: string
    userId: string
    type: string
    vendor: string
    contact?: string | null
    notes?: string | null
    createdAt?: Date | string
  }

  export type ArrangementUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    type?: StringFieldUpdateOperationsInput | string
    vendor?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ArrangementUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    type?: StringFieldUpdateOperationsInput | string
    vendor?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type VaultItemCreateInput = {
    id?: string
    label: string
    encryptedData: string
    createdAt?: Date | string
    user: UserCreateNestedOneWithoutVaultItemsInput
  }

  export type VaultItemUncheckedCreateInput = {
    id?: string
    userId: string
    label: string
    encryptedData: string
    createdAt?: Date | string
  }

  export type VaultItemUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    label?: StringFieldUpdateOperationsInput | string
    encryptedData?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutVaultItemsNestedInput
  }

  export type VaultItemUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    label?: StringFieldUpdateOperationsInput | string
    encryptedData?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type VaultItemCreateManyInput = {
    id?: string
    userId: string
    label: string
    encryptedData: string
    createdAt?: Date | string
  }

  export type VaultItemUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    label?: StringFieldUpdateOperationsInput | string
    encryptedData?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type VaultItemUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    label?: StringFieldUpdateOperationsInput | string
    encryptedData?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ExecutorCreateInput = {
    id?: string
    name: string
    email: string
    phone?: string | null
    verified?: boolean
    certUploadedAt?: Date | string | null
    unlockedAt?: Date | string | null
    createdAt?: Date | string
    user: UserCreateNestedOneWithoutExecutorInput
  }

  export type ExecutorUncheckedCreateInput = {
    id?: string
    userId: string
    name: string
    email: string
    phone?: string | null
    verified?: boolean
    certUploadedAt?: Date | string | null
    unlockedAt?: Date | string | null
    createdAt?: Date | string
  }

  export type ExecutorUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    verified?: BoolFieldUpdateOperationsInput | boolean
    certUploadedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    unlockedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutExecutorNestedInput
  }

  export type ExecutorUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    verified?: BoolFieldUpdateOperationsInput | boolean
    certUploadedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    unlockedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ExecutorCreateManyInput = {
    id?: string
    userId: string
    name: string
    email: string
    phone?: string | null
    verified?: boolean
    certUploadedAt?: Date | string | null
    unlockedAt?: Date | string | null
    createdAt?: Date | string
  }

  export type ExecutorUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    verified?: BoolFieldUpdateOperationsInput | boolean
    certUploadedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    unlockedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ExecutorUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    verified?: BoolFieldUpdateOperationsInput | boolean
    certUploadedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    unlockedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SettingsCreateInput = {
    id?: string
    pageTurnStyle?: string
    fontScale?: string
    highContrast?: boolean
    ttsEnabled?: boolean
    sttEnabled?: boolean
    reducedMotion?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
    user: UserCreateNestedOneWithoutSettingsInput
  }

  export type SettingsUncheckedCreateInput = {
    id?: string
    userId: string
    pageTurnStyle?: string
    fontScale?: string
    highContrast?: boolean
    ttsEnabled?: boolean
    sttEnabled?: boolean
    reducedMotion?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type SettingsUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    pageTurnStyle?: StringFieldUpdateOperationsInput | string
    fontScale?: StringFieldUpdateOperationsInput | string
    highContrast?: BoolFieldUpdateOperationsInput | boolean
    ttsEnabled?: BoolFieldUpdateOperationsInput | boolean
    sttEnabled?: BoolFieldUpdateOperationsInput | boolean
    reducedMotion?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutSettingsNestedInput
  }

  export type SettingsUncheckedUpdateInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    pageTurnStyle?: StringFieldUpdateOperationsInput | string
    fontScale?: StringFieldUpdateOperationsInput | string
    highContrast?: BoolFieldUpdateOperationsInput | boolean
    ttsEnabled?: BoolFieldUpdateOperationsInput | boolean
    sttEnabled?: BoolFieldUpdateOperationsInput | boolean
    reducedMotion?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SettingsCreateManyInput = {
    id?: string
    userId: string
    pageTurnStyle?: string
    fontScale?: string
    highContrast?: boolean
    ttsEnabled?: boolean
    sttEnabled?: boolean
    reducedMotion?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type SettingsUpdateManyMutationInput = {
    id?: StringFieldUpdateOperationsInput | string
    pageTurnStyle?: StringFieldUpdateOperationsInput | string
    fontScale?: StringFieldUpdateOperationsInput | string
    highContrast?: BoolFieldUpdateOperationsInput | boolean
    ttsEnabled?: BoolFieldUpdateOperationsInput | boolean
    sttEnabled?: BoolFieldUpdateOperationsInput | boolean
    reducedMotion?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SettingsUncheckedUpdateManyInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    pageTurnStyle?: StringFieldUpdateOperationsInput | string
    fontScale?: StringFieldUpdateOperationsInput | string
    highContrast?: BoolFieldUpdateOperationsInput | boolean
    ttsEnabled?: BoolFieldUpdateOperationsInput | boolean
    sttEnabled?: BoolFieldUpdateOperationsInput | boolean
    reducedMotion?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type StringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type StringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type DateTimeNullableFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableFilter<$PrismaModel> | Date | string | null
  }

  export type DateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type ContactListRelationFilter = {
    every?: ContactWhereInput
    some?: ContactWhereInput
    none?: ContactWhereInput
  }

  export type MessageListRelationFilter = {
    every?: MessageWhereInput
    some?: MessageWhereInput
    none?: MessageWhereInput
  }

  export type ArrangementListRelationFilter = {
    every?: ArrangementWhereInput
    some?: ArrangementWhereInput
    none?: ArrangementWhereInput
  }

  export type TimelineItemListRelationFilter = {
    every?: TimelineItemWhereInput
    some?: TimelineItemWhereInput
    none?: TimelineItemWhereInput
  }

  export type VaultItemListRelationFilter = {
    every?: VaultItemWhereInput
    some?: VaultItemWhereInput
    none?: VaultItemWhereInput
  }

  export type ExecutorNullableScalarRelationFilter = {
    is?: ExecutorWhereInput | null
    isNot?: ExecutorWhereInput | null
  }

  export type PhotoListRelationFilter = {
    every?: PhotoWhereInput
    some?: PhotoWhereInput
    none?: PhotoWhereInput
  }

  export type SettingsNullableScalarRelationFilter = {
    is?: SettingsWhereInput | null
    isNot?: SettingsWhereInput | null
  }

  export type MessageInviteListRelationFilter = {
    every?: MessageInviteWhereInput
    some?: MessageInviteWhereInput
    none?: MessageInviteWhereInput
  }

  export type ContributionListRelationFilter = {
    every?: ContributionWhereInput
    some?: ContributionWhereInput
    none?: ContributionWhereInput
  }

  export type SortOrderInput = {
    sort: SortOrder
    nulls?: NullsOrder
  }

  export type ContactOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type MessageOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type ArrangementOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type TimelineItemOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type VaultItemOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type PhotoOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type MessageInviteOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type ContributionOrderByRelationAggregateInput = {
    _count?: SortOrder
  }

  export type UserCountOrderByAggregateInput = {
    id?: SortOrder
    email?: SortOrder
    name?: SortOrder
    plan?: SortOrder
    pendingDeathVerificationAt?: SortOrder
    deceasedAt?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type UserMaxOrderByAggregateInput = {
    id?: SortOrder
    email?: SortOrder
    name?: SortOrder
    plan?: SortOrder
    pendingDeathVerificationAt?: SortOrder
    deceasedAt?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type UserMinOrderByAggregateInput = {
    id?: SortOrder
    email?: SortOrder
    name?: SortOrder
    plan?: SortOrder
    pendingDeathVerificationAt?: SortOrder
    deceasedAt?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type StringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type StringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    mode?: QueryMode
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type DateTimeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableWithAggregatesFilter<$PrismaModel> | Date | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedDateTimeNullableFilter<$PrismaModel>
    _max?: NestedDateTimeNullableFilter<$PrismaModel>
  }

  export type DateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type BoolFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolFilter<$PrismaModel> | boolean
  }

  export type UserScalarRelationFilter = {
    is?: UserWhereInput
    isNot?: UserWhereInput
  }

  export type ContactCountOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    name?: SortOrder
    email?: SortOrder
    phone?: SortOrder
    relationship?: SortOrder
    isExecutor?: SortOrder
    isBackup?: SortOrder
    createdAt?: SortOrder
  }

  export type ContactMaxOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    name?: SortOrder
    email?: SortOrder
    phone?: SortOrder
    relationship?: SortOrder
    isExecutor?: SortOrder
    isBackup?: SortOrder
    createdAt?: SortOrder
  }

  export type ContactMinOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    name?: SortOrder
    email?: SortOrder
    phone?: SortOrder
    relationship?: SortOrder
    isExecutor?: SortOrder
    isBackup?: SortOrder
    createdAt?: SortOrder
  }

  export type BoolWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolWithAggregatesFilter<$PrismaModel> | boolean
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedBoolFilter<$PrismaModel>
    _max?: NestedBoolFilter<$PrismaModel>
  }

  export type IntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type IntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type MessageCountOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    recipientName?: SortOrder
    recipientEmail?: SortOrder
    type?: SortOrder
    subject?: SortOrder
    content?: SortOrder
    mediaUrl?: SortOrder
    mediaBlobPath?: SortOrder
    mediaDurationSec?: SortOrder
    triggerDate?: SortOrder
    state?: SortOrder
    approvalPromptedAt?: SortOrder
    approvalExpiresAt?: SortOrder
    sentAt?: SortOrder
    archivedAt?: SortOrder
    deliveryToken?: SortOrder
    approvalToken?: SortOrder
    approvalRemindersSent?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type MessageAvgOrderByAggregateInput = {
    mediaDurationSec?: SortOrder
    approvalRemindersSent?: SortOrder
  }

  export type MessageMaxOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    recipientName?: SortOrder
    recipientEmail?: SortOrder
    type?: SortOrder
    subject?: SortOrder
    content?: SortOrder
    mediaUrl?: SortOrder
    mediaBlobPath?: SortOrder
    mediaDurationSec?: SortOrder
    triggerDate?: SortOrder
    state?: SortOrder
    approvalPromptedAt?: SortOrder
    approvalExpiresAt?: SortOrder
    sentAt?: SortOrder
    archivedAt?: SortOrder
    deliveryToken?: SortOrder
    approvalToken?: SortOrder
    approvalRemindersSent?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type MessageMinOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    recipientName?: SortOrder
    recipientEmail?: SortOrder
    type?: SortOrder
    subject?: SortOrder
    content?: SortOrder
    mediaUrl?: SortOrder
    mediaBlobPath?: SortOrder
    mediaDurationSec?: SortOrder
    triggerDate?: SortOrder
    state?: SortOrder
    approvalPromptedAt?: SortOrder
    approvalExpiresAt?: SortOrder
    sentAt?: SortOrder
    archivedAt?: SortOrder
    deliveryToken?: SortOrder
    approvalToken?: SortOrder
    approvalRemindersSent?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type MessageSumOrderByAggregateInput = {
    mediaDurationSec?: SortOrder
    approvalRemindersSent?: SortOrder
  }

  export type IntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type IntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type MessageInviteCountOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    token?: SortOrder
    contributorName?: SortOrder
    contributorEmail?: SortOrder
    message?: SortOrder
    expiresAt?: SortOrder
    revokedAt?: SortOrder
    lastUsedAt?: SortOrder
    useCount?: SortOrder
    createdAt?: SortOrder
  }

  export type MessageInviteAvgOrderByAggregateInput = {
    useCount?: SortOrder
  }

  export type MessageInviteMaxOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    token?: SortOrder
    contributorName?: SortOrder
    contributorEmail?: SortOrder
    message?: SortOrder
    expiresAt?: SortOrder
    revokedAt?: SortOrder
    lastUsedAt?: SortOrder
    useCount?: SortOrder
    createdAt?: SortOrder
  }

  export type MessageInviteMinOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    token?: SortOrder
    contributorName?: SortOrder
    contributorEmail?: SortOrder
    message?: SortOrder
    expiresAt?: SortOrder
    revokedAt?: SortOrder
    lastUsedAt?: SortOrder
    useCount?: SortOrder
    createdAt?: SortOrder
  }

  export type MessageInviteSumOrderByAggregateInput = {
    useCount?: SortOrder
  }

  export type MessageInviteScalarRelationFilter = {
    is?: MessageInviteWhereInput
    isNot?: MessageInviteWhereInput
  }

  export type ContributionCountOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    inviteId?: SortOrder
    contributorName?: SortOrder
    contributorNote?: SortOrder
    type?: SortOrder
    content?: SortOrder
    mediaUrl?: SortOrder
    mediaBlobPath?: SortOrder
    viewedByUser?: SortOrder
    importedToTimelineItemId?: SortOrder
    archivedAt?: SortOrder
    createdAt?: SortOrder
  }

  export type ContributionMaxOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    inviteId?: SortOrder
    contributorName?: SortOrder
    contributorNote?: SortOrder
    type?: SortOrder
    content?: SortOrder
    mediaUrl?: SortOrder
    mediaBlobPath?: SortOrder
    viewedByUser?: SortOrder
    importedToTimelineItemId?: SortOrder
    archivedAt?: SortOrder
    createdAt?: SortOrder
  }

  export type ContributionMinOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    inviteId?: SortOrder
    contributorName?: SortOrder
    contributorNote?: SortOrder
    type?: SortOrder
    content?: SortOrder
    mediaUrl?: SortOrder
    mediaBlobPath?: SortOrder
    viewedByUser?: SortOrder
    importedToTimelineItemId?: SortOrder
    archivedAt?: SortOrder
    createdAt?: SortOrder
  }

  export type TimelineItemCountOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    date?: SortOrder
    title?: SortOrder
    story?: SortOrder
    mediaUrl?: SortOrder
    createdAt?: SortOrder
  }

  export type TimelineItemMaxOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    date?: SortOrder
    title?: SortOrder
    story?: SortOrder
    mediaUrl?: SortOrder
    createdAt?: SortOrder
  }

  export type TimelineItemMinOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    date?: SortOrder
    title?: SortOrder
    story?: SortOrder
    mediaUrl?: SortOrder
    createdAt?: SortOrder
  }

  export type TimelineItemNullableScalarRelationFilter = {
    is?: TimelineItemWhereInput | null
    isNot?: TimelineItemWhereInput | null
  }

  export type PhotoCountOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    timelineItemId?: SortOrder
    url?: SortOrder
    thumbnailUrl?: SortOrder
    blobPath?: SortOrder
    caption?: SortOrder
    width?: SortOrder
    height?: SortOrder
    sizeBytes?: SortOrder
    order?: SortOrder
    createdAt?: SortOrder
  }

  export type PhotoAvgOrderByAggregateInput = {
    width?: SortOrder
    height?: SortOrder
    sizeBytes?: SortOrder
    order?: SortOrder
  }

  export type PhotoMaxOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    timelineItemId?: SortOrder
    url?: SortOrder
    thumbnailUrl?: SortOrder
    blobPath?: SortOrder
    caption?: SortOrder
    width?: SortOrder
    height?: SortOrder
    sizeBytes?: SortOrder
    order?: SortOrder
    createdAt?: SortOrder
  }

  export type PhotoMinOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    timelineItemId?: SortOrder
    url?: SortOrder
    thumbnailUrl?: SortOrder
    blobPath?: SortOrder
    caption?: SortOrder
    width?: SortOrder
    height?: SortOrder
    sizeBytes?: SortOrder
    order?: SortOrder
    createdAt?: SortOrder
  }

  export type PhotoSumOrderByAggregateInput = {
    width?: SortOrder
    height?: SortOrder
    sizeBytes?: SortOrder
    order?: SortOrder
  }

  export type ArrangementCountOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    type?: SortOrder
    vendor?: SortOrder
    contact?: SortOrder
    notes?: SortOrder
    createdAt?: SortOrder
  }

  export type ArrangementMaxOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    type?: SortOrder
    vendor?: SortOrder
    contact?: SortOrder
    notes?: SortOrder
    createdAt?: SortOrder
  }

  export type ArrangementMinOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    type?: SortOrder
    vendor?: SortOrder
    contact?: SortOrder
    notes?: SortOrder
    createdAt?: SortOrder
  }

  export type VaultItemCountOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    label?: SortOrder
    encryptedData?: SortOrder
    createdAt?: SortOrder
  }

  export type VaultItemMaxOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    label?: SortOrder
    encryptedData?: SortOrder
    createdAt?: SortOrder
  }

  export type VaultItemMinOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    label?: SortOrder
    encryptedData?: SortOrder
    createdAt?: SortOrder
  }

  export type ExecutorCountOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    name?: SortOrder
    email?: SortOrder
    phone?: SortOrder
    verified?: SortOrder
    certUploadedAt?: SortOrder
    unlockedAt?: SortOrder
    createdAt?: SortOrder
  }

  export type ExecutorMaxOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    name?: SortOrder
    email?: SortOrder
    phone?: SortOrder
    verified?: SortOrder
    certUploadedAt?: SortOrder
    unlockedAt?: SortOrder
    createdAt?: SortOrder
  }

  export type ExecutorMinOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    name?: SortOrder
    email?: SortOrder
    phone?: SortOrder
    verified?: SortOrder
    certUploadedAt?: SortOrder
    unlockedAt?: SortOrder
    createdAt?: SortOrder
  }

  export type SettingsCountOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    pageTurnStyle?: SortOrder
    fontScale?: SortOrder
    highContrast?: SortOrder
    ttsEnabled?: SortOrder
    sttEnabled?: SortOrder
    reducedMotion?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SettingsMaxOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    pageTurnStyle?: SortOrder
    fontScale?: SortOrder
    highContrast?: SortOrder
    ttsEnabled?: SortOrder
    sttEnabled?: SortOrder
    reducedMotion?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type SettingsMinOrderByAggregateInput = {
    id?: SortOrder
    userId?: SortOrder
    pageTurnStyle?: SortOrder
    fontScale?: SortOrder
    highContrast?: SortOrder
    ttsEnabled?: SortOrder
    sttEnabled?: SortOrder
    reducedMotion?: SortOrder
    createdAt?: SortOrder
    updatedAt?: SortOrder
  }

  export type ContactCreateNestedManyWithoutUserInput = {
    create?: XOR<ContactCreateWithoutUserInput, ContactUncheckedCreateWithoutUserInput> | ContactCreateWithoutUserInput[] | ContactUncheckedCreateWithoutUserInput[]
    connectOrCreate?: ContactCreateOrConnectWithoutUserInput | ContactCreateOrConnectWithoutUserInput[]
    createMany?: ContactCreateManyUserInputEnvelope
    connect?: ContactWhereUniqueInput | ContactWhereUniqueInput[]
  }

  export type MessageCreateNestedManyWithoutUserInput = {
    create?: XOR<MessageCreateWithoutUserInput, MessageUncheckedCreateWithoutUserInput> | MessageCreateWithoutUserInput[] | MessageUncheckedCreateWithoutUserInput[]
    connectOrCreate?: MessageCreateOrConnectWithoutUserInput | MessageCreateOrConnectWithoutUserInput[]
    createMany?: MessageCreateManyUserInputEnvelope
    connect?: MessageWhereUniqueInput | MessageWhereUniqueInput[]
  }

  export type ArrangementCreateNestedManyWithoutUserInput = {
    create?: XOR<ArrangementCreateWithoutUserInput, ArrangementUncheckedCreateWithoutUserInput> | ArrangementCreateWithoutUserInput[] | ArrangementUncheckedCreateWithoutUserInput[]
    connectOrCreate?: ArrangementCreateOrConnectWithoutUserInput | ArrangementCreateOrConnectWithoutUserInput[]
    createMany?: ArrangementCreateManyUserInputEnvelope
    connect?: ArrangementWhereUniqueInput | ArrangementWhereUniqueInput[]
  }

  export type TimelineItemCreateNestedManyWithoutUserInput = {
    create?: XOR<TimelineItemCreateWithoutUserInput, TimelineItemUncheckedCreateWithoutUserInput> | TimelineItemCreateWithoutUserInput[] | TimelineItemUncheckedCreateWithoutUserInput[]
    connectOrCreate?: TimelineItemCreateOrConnectWithoutUserInput | TimelineItemCreateOrConnectWithoutUserInput[]
    createMany?: TimelineItemCreateManyUserInputEnvelope
    connect?: TimelineItemWhereUniqueInput | TimelineItemWhereUniqueInput[]
  }

  export type VaultItemCreateNestedManyWithoutUserInput = {
    create?: XOR<VaultItemCreateWithoutUserInput, VaultItemUncheckedCreateWithoutUserInput> | VaultItemCreateWithoutUserInput[] | VaultItemUncheckedCreateWithoutUserInput[]
    connectOrCreate?: VaultItemCreateOrConnectWithoutUserInput | VaultItemCreateOrConnectWithoutUserInput[]
    createMany?: VaultItemCreateManyUserInputEnvelope
    connect?: VaultItemWhereUniqueInput | VaultItemWhereUniqueInput[]
  }

  export type ExecutorCreateNestedOneWithoutUserInput = {
    create?: XOR<ExecutorCreateWithoutUserInput, ExecutorUncheckedCreateWithoutUserInput>
    connectOrCreate?: ExecutorCreateOrConnectWithoutUserInput
    connect?: ExecutorWhereUniqueInput
  }

  export type PhotoCreateNestedManyWithoutUserInput = {
    create?: XOR<PhotoCreateWithoutUserInput, PhotoUncheckedCreateWithoutUserInput> | PhotoCreateWithoutUserInput[] | PhotoUncheckedCreateWithoutUserInput[]
    connectOrCreate?: PhotoCreateOrConnectWithoutUserInput | PhotoCreateOrConnectWithoutUserInput[]
    createMany?: PhotoCreateManyUserInputEnvelope
    connect?: PhotoWhereUniqueInput | PhotoWhereUniqueInput[]
  }

  export type SettingsCreateNestedOneWithoutUserInput = {
    create?: XOR<SettingsCreateWithoutUserInput, SettingsUncheckedCreateWithoutUserInput>
    connectOrCreate?: SettingsCreateOrConnectWithoutUserInput
    connect?: SettingsWhereUniqueInput
  }

  export type MessageInviteCreateNestedManyWithoutUserInput = {
    create?: XOR<MessageInviteCreateWithoutUserInput, MessageInviteUncheckedCreateWithoutUserInput> | MessageInviteCreateWithoutUserInput[] | MessageInviteUncheckedCreateWithoutUserInput[]
    connectOrCreate?: MessageInviteCreateOrConnectWithoutUserInput | MessageInviteCreateOrConnectWithoutUserInput[]
    createMany?: MessageInviteCreateManyUserInputEnvelope
    connect?: MessageInviteWhereUniqueInput | MessageInviteWhereUniqueInput[]
  }

  export type ContributionCreateNestedManyWithoutUserInput = {
    create?: XOR<ContributionCreateWithoutUserInput, ContributionUncheckedCreateWithoutUserInput> | ContributionCreateWithoutUserInput[] | ContributionUncheckedCreateWithoutUserInput[]
    connectOrCreate?: ContributionCreateOrConnectWithoutUserInput | ContributionCreateOrConnectWithoutUserInput[]
    createMany?: ContributionCreateManyUserInputEnvelope
    connect?: ContributionWhereUniqueInput | ContributionWhereUniqueInput[]
  }

  export type ContactUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<ContactCreateWithoutUserInput, ContactUncheckedCreateWithoutUserInput> | ContactCreateWithoutUserInput[] | ContactUncheckedCreateWithoutUserInput[]
    connectOrCreate?: ContactCreateOrConnectWithoutUserInput | ContactCreateOrConnectWithoutUserInput[]
    createMany?: ContactCreateManyUserInputEnvelope
    connect?: ContactWhereUniqueInput | ContactWhereUniqueInput[]
  }

  export type MessageUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<MessageCreateWithoutUserInput, MessageUncheckedCreateWithoutUserInput> | MessageCreateWithoutUserInput[] | MessageUncheckedCreateWithoutUserInput[]
    connectOrCreate?: MessageCreateOrConnectWithoutUserInput | MessageCreateOrConnectWithoutUserInput[]
    createMany?: MessageCreateManyUserInputEnvelope
    connect?: MessageWhereUniqueInput | MessageWhereUniqueInput[]
  }

  export type ArrangementUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<ArrangementCreateWithoutUserInput, ArrangementUncheckedCreateWithoutUserInput> | ArrangementCreateWithoutUserInput[] | ArrangementUncheckedCreateWithoutUserInput[]
    connectOrCreate?: ArrangementCreateOrConnectWithoutUserInput | ArrangementCreateOrConnectWithoutUserInput[]
    createMany?: ArrangementCreateManyUserInputEnvelope
    connect?: ArrangementWhereUniqueInput | ArrangementWhereUniqueInput[]
  }

  export type TimelineItemUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<TimelineItemCreateWithoutUserInput, TimelineItemUncheckedCreateWithoutUserInput> | TimelineItemCreateWithoutUserInput[] | TimelineItemUncheckedCreateWithoutUserInput[]
    connectOrCreate?: TimelineItemCreateOrConnectWithoutUserInput | TimelineItemCreateOrConnectWithoutUserInput[]
    createMany?: TimelineItemCreateManyUserInputEnvelope
    connect?: TimelineItemWhereUniqueInput | TimelineItemWhereUniqueInput[]
  }

  export type VaultItemUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<VaultItemCreateWithoutUserInput, VaultItemUncheckedCreateWithoutUserInput> | VaultItemCreateWithoutUserInput[] | VaultItemUncheckedCreateWithoutUserInput[]
    connectOrCreate?: VaultItemCreateOrConnectWithoutUserInput | VaultItemCreateOrConnectWithoutUserInput[]
    createMany?: VaultItemCreateManyUserInputEnvelope
    connect?: VaultItemWhereUniqueInput | VaultItemWhereUniqueInput[]
  }

  export type ExecutorUncheckedCreateNestedOneWithoutUserInput = {
    create?: XOR<ExecutorCreateWithoutUserInput, ExecutorUncheckedCreateWithoutUserInput>
    connectOrCreate?: ExecutorCreateOrConnectWithoutUserInput
    connect?: ExecutorWhereUniqueInput
  }

  export type PhotoUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<PhotoCreateWithoutUserInput, PhotoUncheckedCreateWithoutUserInput> | PhotoCreateWithoutUserInput[] | PhotoUncheckedCreateWithoutUserInput[]
    connectOrCreate?: PhotoCreateOrConnectWithoutUserInput | PhotoCreateOrConnectWithoutUserInput[]
    createMany?: PhotoCreateManyUserInputEnvelope
    connect?: PhotoWhereUniqueInput | PhotoWhereUniqueInput[]
  }

  export type SettingsUncheckedCreateNestedOneWithoutUserInput = {
    create?: XOR<SettingsCreateWithoutUserInput, SettingsUncheckedCreateWithoutUserInput>
    connectOrCreate?: SettingsCreateOrConnectWithoutUserInput
    connect?: SettingsWhereUniqueInput
  }

  export type MessageInviteUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<MessageInviteCreateWithoutUserInput, MessageInviteUncheckedCreateWithoutUserInput> | MessageInviteCreateWithoutUserInput[] | MessageInviteUncheckedCreateWithoutUserInput[]
    connectOrCreate?: MessageInviteCreateOrConnectWithoutUserInput | MessageInviteCreateOrConnectWithoutUserInput[]
    createMany?: MessageInviteCreateManyUserInputEnvelope
    connect?: MessageInviteWhereUniqueInput | MessageInviteWhereUniqueInput[]
  }

  export type ContributionUncheckedCreateNestedManyWithoutUserInput = {
    create?: XOR<ContributionCreateWithoutUserInput, ContributionUncheckedCreateWithoutUserInput> | ContributionCreateWithoutUserInput[] | ContributionUncheckedCreateWithoutUserInput[]
    connectOrCreate?: ContributionCreateOrConnectWithoutUserInput | ContributionCreateOrConnectWithoutUserInput[]
    createMany?: ContributionCreateManyUserInputEnvelope
    connect?: ContributionWhereUniqueInput | ContributionWhereUniqueInput[]
  }

  export type StringFieldUpdateOperationsInput = {
    set?: string
  }

  export type NullableStringFieldUpdateOperationsInput = {
    set?: string | null
  }

  export type NullableDateTimeFieldUpdateOperationsInput = {
    set?: Date | string | null
  }

  export type DateTimeFieldUpdateOperationsInput = {
    set?: Date | string
  }

  export type ContactUpdateManyWithoutUserNestedInput = {
    create?: XOR<ContactCreateWithoutUserInput, ContactUncheckedCreateWithoutUserInput> | ContactCreateWithoutUserInput[] | ContactUncheckedCreateWithoutUserInput[]
    connectOrCreate?: ContactCreateOrConnectWithoutUserInput | ContactCreateOrConnectWithoutUserInput[]
    upsert?: ContactUpsertWithWhereUniqueWithoutUserInput | ContactUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: ContactCreateManyUserInputEnvelope
    set?: ContactWhereUniqueInput | ContactWhereUniqueInput[]
    disconnect?: ContactWhereUniqueInput | ContactWhereUniqueInput[]
    delete?: ContactWhereUniqueInput | ContactWhereUniqueInput[]
    connect?: ContactWhereUniqueInput | ContactWhereUniqueInput[]
    update?: ContactUpdateWithWhereUniqueWithoutUserInput | ContactUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: ContactUpdateManyWithWhereWithoutUserInput | ContactUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: ContactScalarWhereInput | ContactScalarWhereInput[]
  }

  export type MessageUpdateManyWithoutUserNestedInput = {
    create?: XOR<MessageCreateWithoutUserInput, MessageUncheckedCreateWithoutUserInput> | MessageCreateWithoutUserInput[] | MessageUncheckedCreateWithoutUserInput[]
    connectOrCreate?: MessageCreateOrConnectWithoutUserInput | MessageCreateOrConnectWithoutUserInput[]
    upsert?: MessageUpsertWithWhereUniqueWithoutUserInput | MessageUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: MessageCreateManyUserInputEnvelope
    set?: MessageWhereUniqueInput | MessageWhereUniqueInput[]
    disconnect?: MessageWhereUniqueInput | MessageWhereUniqueInput[]
    delete?: MessageWhereUniqueInput | MessageWhereUniqueInput[]
    connect?: MessageWhereUniqueInput | MessageWhereUniqueInput[]
    update?: MessageUpdateWithWhereUniqueWithoutUserInput | MessageUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: MessageUpdateManyWithWhereWithoutUserInput | MessageUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: MessageScalarWhereInput | MessageScalarWhereInput[]
  }

  export type ArrangementUpdateManyWithoutUserNestedInput = {
    create?: XOR<ArrangementCreateWithoutUserInput, ArrangementUncheckedCreateWithoutUserInput> | ArrangementCreateWithoutUserInput[] | ArrangementUncheckedCreateWithoutUserInput[]
    connectOrCreate?: ArrangementCreateOrConnectWithoutUserInput | ArrangementCreateOrConnectWithoutUserInput[]
    upsert?: ArrangementUpsertWithWhereUniqueWithoutUserInput | ArrangementUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: ArrangementCreateManyUserInputEnvelope
    set?: ArrangementWhereUniqueInput | ArrangementWhereUniqueInput[]
    disconnect?: ArrangementWhereUniqueInput | ArrangementWhereUniqueInput[]
    delete?: ArrangementWhereUniqueInput | ArrangementWhereUniqueInput[]
    connect?: ArrangementWhereUniqueInput | ArrangementWhereUniqueInput[]
    update?: ArrangementUpdateWithWhereUniqueWithoutUserInput | ArrangementUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: ArrangementUpdateManyWithWhereWithoutUserInput | ArrangementUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: ArrangementScalarWhereInput | ArrangementScalarWhereInput[]
  }

  export type TimelineItemUpdateManyWithoutUserNestedInput = {
    create?: XOR<TimelineItemCreateWithoutUserInput, TimelineItemUncheckedCreateWithoutUserInput> | TimelineItemCreateWithoutUserInput[] | TimelineItemUncheckedCreateWithoutUserInput[]
    connectOrCreate?: TimelineItemCreateOrConnectWithoutUserInput | TimelineItemCreateOrConnectWithoutUserInput[]
    upsert?: TimelineItemUpsertWithWhereUniqueWithoutUserInput | TimelineItemUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: TimelineItemCreateManyUserInputEnvelope
    set?: TimelineItemWhereUniqueInput | TimelineItemWhereUniqueInput[]
    disconnect?: TimelineItemWhereUniqueInput | TimelineItemWhereUniqueInput[]
    delete?: TimelineItemWhereUniqueInput | TimelineItemWhereUniqueInput[]
    connect?: TimelineItemWhereUniqueInput | TimelineItemWhereUniqueInput[]
    update?: TimelineItemUpdateWithWhereUniqueWithoutUserInput | TimelineItemUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: TimelineItemUpdateManyWithWhereWithoutUserInput | TimelineItemUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: TimelineItemScalarWhereInput | TimelineItemScalarWhereInput[]
  }

  export type VaultItemUpdateManyWithoutUserNestedInput = {
    create?: XOR<VaultItemCreateWithoutUserInput, VaultItemUncheckedCreateWithoutUserInput> | VaultItemCreateWithoutUserInput[] | VaultItemUncheckedCreateWithoutUserInput[]
    connectOrCreate?: VaultItemCreateOrConnectWithoutUserInput | VaultItemCreateOrConnectWithoutUserInput[]
    upsert?: VaultItemUpsertWithWhereUniqueWithoutUserInput | VaultItemUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: VaultItemCreateManyUserInputEnvelope
    set?: VaultItemWhereUniqueInput | VaultItemWhereUniqueInput[]
    disconnect?: VaultItemWhereUniqueInput | VaultItemWhereUniqueInput[]
    delete?: VaultItemWhereUniqueInput | VaultItemWhereUniqueInput[]
    connect?: VaultItemWhereUniqueInput | VaultItemWhereUniqueInput[]
    update?: VaultItemUpdateWithWhereUniqueWithoutUserInput | VaultItemUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: VaultItemUpdateManyWithWhereWithoutUserInput | VaultItemUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: VaultItemScalarWhereInput | VaultItemScalarWhereInput[]
  }

  export type ExecutorUpdateOneWithoutUserNestedInput = {
    create?: XOR<ExecutorCreateWithoutUserInput, ExecutorUncheckedCreateWithoutUserInput>
    connectOrCreate?: ExecutorCreateOrConnectWithoutUserInput
    upsert?: ExecutorUpsertWithoutUserInput
    disconnect?: ExecutorWhereInput | boolean
    delete?: ExecutorWhereInput | boolean
    connect?: ExecutorWhereUniqueInput
    update?: XOR<XOR<ExecutorUpdateToOneWithWhereWithoutUserInput, ExecutorUpdateWithoutUserInput>, ExecutorUncheckedUpdateWithoutUserInput>
  }

  export type PhotoUpdateManyWithoutUserNestedInput = {
    create?: XOR<PhotoCreateWithoutUserInput, PhotoUncheckedCreateWithoutUserInput> | PhotoCreateWithoutUserInput[] | PhotoUncheckedCreateWithoutUserInput[]
    connectOrCreate?: PhotoCreateOrConnectWithoutUserInput | PhotoCreateOrConnectWithoutUserInput[]
    upsert?: PhotoUpsertWithWhereUniqueWithoutUserInput | PhotoUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: PhotoCreateManyUserInputEnvelope
    set?: PhotoWhereUniqueInput | PhotoWhereUniqueInput[]
    disconnect?: PhotoWhereUniqueInput | PhotoWhereUniqueInput[]
    delete?: PhotoWhereUniqueInput | PhotoWhereUniqueInput[]
    connect?: PhotoWhereUniqueInput | PhotoWhereUniqueInput[]
    update?: PhotoUpdateWithWhereUniqueWithoutUserInput | PhotoUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: PhotoUpdateManyWithWhereWithoutUserInput | PhotoUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: PhotoScalarWhereInput | PhotoScalarWhereInput[]
  }

  export type SettingsUpdateOneWithoutUserNestedInput = {
    create?: XOR<SettingsCreateWithoutUserInput, SettingsUncheckedCreateWithoutUserInput>
    connectOrCreate?: SettingsCreateOrConnectWithoutUserInput
    upsert?: SettingsUpsertWithoutUserInput
    disconnect?: SettingsWhereInput | boolean
    delete?: SettingsWhereInput | boolean
    connect?: SettingsWhereUniqueInput
    update?: XOR<XOR<SettingsUpdateToOneWithWhereWithoutUserInput, SettingsUpdateWithoutUserInput>, SettingsUncheckedUpdateWithoutUserInput>
  }

  export type MessageInviteUpdateManyWithoutUserNestedInput = {
    create?: XOR<MessageInviteCreateWithoutUserInput, MessageInviteUncheckedCreateWithoutUserInput> | MessageInviteCreateWithoutUserInput[] | MessageInviteUncheckedCreateWithoutUserInput[]
    connectOrCreate?: MessageInviteCreateOrConnectWithoutUserInput | MessageInviteCreateOrConnectWithoutUserInput[]
    upsert?: MessageInviteUpsertWithWhereUniqueWithoutUserInput | MessageInviteUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: MessageInviteCreateManyUserInputEnvelope
    set?: MessageInviteWhereUniqueInput | MessageInviteWhereUniqueInput[]
    disconnect?: MessageInviteWhereUniqueInput | MessageInviteWhereUniqueInput[]
    delete?: MessageInviteWhereUniqueInput | MessageInviteWhereUniqueInput[]
    connect?: MessageInviteWhereUniqueInput | MessageInviteWhereUniqueInput[]
    update?: MessageInviteUpdateWithWhereUniqueWithoutUserInput | MessageInviteUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: MessageInviteUpdateManyWithWhereWithoutUserInput | MessageInviteUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: MessageInviteScalarWhereInput | MessageInviteScalarWhereInput[]
  }

  export type ContributionUpdateManyWithoutUserNestedInput = {
    create?: XOR<ContributionCreateWithoutUserInput, ContributionUncheckedCreateWithoutUserInput> | ContributionCreateWithoutUserInput[] | ContributionUncheckedCreateWithoutUserInput[]
    connectOrCreate?: ContributionCreateOrConnectWithoutUserInput | ContributionCreateOrConnectWithoutUserInput[]
    upsert?: ContributionUpsertWithWhereUniqueWithoutUserInput | ContributionUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: ContributionCreateManyUserInputEnvelope
    set?: ContributionWhereUniqueInput | ContributionWhereUniqueInput[]
    disconnect?: ContributionWhereUniqueInput | ContributionWhereUniqueInput[]
    delete?: ContributionWhereUniqueInput | ContributionWhereUniqueInput[]
    connect?: ContributionWhereUniqueInput | ContributionWhereUniqueInput[]
    update?: ContributionUpdateWithWhereUniqueWithoutUserInput | ContributionUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: ContributionUpdateManyWithWhereWithoutUserInput | ContributionUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: ContributionScalarWhereInput | ContributionScalarWhereInput[]
  }

  export type ContactUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<ContactCreateWithoutUserInput, ContactUncheckedCreateWithoutUserInput> | ContactCreateWithoutUserInput[] | ContactUncheckedCreateWithoutUserInput[]
    connectOrCreate?: ContactCreateOrConnectWithoutUserInput | ContactCreateOrConnectWithoutUserInput[]
    upsert?: ContactUpsertWithWhereUniqueWithoutUserInput | ContactUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: ContactCreateManyUserInputEnvelope
    set?: ContactWhereUniqueInput | ContactWhereUniqueInput[]
    disconnect?: ContactWhereUniqueInput | ContactWhereUniqueInput[]
    delete?: ContactWhereUniqueInput | ContactWhereUniqueInput[]
    connect?: ContactWhereUniqueInput | ContactWhereUniqueInput[]
    update?: ContactUpdateWithWhereUniqueWithoutUserInput | ContactUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: ContactUpdateManyWithWhereWithoutUserInput | ContactUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: ContactScalarWhereInput | ContactScalarWhereInput[]
  }

  export type MessageUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<MessageCreateWithoutUserInput, MessageUncheckedCreateWithoutUserInput> | MessageCreateWithoutUserInput[] | MessageUncheckedCreateWithoutUserInput[]
    connectOrCreate?: MessageCreateOrConnectWithoutUserInput | MessageCreateOrConnectWithoutUserInput[]
    upsert?: MessageUpsertWithWhereUniqueWithoutUserInput | MessageUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: MessageCreateManyUserInputEnvelope
    set?: MessageWhereUniqueInput | MessageWhereUniqueInput[]
    disconnect?: MessageWhereUniqueInput | MessageWhereUniqueInput[]
    delete?: MessageWhereUniqueInput | MessageWhereUniqueInput[]
    connect?: MessageWhereUniqueInput | MessageWhereUniqueInput[]
    update?: MessageUpdateWithWhereUniqueWithoutUserInput | MessageUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: MessageUpdateManyWithWhereWithoutUserInput | MessageUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: MessageScalarWhereInput | MessageScalarWhereInput[]
  }

  export type ArrangementUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<ArrangementCreateWithoutUserInput, ArrangementUncheckedCreateWithoutUserInput> | ArrangementCreateWithoutUserInput[] | ArrangementUncheckedCreateWithoutUserInput[]
    connectOrCreate?: ArrangementCreateOrConnectWithoutUserInput | ArrangementCreateOrConnectWithoutUserInput[]
    upsert?: ArrangementUpsertWithWhereUniqueWithoutUserInput | ArrangementUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: ArrangementCreateManyUserInputEnvelope
    set?: ArrangementWhereUniqueInput | ArrangementWhereUniqueInput[]
    disconnect?: ArrangementWhereUniqueInput | ArrangementWhereUniqueInput[]
    delete?: ArrangementWhereUniqueInput | ArrangementWhereUniqueInput[]
    connect?: ArrangementWhereUniqueInput | ArrangementWhereUniqueInput[]
    update?: ArrangementUpdateWithWhereUniqueWithoutUserInput | ArrangementUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: ArrangementUpdateManyWithWhereWithoutUserInput | ArrangementUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: ArrangementScalarWhereInput | ArrangementScalarWhereInput[]
  }

  export type TimelineItemUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<TimelineItemCreateWithoutUserInput, TimelineItemUncheckedCreateWithoutUserInput> | TimelineItemCreateWithoutUserInput[] | TimelineItemUncheckedCreateWithoutUserInput[]
    connectOrCreate?: TimelineItemCreateOrConnectWithoutUserInput | TimelineItemCreateOrConnectWithoutUserInput[]
    upsert?: TimelineItemUpsertWithWhereUniqueWithoutUserInput | TimelineItemUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: TimelineItemCreateManyUserInputEnvelope
    set?: TimelineItemWhereUniqueInput | TimelineItemWhereUniqueInput[]
    disconnect?: TimelineItemWhereUniqueInput | TimelineItemWhereUniqueInput[]
    delete?: TimelineItemWhereUniqueInput | TimelineItemWhereUniqueInput[]
    connect?: TimelineItemWhereUniqueInput | TimelineItemWhereUniqueInput[]
    update?: TimelineItemUpdateWithWhereUniqueWithoutUserInput | TimelineItemUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: TimelineItemUpdateManyWithWhereWithoutUserInput | TimelineItemUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: TimelineItemScalarWhereInput | TimelineItemScalarWhereInput[]
  }

  export type VaultItemUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<VaultItemCreateWithoutUserInput, VaultItemUncheckedCreateWithoutUserInput> | VaultItemCreateWithoutUserInput[] | VaultItemUncheckedCreateWithoutUserInput[]
    connectOrCreate?: VaultItemCreateOrConnectWithoutUserInput | VaultItemCreateOrConnectWithoutUserInput[]
    upsert?: VaultItemUpsertWithWhereUniqueWithoutUserInput | VaultItemUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: VaultItemCreateManyUserInputEnvelope
    set?: VaultItemWhereUniqueInput | VaultItemWhereUniqueInput[]
    disconnect?: VaultItemWhereUniqueInput | VaultItemWhereUniqueInput[]
    delete?: VaultItemWhereUniqueInput | VaultItemWhereUniqueInput[]
    connect?: VaultItemWhereUniqueInput | VaultItemWhereUniqueInput[]
    update?: VaultItemUpdateWithWhereUniqueWithoutUserInput | VaultItemUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: VaultItemUpdateManyWithWhereWithoutUserInput | VaultItemUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: VaultItemScalarWhereInput | VaultItemScalarWhereInput[]
  }

  export type ExecutorUncheckedUpdateOneWithoutUserNestedInput = {
    create?: XOR<ExecutorCreateWithoutUserInput, ExecutorUncheckedCreateWithoutUserInput>
    connectOrCreate?: ExecutorCreateOrConnectWithoutUserInput
    upsert?: ExecutorUpsertWithoutUserInput
    disconnect?: ExecutorWhereInput | boolean
    delete?: ExecutorWhereInput | boolean
    connect?: ExecutorWhereUniqueInput
    update?: XOR<XOR<ExecutorUpdateToOneWithWhereWithoutUserInput, ExecutorUpdateWithoutUserInput>, ExecutorUncheckedUpdateWithoutUserInput>
  }

  export type PhotoUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<PhotoCreateWithoutUserInput, PhotoUncheckedCreateWithoutUserInput> | PhotoCreateWithoutUserInput[] | PhotoUncheckedCreateWithoutUserInput[]
    connectOrCreate?: PhotoCreateOrConnectWithoutUserInput | PhotoCreateOrConnectWithoutUserInput[]
    upsert?: PhotoUpsertWithWhereUniqueWithoutUserInput | PhotoUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: PhotoCreateManyUserInputEnvelope
    set?: PhotoWhereUniqueInput | PhotoWhereUniqueInput[]
    disconnect?: PhotoWhereUniqueInput | PhotoWhereUniqueInput[]
    delete?: PhotoWhereUniqueInput | PhotoWhereUniqueInput[]
    connect?: PhotoWhereUniqueInput | PhotoWhereUniqueInput[]
    update?: PhotoUpdateWithWhereUniqueWithoutUserInput | PhotoUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: PhotoUpdateManyWithWhereWithoutUserInput | PhotoUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: PhotoScalarWhereInput | PhotoScalarWhereInput[]
  }

  export type SettingsUncheckedUpdateOneWithoutUserNestedInput = {
    create?: XOR<SettingsCreateWithoutUserInput, SettingsUncheckedCreateWithoutUserInput>
    connectOrCreate?: SettingsCreateOrConnectWithoutUserInput
    upsert?: SettingsUpsertWithoutUserInput
    disconnect?: SettingsWhereInput | boolean
    delete?: SettingsWhereInput | boolean
    connect?: SettingsWhereUniqueInput
    update?: XOR<XOR<SettingsUpdateToOneWithWhereWithoutUserInput, SettingsUpdateWithoutUserInput>, SettingsUncheckedUpdateWithoutUserInput>
  }

  export type MessageInviteUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<MessageInviteCreateWithoutUserInput, MessageInviteUncheckedCreateWithoutUserInput> | MessageInviteCreateWithoutUserInput[] | MessageInviteUncheckedCreateWithoutUserInput[]
    connectOrCreate?: MessageInviteCreateOrConnectWithoutUserInput | MessageInviteCreateOrConnectWithoutUserInput[]
    upsert?: MessageInviteUpsertWithWhereUniqueWithoutUserInput | MessageInviteUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: MessageInviteCreateManyUserInputEnvelope
    set?: MessageInviteWhereUniqueInput | MessageInviteWhereUniqueInput[]
    disconnect?: MessageInviteWhereUniqueInput | MessageInviteWhereUniqueInput[]
    delete?: MessageInviteWhereUniqueInput | MessageInviteWhereUniqueInput[]
    connect?: MessageInviteWhereUniqueInput | MessageInviteWhereUniqueInput[]
    update?: MessageInviteUpdateWithWhereUniqueWithoutUserInput | MessageInviteUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: MessageInviteUpdateManyWithWhereWithoutUserInput | MessageInviteUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: MessageInviteScalarWhereInput | MessageInviteScalarWhereInput[]
  }

  export type ContributionUncheckedUpdateManyWithoutUserNestedInput = {
    create?: XOR<ContributionCreateWithoutUserInput, ContributionUncheckedCreateWithoutUserInput> | ContributionCreateWithoutUserInput[] | ContributionUncheckedCreateWithoutUserInput[]
    connectOrCreate?: ContributionCreateOrConnectWithoutUserInput | ContributionCreateOrConnectWithoutUserInput[]
    upsert?: ContributionUpsertWithWhereUniqueWithoutUserInput | ContributionUpsertWithWhereUniqueWithoutUserInput[]
    createMany?: ContributionCreateManyUserInputEnvelope
    set?: ContributionWhereUniqueInput | ContributionWhereUniqueInput[]
    disconnect?: ContributionWhereUniqueInput | ContributionWhereUniqueInput[]
    delete?: ContributionWhereUniqueInput | ContributionWhereUniqueInput[]
    connect?: ContributionWhereUniqueInput | ContributionWhereUniqueInput[]
    update?: ContributionUpdateWithWhereUniqueWithoutUserInput | ContributionUpdateWithWhereUniqueWithoutUserInput[]
    updateMany?: ContributionUpdateManyWithWhereWithoutUserInput | ContributionUpdateManyWithWhereWithoutUserInput[]
    deleteMany?: ContributionScalarWhereInput | ContributionScalarWhereInput[]
  }

  export type UserCreateNestedOneWithoutContactsInput = {
    create?: XOR<UserCreateWithoutContactsInput, UserUncheckedCreateWithoutContactsInput>
    connectOrCreate?: UserCreateOrConnectWithoutContactsInput
    connect?: UserWhereUniqueInput
  }

  export type BoolFieldUpdateOperationsInput = {
    set?: boolean
  }

  export type UserUpdateOneRequiredWithoutContactsNestedInput = {
    create?: XOR<UserCreateWithoutContactsInput, UserUncheckedCreateWithoutContactsInput>
    connectOrCreate?: UserCreateOrConnectWithoutContactsInput
    upsert?: UserUpsertWithoutContactsInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutContactsInput, UserUpdateWithoutContactsInput>, UserUncheckedUpdateWithoutContactsInput>
  }

  export type UserCreateNestedOneWithoutMessagesInput = {
    create?: XOR<UserCreateWithoutMessagesInput, UserUncheckedCreateWithoutMessagesInput>
    connectOrCreate?: UserCreateOrConnectWithoutMessagesInput
    connect?: UserWhereUniqueInput
  }

  export type NullableIntFieldUpdateOperationsInput = {
    set?: number | null
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type IntFieldUpdateOperationsInput = {
    set?: number
    increment?: number
    decrement?: number
    multiply?: number
    divide?: number
  }

  export type UserUpdateOneRequiredWithoutMessagesNestedInput = {
    create?: XOR<UserCreateWithoutMessagesInput, UserUncheckedCreateWithoutMessagesInput>
    connectOrCreate?: UserCreateOrConnectWithoutMessagesInput
    upsert?: UserUpsertWithoutMessagesInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutMessagesInput, UserUpdateWithoutMessagesInput>, UserUncheckedUpdateWithoutMessagesInput>
  }

  export type UserCreateNestedOneWithoutMessageInvitesInput = {
    create?: XOR<UserCreateWithoutMessageInvitesInput, UserUncheckedCreateWithoutMessageInvitesInput>
    connectOrCreate?: UserCreateOrConnectWithoutMessageInvitesInput
    connect?: UserWhereUniqueInput
  }

  export type ContributionCreateNestedManyWithoutInviteInput = {
    create?: XOR<ContributionCreateWithoutInviteInput, ContributionUncheckedCreateWithoutInviteInput> | ContributionCreateWithoutInviteInput[] | ContributionUncheckedCreateWithoutInviteInput[]
    connectOrCreate?: ContributionCreateOrConnectWithoutInviteInput | ContributionCreateOrConnectWithoutInviteInput[]
    createMany?: ContributionCreateManyInviteInputEnvelope
    connect?: ContributionWhereUniqueInput | ContributionWhereUniqueInput[]
  }

  export type ContributionUncheckedCreateNestedManyWithoutInviteInput = {
    create?: XOR<ContributionCreateWithoutInviteInput, ContributionUncheckedCreateWithoutInviteInput> | ContributionCreateWithoutInviteInput[] | ContributionUncheckedCreateWithoutInviteInput[]
    connectOrCreate?: ContributionCreateOrConnectWithoutInviteInput | ContributionCreateOrConnectWithoutInviteInput[]
    createMany?: ContributionCreateManyInviteInputEnvelope
    connect?: ContributionWhereUniqueInput | ContributionWhereUniqueInput[]
  }

  export type UserUpdateOneRequiredWithoutMessageInvitesNestedInput = {
    create?: XOR<UserCreateWithoutMessageInvitesInput, UserUncheckedCreateWithoutMessageInvitesInput>
    connectOrCreate?: UserCreateOrConnectWithoutMessageInvitesInput
    upsert?: UserUpsertWithoutMessageInvitesInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutMessageInvitesInput, UserUpdateWithoutMessageInvitesInput>, UserUncheckedUpdateWithoutMessageInvitesInput>
  }

  export type ContributionUpdateManyWithoutInviteNestedInput = {
    create?: XOR<ContributionCreateWithoutInviteInput, ContributionUncheckedCreateWithoutInviteInput> | ContributionCreateWithoutInviteInput[] | ContributionUncheckedCreateWithoutInviteInput[]
    connectOrCreate?: ContributionCreateOrConnectWithoutInviteInput | ContributionCreateOrConnectWithoutInviteInput[]
    upsert?: ContributionUpsertWithWhereUniqueWithoutInviteInput | ContributionUpsertWithWhereUniqueWithoutInviteInput[]
    createMany?: ContributionCreateManyInviteInputEnvelope
    set?: ContributionWhereUniqueInput | ContributionWhereUniqueInput[]
    disconnect?: ContributionWhereUniqueInput | ContributionWhereUniqueInput[]
    delete?: ContributionWhereUniqueInput | ContributionWhereUniqueInput[]
    connect?: ContributionWhereUniqueInput | ContributionWhereUniqueInput[]
    update?: ContributionUpdateWithWhereUniqueWithoutInviteInput | ContributionUpdateWithWhereUniqueWithoutInviteInput[]
    updateMany?: ContributionUpdateManyWithWhereWithoutInviteInput | ContributionUpdateManyWithWhereWithoutInviteInput[]
    deleteMany?: ContributionScalarWhereInput | ContributionScalarWhereInput[]
  }

  export type ContributionUncheckedUpdateManyWithoutInviteNestedInput = {
    create?: XOR<ContributionCreateWithoutInviteInput, ContributionUncheckedCreateWithoutInviteInput> | ContributionCreateWithoutInviteInput[] | ContributionUncheckedCreateWithoutInviteInput[]
    connectOrCreate?: ContributionCreateOrConnectWithoutInviteInput | ContributionCreateOrConnectWithoutInviteInput[]
    upsert?: ContributionUpsertWithWhereUniqueWithoutInviteInput | ContributionUpsertWithWhereUniqueWithoutInviteInput[]
    createMany?: ContributionCreateManyInviteInputEnvelope
    set?: ContributionWhereUniqueInput | ContributionWhereUniqueInput[]
    disconnect?: ContributionWhereUniqueInput | ContributionWhereUniqueInput[]
    delete?: ContributionWhereUniqueInput | ContributionWhereUniqueInput[]
    connect?: ContributionWhereUniqueInput | ContributionWhereUniqueInput[]
    update?: ContributionUpdateWithWhereUniqueWithoutInviteInput | ContributionUpdateWithWhereUniqueWithoutInviteInput[]
    updateMany?: ContributionUpdateManyWithWhereWithoutInviteInput | ContributionUpdateManyWithWhereWithoutInviteInput[]
    deleteMany?: ContributionScalarWhereInput | ContributionScalarWhereInput[]
  }

  export type UserCreateNestedOneWithoutContributionsInput = {
    create?: XOR<UserCreateWithoutContributionsInput, UserUncheckedCreateWithoutContributionsInput>
    connectOrCreate?: UserCreateOrConnectWithoutContributionsInput
    connect?: UserWhereUniqueInput
  }

  export type MessageInviteCreateNestedOneWithoutContributionsInput = {
    create?: XOR<MessageInviteCreateWithoutContributionsInput, MessageInviteUncheckedCreateWithoutContributionsInput>
    connectOrCreate?: MessageInviteCreateOrConnectWithoutContributionsInput
    connect?: MessageInviteWhereUniqueInput
  }

  export type UserUpdateOneRequiredWithoutContributionsNestedInput = {
    create?: XOR<UserCreateWithoutContributionsInput, UserUncheckedCreateWithoutContributionsInput>
    connectOrCreate?: UserCreateOrConnectWithoutContributionsInput
    upsert?: UserUpsertWithoutContributionsInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutContributionsInput, UserUpdateWithoutContributionsInput>, UserUncheckedUpdateWithoutContributionsInput>
  }

  export type MessageInviteUpdateOneRequiredWithoutContributionsNestedInput = {
    create?: XOR<MessageInviteCreateWithoutContributionsInput, MessageInviteUncheckedCreateWithoutContributionsInput>
    connectOrCreate?: MessageInviteCreateOrConnectWithoutContributionsInput
    upsert?: MessageInviteUpsertWithoutContributionsInput
    connect?: MessageInviteWhereUniqueInput
    update?: XOR<XOR<MessageInviteUpdateToOneWithWhereWithoutContributionsInput, MessageInviteUpdateWithoutContributionsInput>, MessageInviteUncheckedUpdateWithoutContributionsInput>
  }

  export type UserCreateNestedOneWithoutTimelineItemsInput = {
    create?: XOR<UserCreateWithoutTimelineItemsInput, UserUncheckedCreateWithoutTimelineItemsInput>
    connectOrCreate?: UserCreateOrConnectWithoutTimelineItemsInput
    connect?: UserWhereUniqueInput
  }

  export type PhotoCreateNestedManyWithoutTimelineItemInput = {
    create?: XOR<PhotoCreateWithoutTimelineItemInput, PhotoUncheckedCreateWithoutTimelineItemInput> | PhotoCreateWithoutTimelineItemInput[] | PhotoUncheckedCreateWithoutTimelineItemInput[]
    connectOrCreate?: PhotoCreateOrConnectWithoutTimelineItemInput | PhotoCreateOrConnectWithoutTimelineItemInput[]
    createMany?: PhotoCreateManyTimelineItemInputEnvelope
    connect?: PhotoWhereUniqueInput | PhotoWhereUniqueInput[]
  }

  export type PhotoUncheckedCreateNestedManyWithoutTimelineItemInput = {
    create?: XOR<PhotoCreateWithoutTimelineItemInput, PhotoUncheckedCreateWithoutTimelineItemInput> | PhotoCreateWithoutTimelineItemInput[] | PhotoUncheckedCreateWithoutTimelineItemInput[]
    connectOrCreate?: PhotoCreateOrConnectWithoutTimelineItemInput | PhotoCreateOrConnectWithoutTimelineItemInput[]
    createMany?: PhotoCreateManyTimelineItemInputEnvelope
    connect?: PhotoWhereUniqueInput | PhotoWhereUniqueInput[]
  }

  export type UserUpdateOneRequiredWithoutTimelineItemsNestedInput = {
    create?: XOR<UserCreateWithoutTimelineItemsInput, UserUncheckedCreateWithoutTimelineItemsInput>
    connectOrCreate?: UserCreateOrConnectWithoutTimelineItemsInput
    upsert?: UserUpsertWithoutTimelineItemsInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutTimelineItemsInput, UserUpdateWithoutTimelineItemsInput>, UserUncheckedUpdateWithoutTimelineItemsInput>
  }

  export type PhotoUpdateManyWithoutTimelineItemNestedInput = {
    create?: XOR<PhotoCreateWithoutTimelineItemInput, PhotoUncheckedCreateWithoutTimelineItemInput> | PhotoCreateWithoutTimelineItemInput[] | PhotoUncheckedCreateWithoutTimelineItemInput[]
    connectOrCreate?: PhotoCreateOrConnectWithoutTimelineItemInput | PhotoCreateOrConnectWithoutTimelineItemInput[]
    upsert?: PhotoUpsertWithWhereUniqueWithoutTimelineItemInput | PhotoUpsertWithWhereUniqueWithoutTimelineItemInput[]
    createMany?: PhotoCreateManyTimelineItemInputEnvelope
    set?: PhotoWhereUniqueInput | PhotoWhereUniqueInput[]
    disconnect?: PhotoWhereUniqueInput | PhotoWhereUniqueInput[]
    delete?: PhotoWhereUniqueInput | PhotoWhereUniqueInput[]
    connect?: PhotoWhereUniqueInput | PhotoWhereUniqueInput[]
    update?: PhotoUpdateWithWhereUniqueWithoutTimelineItemInput | PhotoUpdateWithWhereUniqueWithoutTimelineItemInput[]
    updateMany?: PhotoUpdateManyWithWhereWithoutTimelineItemInput | PhotoUpdateManyWithWhereWithoutTimelineItemInput[]
    deleteMany?: PhotoScalarWhereInput | PhotoScalarWhereInput[]
  }

  export type PhotoUncheckedUpdateManyWithoutTimelineItemNestedInput = {
    create?: XOR<PhotoCreateWithoutTimelineItemInput, PhotoUncheckedCreateWithoutTimelineItemInput> | PhotoCreateWithoutTimelineItemInput[] | PhotoUncheckedCreateWithoutTimelineItemInput[]
    connectOrCreate?: PhotoCreateOrConnectWithoutTimelineItemInput | PhotoCreateOrConnectWithoutTimelineItemInput[]
    upsert?: PhotoUpsertWithWhereUniqueWithoutTimelineItemInput | PhotoUpsertWithWhereUniqueWithoutTimelineItemInput[]
    createMany?: PhotoCreateManyTimelineItemInputEnvelope
    set?: PhotoWhereUniqueInput | PhotoWhereUniqueInput[]
    disconnect?: PhotoWhereUniqueInput | PhotoWhereUniqueInput[]
    delete?: PhotoWhereUniqueInput | PhotoWhereUniqueInput[]
    connect?: PhotoWhereUniqueInput | PhotoWhereUniqueInput[]
    update?: PhotoUpdateWithWhereUniqueWithoutTimelineItemInput | PhotoUpdateWithWhereUniqueWithoutTimelineItemInput[]
    updateMany?: PhotoUpdateManyWithWhereWithoutTimelineItemInput | PhotoUpdateManyWithWhereWithoutTimelineItemInput[]
    deleteMany?: PhotoScalarWhereInput | PhotoScalarWhereInput[]
  }

  export type UserCreateNestedOneWithoutPhotosInput = {
    create?: XOR<UserCreateWithoutPhotosInput, UserUncheckedCreateWithoutPhotosInput>
    connectOrCreate?: UserCreateOrConnectWithoutPhotosInput
    connect?: UserWhereUniqueInput
  }

  export type TimelineItemCreateNestedOneWithoutPhotosInput = {
    create?: XOR<TimelineItemCreateWithoutPhotosInput, TimelineItemUncheckedCreateWithoutPhotosInput>
    connectOrCreate?: TimelineItemCreateOrConnectWithoutPhotosInput
    connect?: TimelineItemWhereUniqueInput
  }

  export type UserUpdateOneRequiredWithoutPhotosNestedInput = {
    create?: XOR<UserCreateWithoutPhotosInput, UserUncheckedCreateWithoutPhotosInput>
    connectOrCreate?: UserCreateOrConnectWithoutPhotosInput
    upsert?: UserUpsertWithoutPhotosInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutPhotosInput, UserUpdateWithoutPhotosInput>, UserUncheckedUpdateWithoutPhotosInput>
  }

  export type TimelineItemUpdateOneWithoutPhotosNestedInput = {
    create?: XOR<TimelineItemCreateWithoutPhotosInput, TimelineItemUncheckedCreateWithoutPhotosInput>
    connectOrCreate?: TimelineItemCreateOrConnectWithoutPhotosInput
    upsert?: TimelineItemUpsertWithoutPhotosInput
    disconnect?: TimelineItemWhereInput | boolean
    delete?: TimelineItemWhereInput | boolean
    connect?: TimelineItemWhereUniqueInput
    update?: XOR<XOR<TimelineItemUpdateToOneWithWhereWithoutPhotosInput, TimelineItemUpdateWithoutPhotosInput>, TimelineItemUncheckedUpdateWithoutPhotosInput>
  }

  export type UserCreateNestedOneWithoutArrangementsInput = {
    create?: XOR<UserCreateWithoutArrangementsInput, UserUncheckedCreateWithoutArrangementsInput>
    connectOrCreate?: UserCreateOrConnectWithoutArrangementsInput
    connect?: UserWhereUniqueInput
  }

  export type UserUpdateOneRequiredWithoutArrangementsNestedInput = {
    create?: XOR<UserCreateWithoutArrangementsInput, UserUncheckedCreateWithoutArrangementsInput>
    connectOrCreate?: UserCreateOrConnectWithoutArrangementsInput
    upsert?: UserUpsertWithoutArrangementsInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutArrangementsInput, UserUpdateWithoutArrangementsInput>, UserUncheckedUpdateWithoutArrangementsInput>
  }

  export type UserCreateNestedOneWithoutVaultItemsInput = {
    create?: XOR<UserCreateWithoutVaultItemsInput, UserUncheckedCreateWithoutVaultItemsInput>
    connectOrCreate?: UserCreateOrConnectWithoutVaultItemsInput
    connect?: UserWhereUniqueInput
  }

  export type UserUpdateOneRequiredWithoutVaultItemsNestedInput = {
    create?: XOR<UserCreateWithoutVaultItemsInput, UserUncheckedCreateWithoutVaultItemsInput>
    connectOrCreate?: UserCreateOrConnectWithoutVaultItemsInput
    upsert?: UserUpsertWithoutVaultItemsInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutVaultItemsInput, UserUpdateWithoutVaultItemsInput>, UserUncheckedUpdateWithoutVaultItemsInput>
  }

  export type UserCreateNestedOneWithoutExecutorInput = {
    create?: XOR<UserCreateWithoutExecutorInput, UserUncheckedCreateWithoutExecutorInput>
    connectOrCreate?: UserCreateOrConnectWithoutExecutorInput
    connect?: UserWhereUniqueInput
  }

  export type UserUpdateOneRequiredWithoutExecutorNestedInput = {
    create?: XOR<UserCreateWithoutExecutorInput, UserUncheckedCreateWithoutExecutorInput>
    connectOrCreate?: UserCreateOrConnectWithoutExecutorInput
    upsert?: UserUpsertWithoutExecutorInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutExecutorInput, UserUpdateWithoutExecutorInput>, UserUncheckedUpdateWithoutExecutorInput>
  }

  export type UserCreateNestedOneWithoutSettingsInput = {
    create?: XOR<UserCreateWithoutSettingsInput, UserUncheckedCreateWithoutSettingsInput>
    connectOrCreate?: UserCreateOrConnectWithoutSettingsInput
    connect?: UserWhereUniqueInput
  }

  export type UserUpdateOneRequiredWithoutSettingsNestedInput = {
    create?: XOR<UserCreateWithoutSettingsInput, UserUncheckedCreateWithoutSettingsInput>
    connectOrCreate?: UserCreateOrConnectWithoutSettingsInput
    upsert?: UserUpsertWithoutSettingsInput
    connect?: UserWhereUniqueInput
    update?: XOR<XOR<UserUpdateToOneWithWhereWithoutSettingsInput, UserUpdateWithoutSettingsInput>, UserUncheckedUpdateWithoutSettingsInput>
  }

  export type NestedStringFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringFilter<$PrismaModel> | string
  }

  export type NestedStringNullableFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableFilter<$PrismaModel> | string | null
  }

  export type NestedDateTimeNullableFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableFilter<$PrismaModel> | Date | string | null
  }

  export type NestedDateTimeFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeFilter<$PrismaModel> | Date | string
  }

  export type NestedStringWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel>
    in?: string[] | ListStringFieldRefInput<$PrismaModel>
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel>
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringWithAggregatesFilter<$PrismaModel> | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedStringFilter<$PrismaModel>
    _max?: NestedStringFilter<$PrismaModel>
  }

  export type NestedIntFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntFilter<$PrismaModel> | number
  }

  export type NestedStringNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: string | StringFieldRefInput<$PrismaModel> | null
    in?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    notIn?: string[] | ListStringFieldRefInput<$PrismaModel> | null
    lt?: string | StringFieldRefInput<$PrismaModel>
    lte?: string | StringFieldRefInput<$PrismaModel>
    gt?: string | StringFieldRefInput<$PrismaModel>
    gte?: string | StringFieldRefInput<$PrismaModel>
    contains?: string | StringFieldRefInput<$PrismaModel>
    startsWith?: string | StringFieldRefInput<$PrismaModel>
    endsWith?: string | StringFieldRefInput<$PrismaModel>
    not?: NestedStringNullableWithAggregatesFilter<$PrismaModel> | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedStringNullableFilter<$PrismaModel>
    _max?: NestedStringNullableFilter<$PrismaModel>
  }

  export type NestedIntNullableFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableFilter<$PrismaModel> | number | null
  }

  export type NestedDateTimeNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel> | null
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel> | null
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeNullableWithAggregatesFilter<$PrismaModel> | Date | string | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedDateTimeNullableFilter<$PrismaModel>
    _max?: NestedDateTimeNullableFilter<$PrismaModel>
  }

  export type NestedDateTimeWithAggregatesFilter<$PrismaModel = never> = {
    equals?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    in?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    notIn?: Date[] | string[] | ListDateTimeFieldRefInput<$PrismaModel>
    lt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    lte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gt?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    gte?: Date | string | DateTimeFieldRefInput<$PrismaModel>
    not?: NestedDateTimeWithAggregatesFilter<$PrismaModel> | Date | string
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedDateTimeFilter<$PrismaModel>
    _max?: NestedDateTimeFilter<$PrismaModel>
  }

  export type NestedBoolFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolFilter<$PrismaModel> | boolean
  }

  export type NestedBoolWithAggregatesFilter<$PrismaModel = never> = {
    equals?: boolean | BooleanFieldRefInput<$PrismaModel>
    not?: NestedBoolWithAggregatesFilter<$PrismaModel> | boolean
    _count?: NestedIntFilter<$PrismaModel>
    _min?: NestedBoolFilter<$PrismaModel>
    _max?: NestedBoolFilter<$PrismaModel>
  }

  export type NestedIntNullableWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel> | null
    in?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel> | null
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntNullableWithAggregatesFilter<$PrismaModel> | number | null
    _count?: NestedIntNullableFilter<$PrismaModel>
    _avg?: NestedFloatNullableFilter<$PrismaModel>
    _sum?: NestedIntNullableFilter<$PrismaModel>
    _min?: NestedIntNullableFilter<$PrismaModel>
    _max?: NestedIntNullableFilter<$PrismaModel>
  }

  export type NestedFloatNullableFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel> | null
    in?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel> | null
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatNullableFilter<$PrismaModel> | number | null
  }

  export type NestedIntWithAggregatesFilter<$PrismaModel = never> = {
    equals?: number | IntFieldRefInput<$PrismaModel>
    in?: number[] | ListIntFieldRefInput<$PrismaModel>
    notIn?: number[] | ListIntFieldRefInput<$PrismaModel>
    lt?: number | IntFieldRefInput<$PrismaModel>
    lte?: number | IntFieldRefInput<$PrismaModel>
    gt?: number | IntFieldRefInput<$PrismaModel>
    gte?: number | IntFieldRefInput<$PrismaModel>
    not?: NestedIntWithAggregatesFilter<$PrismaModel> | number
    _count?: NestedIntFilter<$PrismaModel>
    _avg?: NestedFloatFilter<$PrismaModel>
    _sum?: NestedIntFilter<$PrismaModel>
    _min?: NestedIntFilter<$PrismaModel>
    _max?: NestedIntFilter<$PrismaModel>
  }

  export type NestedFloatFilter<$PrismaModel = never> = {
    equals?: number | FloatFieldRefInput<$PrismaModel>
    in?: number[] | ListFloatFieldRefInput<$PrismaModel>
    notIn?: number[] | ListFloatFieldRefInput<$PrismaModel>
    lt?: number | FloatFieldRefInput<$PrismaModel>
    lte?: number | FloatFieldRefInput<$PrismaModel>
    gt?: number | FloatFieldRefInput<$PrismaModel>
    gte?: number | FloatFieldRefInput<$PrismaModel>
    not?: NestedFloatFilter<$PrismaModel> | number
  }

  export type ContactCreateWithoutUserInput = {
    id?: string
    name: string
    email?: string | null
    phone?: string | null
    relationship?: string | null
    isExecutor?: boolean
    isBackup?: boolean
    createdAt?: Date | string
  }

  export type ContactUncheckedCreateWithoutUserInput = {
    id?: string
    name: string
    email?: string | null
    phone?: string | null
    relationship?: string | null
    isExecutor?: boolean
    isBackup?: boolean
    createdAt?: Date | string
  }

  export type ContactCreateOrConnectWithoutUserInput = {
    where: ContactWhereUniqueInput
    create: XOR<ContactCreateWithoutUserInput, ContactUncheckedCreateWithoutUserInput>
  }

  export type ContactCreateManyUserInputEnvelope = {
    data: ContactCreateManyUserInput | ContactCreateManyUserInput[]
    skipDuplicates?: boolean
  }

  export type MessageCreateWithoutUserInput = {
    id?: string
    recipientName: string
    recipientEmail?: string | null
    type?: string
    subject?: string | null
    content?: string | null
    mediaUrl?: string | null
    mediaBlobPath?: string | null
    mediaDurationSec?: number | null
    triggerDate?: Date | string | null
    state?: string
    approvalPromptedAt?: Date | string | null
    approvalExpiresAt?: Date | string | null
    sentAt?: Date | string | null
    archivedAt?: Date | string | null
    deliveryToken?: string | null
    approvalToken?: string | null
    approvalRemindersSent?: number
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type MessageUncheckedCreateWithoutUserInput = {
    id?: string
    recipientName: string
    recipientEmail?: string | null
    type?: string
    subject?: string | null
    content?: string | null
    mediaUrl?: string | null
    mediaBlobPath?: string | null
    mediaDurationSec?: number | null
    triggerDate?: Date | string | null
    state?: string
    approvalPromptedAt?: Date | string | null
    approvalExpiresAt?: Date | string | null
    sentAt?: Date | string | null
    archivedAt?: Date | string | null
    deliveryToken?: string | null
    approvalToken?: string | null
    approvalRemindersSent?: number
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type MessageCreateOrConnectWithoutUserInput = {
    where: MessageWhereUniqueInput
    create: XOR<MessageCreateWithoutUserInput, MessageUncheckedCreateWithoutUserInput>
  }

  export type MessageCreateManyUserInputEnvelope = {
    data: MessageCreateManyUserInput | MessageCreateManyUserInput[]
    skipDuplicates?: boolean
  }

  export type ArrangementCreateWithoutUserInput = {
    id?: string
    type: string
    vendor: string
    contact?: string | null
    notes?: string | null
    createdAt?: Date | string
  }

  export type ArrangementUncheckedCreateWithoutUserInput = {
    id?: string
    type: string
    vendor: string
    contact?: string | null
    notes?: string | null
    createdAt?: Date | string
  }

  export type ArrangementCreateOrConnectWithoutUserInput = {
    where: ArrangementWhereUniqueInput
    create: XOR<ArrangementCreateWithoutUserInput, ArrangementUncheckedCreateWithoutUserInput>
  }

  export type ArrangementCreateManyUserInputEnvelope = {
    data: ArrangementCreateManyUserInput | ArrangementCreateManyUserInput[]
    skipDuplicates?: boolean
  }

  export type TimelineItemCreateWithoutUserInput = {
    id?: string
    date: Date | string
    title: string
    story?: string | null
    mediaUrl?: string | null
    createdAt?: Date | string
    photos?: PhotoCreateNestedManyWithoutTimelineItemInput
  }

  export type TimelineItemUncheckedCreateWithoutUserInput = {
    id?: string
    date: Date | string
    title: string
    story?: string | null
    mediaUrl?: string | null
    createdAt?: Date | string
    photos?: PhotoUncheckedCreateNestedManyWithoutTimelineItemInput
  }

  export type TimelineItemCreateOrConnectWithoutUserInput = {
    where: TimelineItemWhereUniqueInput
    create: XOR<TimelineItemCreateWithoutUserInput, TimelineItemUncheckedCreateWithoutUserInput>
  }

  export type TimelineItemCreateManyUserInputEnvelope = {
    data: TimelineItemCreateManyUserInput | TimelineItemCreateManyUserInput[]
    skipDuplicates?: boolean
  }

  export type VaultItemCreateWithoutUserInput = {
    id?: string
    label: string
    encryptedData: string
    createdAt?: Date | string
  }

  export type VaultItemUncheckedCreateWithoutUserInput = {
    id?: string
    label: string
    encryptedData: string
    createdAt?: Date | string
  }

  export type VaultItemCreateOrConnectWithoutUserInput = {
    where: VaultItemWhereUniqueInput
    create: XOR<VaultItemCreateWithoutUserInput, VaultItemUncheckedCreateWithoutUserInput>
  }

  export type VaultItemCreateManyUserInputEnvelope = {
    data: VaultItemCreateManyUserInput | VaultItemCreateManyUserInput[]
    skipDuplicates?: boolean
  }

  export type ExecutorCreateWithoutUserInput = {
    id?: string
    name: string
    email: string
    phone?: string | null
    verified?: boolean
    certUploadedAt?: Date | string | null
    unlockedAt?: Date | string | null
    createdAt?: Date | string
  }

  export type ExecutorUncheckedCreateWithoutUserInput = {
    id?: string
    name: string
    email: string
    phone?: string | null
    verified?: boolean
    certUploadedAt?: Date | string | null
    unlockedAt?: Date | string | null
    createdAt?: Date | string
  }

  export type ExecutorCreateOrConnectWithoutUserInput = {
    where: ExecutorWhereUniqueInput
    create: XOR<ExecutorCreateWithoutUserInput, ExecutorUncheckedCreateWithoutUserInput>
  }

  export type PhotoCreateWithoutUserInput = {
    id?: string
    url: string
    thumbnailUrl?: string | null
    blobPath: string
    caption?: string | null
    width?: number | null
    height?: number | null
    sizeBytes?: number | null
    order?: number
    createdAt?: Date | string
    timelineItem?: TimelineItemCreateNestedOneWithoutPhotosInput
  }

  export type PhotoUncheckedCreateWithoutUserInput = {
    id?: string
    timelineItemId?: string | null
    url: string
    thumbnailUrl?: string | null
    blobPath: string
    caption?: string | null
    width?: number | null
    height?: number | null
    sizeBytes?: number | null
    order?: number
    createdAt?: Date | string
  }

  export type PhotoCreateOrConnectWithoutUserInput = {
    where: PhotoWhereUniqueInput
    create: XOR<PhotoCreateWithoutUserInput, PhotoUncheckedCreateWithoutUserInput>
  }

  export type PhotoCreateManyUserInputEnvelope = {
    data: PhotoCreateManyUserInput | PhotoCreateManyUserInput[]
    skipDuplicates?: boolean
  }

  export type SettingsCreateWithoutUserInput = {
    id?: string
    pageTurnStyle?: string
    fontScale?: string
    highContrast?: boolean
    ttsEnabled?: boolean
    sttEnabled?: boolean
    reducedMotion?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type SettingsUncheckedCreateWithoutUserInput = {
    id?: string
    pageTurnStyle?: string
    fontScale?: string
    highContrast?: boolean
    ttsEnabled?: boolean
    sttEnabled?: boolean
    reducedMotion?: boolean
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type SettingsCreateOrConnectWithoutUserInput = {
    where: SettingsWhereUniqueInput
    create: XOR<SettingsCreateWithoutUserInput, SettingsUncheckedCreateWithoutUserInput>
  }

  export type MessageInviteCreateWithoutUserInput = {
    id?: string
    token: string
    contributorName: string
    contributorEmail?: string | null
    message?: string | null
    expiresAt: Date | string
    revokedAt?: Date | string | null
    lastUsedAt?: Date | string | null
    useCount?: number
    createdAt?: Date | string
    contributions?: ContributionCreateNestedManyWithoutInviteInput
  }

  export type MessageInviteUncheckedCreateWithoutUserInput = {
    id?: string
    token: string
    contributorName: string
    contributorEmail?: string | null
    message?: string | null
    expiresAt: Date | string
    revokedAt?: Date | string | null
    lastUsedAt?: Date | string | null
    useCount?: number
    createdAt?: Date | string
    contributions?: ContributionUncheckedCreateNestedManyWithoutInviteInput
  }

  export type MessageInviteCreateOrConnectWithoutUserInput = {
    where: MessageInviteWhereUniqueInput
    create: XOR<MessageInviteCreateWithoutUserInput, MessageInviteUncheckedCreateWithoutUserInput>
  }

  export type MessageInviteCreateManyUserInputEnvelope = {
    data: MessageInviteCreateManyUserInput | MessageInviteCreateManyUserInput[]
    skipDuplicates?: boolean
  }

  export type ContributionCreateWithoutUserInput = {
    id?: string
    contributorName: string
    contributorNote?: string | null
    type: string
    content?: string | null
    mediaUrl?: string | null
    mediaBlobPath?: string | null
    viewedByUser?: boolean
    importedToTimelineItemId?: string | null
    archivedAt?: Date | string | null
    createdAt?: Date | string
    invite: MessageInviteCreateNestedOneWithoutContributionsInput
  }

  export type ContributionUncheckedCreateWithoutUserInput = {
    id?: string
    inviteId: string
    contributorName: string
    contributorNote?: string | null
    type: string
    content?: string | null
    mediaUrl?: string | null
    mediaBlobPath?: string | null
    viewedByUser?: boolean
    importedToTimelineItemId?: string | null
    archivedAt?: Date | string | null
    createdAt?: Date | string
  }

  export type ContributionCreateOrConnectWithoutUserInput = {
    where: ContributionWhereUniqueInput
    create: XOR<ContributionCreateWithoutUserInput, ContributionUncheckedCreateWithoutUserInput>
  }

  export type ContributionCreateManyUserInputEnvelope = {
    data: ContributionCreateManyUserInput | ContributionCreateManyUserInput[]
    skipDuplicates?: boolean
  }

  export type ContactUpsertWithWhereUniqueWithoutUserInput = {
    where: ContactWhereUniqueInput
    update: XOR<ContactUpdateWithoutUserInput, ContactUncheckedUpdateWithoutUserInput>
    create: XOR<ContactCreateWithoutUserInput, ContactUncheckedCreateWithoutUserInput>
  }

  export type ContactUpdateWithWhereUniqueWithoutUserInput = {
    where: ContactWhereUniqueInput
    data: XOR<ContactUpdateWithoutUserInput, ContactUncheckedUpdateWithoutUserInput>
  }

  export type ContactUpdateManyWithWhereWithoutUserInput = {
    where: ContactScalarWhereInput
    data: XOR<ContactUpdateManyMutationInput, ContactUncheckedUpdateManyWithoutUserInput>
  }

  export type ContactScalarWhereInput = {
    AND?: ContactScalarWhereInput | ContactScalarWhereInput[]
    OR?: ContactScalarWhereInput[]
    NOT?: ContactScalarWhereInput | ContactScalarWhereInput[]
    id?: StringFilter<"Contact"> | string
    userId?: StringFilter<"Contact"> | string
    name?: StringFilter<"Contact"> | string
    email?: StringNullableFilter<"Contact"> | string | null
    phone?: StringNullableFilter<"Contact"> | string | null
    relationship?: StringNullableFilter<"Contact"> | string | null
    isExecutor?: BoolFilter<"Contact"> | boolean
    isBackup?: BoolFilter<"Contact"> | boolean
    createdAt?: DateTimeFilter<"Contact"> | Date | string
  }

  export type MessageUpsertWithWhereUniqueWithoutUserInput = {
    where: MessageWhereUniqueInput
    update: XOR<MessageUpdateWithoutUserInput, MessageUncheckedUpdateWithoutUserInput>
    create: XOR<MessageCreateWithoutUserInput, MessageUncheckedCreateWithoutUserInput>
  }

  export type MessageUpdateWithWhereUniqueWithoutUserInput = {
    where: MessageWhereUniqueInput
    data: XOR<MessageUpdateWithoutUserInput, MessageUncheckedUpdateWithoutUserInput>
  }

  export type MessageUpdateManyWithWhereWithoutUserInput = {
    where: MessageScalarWhereInput
    data: XOR<MessageUpdateManyMutationInput, MessageUncheckedUpdateManyWithoutUserInput>
  }

  export type MessageScalarWhereInput = {
    AND?: MessageScalarWhereInput | MessageScalarWhereInput[]
    OR?: MessageScalarWhereInput[]
    NOT?: MessageScalarWhereInput | MessageScalarWhereInput[]
    id?: StringFilter<"Message"> | string
    userId?: StringFilter<"Message"> | string
    recipientName?: StringFilter<"Message"> | string
    recipientEmail?: StringNullableFilter<"Message"> | string | null
    type?: StringFilter<"Message"> | string
    subject?: StringNullableFilter<"Message"> | string | null
    content?: StringNullableFilter<"Message"> | string | null
    mediaUrl?: StringNullableFilter<"Message"> | string | null
    mediaBlobPath?: StringNullableFilter<"Message"> | string | null
    mediaDurationSec?: IntNullableFilter<"Message"> | number | null
    triggerDate?: DateTimeNullableFilter<"Message"> | Date | string | null
    state?: StringFilter<"Message"> | string
    approvalPromptedAt?: DateTimeNullableFilter<"Message"> | Date | string | null
    approvalExpiresAt?: DateTimeNullableFilter<"Message"> | Date | string | null
    sentAt?: DateTimeNullableFilter<"Message"> | Date | string | null
    archivedAt?: DateTimeNullableFilter<"Message"> | Date | string | null
    deliveryToken?: StringNullableFilter<"Message"> | string | null
    approvalToken?: StringNullableFilter<"Message"> | string | null
    approvalRemindersSent?: IntFilter<"Message"> | number
    createdAt?: DateTimeFilter<"Message"> | Date | string
    updatedAt?: DateTimeFilter<"Message"> | Date | string
  }

  export type ArrangementUpsertWithWhereUniqueWithoutUserInput = {
    where: ArrangementWhereUniqueInput
    update: XOR<ArrangementUpdateWithoutUserInput, ArrangementUncheckedUpdateWithoutUserInput>
    create: XOR<ArrangementCreateWithoutUserInput, ArrangementUncheckedCreateWithoutUserInput>
  }

  export type ArrangementUpdateWithWhereUniqueWithoutUserInput = {
    where: ArrangementWhereUniqueInput
    data: XOR<ArrangementUpdateWithoutUserInput, ArrangementUncheckedUpdateWithoutUserInput>
  }

  export type ArrangementUpdateManyWithWhereWithoutUserInput = {
    where: ArrangementScalarWhereInput
    data: XOR<ArrangementUpdateManyMutationInput, ArrangementUncheckedUpdateManyWithoutUserInput>
  }

  export type ArrangementScalarWhereInput = {
    AND?: ArrangementScalarWhereInput | ArrangementScalarWhereInput[]
    OR?: ArrangementScalarWhereInput[]
    NOT?: ArrangementScalarWhereInput | ArrangementScalarWhereInput[]
    id?: StringFilter<"Arrangement"> | string
    userId?: StringFilter<"Arrangement"> | string
    type?: StringFilter<"Arrangement"> | string
    vendor?: StringFilter<"Arrangement"> | string
    contact?: StringNullableFilter<"Arrangement"> | string | null
    notes?: StringNullableFilter<"Arrangement"> | string | null
    createdAt?: DateTimeFilter<"Arrangement"> | Date | string
  }

  export type TimelineItemUpsertWithWhereUniqueWithoutUserInput = {
    where: TimelineItemWhereUniqueInput
    update: XOR<TimelineItemUpdateWithoutUserInput, TimelineItemUncheckedUpdateWithoutUserInput>
    create: XOR<TimelineItemCreateWithoutUserInput, TimelineItemUncheckedCreateWithoutUserInput>
  }

  export type TimelineItemUpdateWithWhereUniqueWithoutUserInput = {
    where: TimelineItemWhereUniqueInput
    data: XOR<TimelineItemUpdateWithoutUserInput, TimelineItemUncheckedUpdateWithoutUserInput>
  }

  export type TimelineItemUpdateManyWithWhereWithoutUserInput = {
    where: TimelineItemScalarWhereInput
    data: XOR<TimelineItemUpdateManyMutationInput, TimelineItemUncheckedUpdateManyWithoutUserInput>
  }

  export type TimelineItemScalarWhereInput = {
    AND?: TimelineItemScalarWhereInput | TimelineItemScalarWhereInput[]
    OR?: TimelineItemScalarWhereInput[]
    NOT?: TimelineItemScalarWhereInput | TimelineItemScalarWhereInput[]
    id?: StringFilter<"TimelineItem"> | string
    userId?: StringFilter<"TimelineItem"> | string
    date?: DateTimeFilter<"TimelineItem"> | Date | string
    title?: StringFilter<"TimelineItem"> | string
    story?: StringNullableFilter<"TimelineItem"> | string | null
    mediaUrl?: StringNullableFilter<"TimelineItem"> | string | null
    createdAt?: DateTimeFilter<"TimelineItem"> | Date | string
  }

  export type VaultItemUpsertWithWhereUniqueWithoutUserInput = {
    where: VaultItemWhereUniqueInput
    update: XOR<VaultItemUpdateWithoutUserInput, VaultItemUncheckedUpdateWithoutUserInput>
    create: XOR<VaultItemCreateWithoutUserInput, VaultItemUncheckedCreateWithoutUserInput>
  }

  export type VaultItemUpdateWithWhereUniqueWithoutUserInput = {
    where: VaultItemWhereUniqueInput
    data: XOR<VaultItemUpdateWithoutUserInput, VaultItemUncheckedUpdateWithoutUserInput>
  }

  export type VaultItemUpdateManyWithWhereWithoutUserInput = {
    where: VaultItemScalarWhereInput
    data: XOR<VaultItemUpdateManyMutationInput, VaultItemUncheckedUpdateManyWithoutUserInput>
  }

  export type VaultItemScalarWhereInput = {
    AND?: VaultItemScalarWhereInput | VaultItemScalarWhereInput[]
    OR?: VaultItemScalarWhereInput[]
    NOT?: VaultItemScalarWhereInput | VaultItemScalarWhereInput[]
    id?: StringFilter<"VaultItem"> | string
    userId?: StringFilter<"VaultItem"> | string
    label?: StringFilter<"VaultItem"> | string
    encryptedData?: StringFilter<"VaultItem"> | string
    createdAt?: DateTimeFilter<"VaultItem"> | Date | string
  }

  export type ExecutorUpsertWithoutUserInput = {
    update: XOR<ExecutorUpdateWithoutUserInput, ExecutorUncheckedUpdateWithoutUserInput>
    create: XOR<ExecutorCreateWithoutUserInput, ExecutorUncheckedCreateWithoutUserInput>
    where?: ExecutorWhereInput
  }

  export type ExecutorUpdateToOneWithWhereWithoutUserInput = {
    where?: ExecutorWhereInput
    data: XOR<ExecutorUpdateWithoutUserInput, ExecutorUncheckedUpdateWithoutUserInput>
  }

  export type ExecutorUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    verified?: BoolFieldUpdateOperationsInput | boolean
    certUploadedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    unlockedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ExecutorUncheckedUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    verified?: BoolFieldUpdateOperationsInput | boolean
    certUploadedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    unlockedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PhotoUpsertWithWhereUniqueWithoutUserInput = {
    where: PhotoWhereUniqueInput
    update: XOR<PhotoUpdateWithoutUserInput, PhotoUncheckedUpdateWithoutUserInput>
    create: XOR<PhotoCreateWithoutUserInput, PhotoUncheckedCreateWithoutUserInput>
  }

  export type PhotoUpdateWithWhereUniqueWithoutUserInput = {
    where: PhotoWhereUniqueInput
    data: XOR<PhotoUpdateWithoutUserInput, PhotoUncheckedUpdateWithoutUserInput>
  }

  export type PhotoUpdateManyWithWhereWithoutUserInput = {
    where: PhotoScalarWhereInput
    data: XOR<PhotoUpdateManyMutationInput, PhotoUncheckedUpdateManyWithoutUserInput>
  }

  export type PhotoScalarWhereInput = {
    AND?: PhotoScalarWhereInput | PhotoScalarWhereInput[]
    OR?: PhotoScalarWhereInput[]
    NOT?: PhotoScalarWhereInput | PhotoScalarWhereInput[]
    id?: StringFilter<"Photo"> | string
    userId?: StringFilter<"Photo"> | string
    timelineItemId?: StringNullableFilter<"Photo"> | string | null
    url?: StringFilter<"Photo"> | string
    thumbnailUrl?: StringNullableFilter<"Photo"> | string | null
    blobPath?: StringFilter<"Photo"> | string
    caption?: StringNullableFilter<"Photo"> | string | null
    width?: IntNullableFilter<"Photo"> | number | null
    height?: IntNullableFilter<"Photo"> | number | null
    sizeBytes?: IntNullableFilter<"Photo"> | number | null
    order?: IntFilter<"Photo"> | number
    createdAt?: DateTimeFilter<"Photo"> | Date | string
  }

  export type SettingsUpsertWithoutUserInput = {
    update: XOR<SettingsUpdateWithoutUserInput, SettingsUncheckedUpdateWithoutUserInput>
    create: XOR<SettingsCreateWithoutUserInput, SettingsUncheckedCreateWithoutUserInput>
    where?: SettingsWhereInput
  }

  export type SettingsUpdateToOneWithWhereWithoutUserInput = {
    where?: SettingsWhereInput
    data: XOR<SettingsUpdateWithoutUserInput, SettingsUncheckedUpdateWithoutUserInput>
  }

  export type SettingsUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    pageTurnStyle?: StringFieldUpdateOperationsInput | string
    fontScale?: StringFieldUpdateOperationsInput | string
    highContrast?: BoolFieldUpdateOperationsInput | boolean
    ttsEnabled?: BoolFieldUpdateOperationsInput | boolean
    sttEnabled?: BoolFieldUpdateOperationsInput | boolean
    reducedMotion?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type SettingsUncheckedUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    pageTurnStyle?: StringFieldUpdateOperationsInput | string
    fontScale?: StringFieldUpdateOperationsInput | string
    highContrast?: BoolFieldUpdateOperationsInput | boolean
    ttsEnabled?: BoolFieldUpdateOperationsInput | boolean
    sttEnabled?: BoolFieldUpdateOperationsInput | boolean
    reducedMotion?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type MessageInviteUpsertWithWhereUniqueWithoutUserInput = {
    where: MessageInviteWhereUniqueInput
    update: XOR<MessageInviteUpdateWithoutUserInput, MessageInviteUncheckedUpdateWithoutUserInput>
    create: XOR<MessageInviteCreateWithoutUserInput, MessageInviteUncheckedCreateWithoutUserInput>
  }

  export type MessageInviteUpdateWithWhereUniqueWithoutUserInput = {
    where: MessageInviteWhereUniqueInput
    data: XOR<MessageInviteUpdateWithoutUserInput, MessageInviteUncheckedUpdateWithoutUserInput>
  }

  export type MessageInviteUpdateManyWithWhereWithoutUserInput = {
    where: MessageInviteScalarWhereInput
    data: XOR<MessageInviteUpdateManyMutationInput, MessageInviteUncheckedUpdateManyWithoutUserInput>
  }

  export type MessageInviteScalarWhereInput = {
    AND?: MessageInviteScalarWhereInput | MessageInviteScalarWhereInput[]
    OR?: MessageInviteScalarWhereInput[]
    NOT?: MessageInviteScalarWhereInput | MessageInviteScalarWhereInput[]
    id?: StringFilter<"MessageInvite"> | string
    userId?: StringFilter<"MessageInvite"> | string
    token?: StringFilter<"MessageInvite"> | string
    contributorName?: StringFilter<"MessageInvite"> | string
    contributorEmail?: StringNullableFilter<"MessageInvite"> | string | null
    message?: StringNullableFilter<"MessageInvite"> | string | null
    expiresAt?: DateTimeFilter<"MessageInvite"> | Date | string
    revokedAt?: DateTimeNullableFilter<"MessageInvite"> | Date | string | null
    lastUsedAt?: DateTimeNullableFilter<"MessageInvite"> | Date | string | null
    useCount?: IntFilter<"MessageInvite"> | number
    createdAt?: DateTimeFilter<"MessageInvite"> | Date | string
  }

  export type ContributionUpsertWithWhereUniqueWithoutUserInput = {
    where: ContributionWhereUniqueInput
    update: XOR<ContributionUpdateWithoutUserInput, ContributionUncheckedUpdateWithoutUserInput>
    create: XOR<ContributionCreateWithoutUserInput, ContributionUncheckedCreateWithoutUserInput>
  }

  export type ContributionUpdateWithWhereUniqueWithoutUserInput = {
    where: ContributionWhereUniqueInput
    data: XOR<ContributionUpdateWithoutUserInput, ContributionUncheckedUpdateWithoutUserInput>
  }

  export type ContributionUpdateManyWithWhereWithoutUserInput = {
    where: ContributionScalarWhereInput
    data: XOR<ContributionUpdateManyMutationInput, ContributionUncheckedUpdateManyWithoutUserInput>
  }

  export type ContributionScalarWhereInput = {
    AND?: ContributionScalarWhereInput | ContributionScalarWhereInput[]
    OR?: ContributionScalarWhereInput[]
    NOT?: ContributionScalarWhereInput | ContributionScalarWhereInput[]
    id?: StringFilter<"Contribution"> | string
    userId?: StringFilter<"Contribution"> | string
    inviteId?: StringFilter<"Contribution"> | string
    contributorName?: StringFilter<"Contribution"> | string
    contributorNote?: StringNullableFilter<"Contribution"> | string | null
    type?: StringFilter<"Contribution"> | string
    content?: StringNullableFilter<"Contribution"> | string | null
    mediaUrl?: StringNullableFilter<"Contribution"> | string | null
    mediaBlobPath?: StringNullableFilter<"Contribution"> | string | null
    viewedByUser?: BoolFilter<"Contribution"> | boolean
    importedToTimelineItemId?: StringNullableFilter<"Contribution"> | string | null
    archivedAt?: DateTimeNullableFilter<"Contribution"> | Date | string | null
    createdAt?: DateTimeFilter<"Contribution"> | Date | string
  }

  export type UserCreateWithoutContactsInput = {
    id?: string
    email: string
    name?: string | null
    plan?: string
    pendingDeathVerificationAt?: Date | string | null
    deceasedAt?: Date | string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    messages?: MessageCreateNestedManyWithoutUserInput
    arrangements?: ArrangementCreateNestedManyWithoutUserInput
    timelineItems?: TimelineItemCreateNestedManyWithoutUserInput
    vaultItems?: VaultItemCreateNestedManyWithoutUserInput
    executor?: ExecutorCreateNestedOneWithoutUserInput
    photos?: PhotoCreateNestedManyWithoutUserInput
    settings?: SettingsCreateNestedOneWithoutUserInput
    messageInvites?: MessageInviteCreateNestedManyWithoutUserInput
    contributions?: ContributionCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutContactsInput = {
    id?: string
    email: string
    name?: string | null
    plan?: string
    pendingDeathVerificationAt?: Date | string | null
    deceasedAt?: Date | string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    messages?: MessageUncheckedCreateNestedManyWithoutUserInput
    arrangements?: ArrangementUncheckedCreateNestedManyWithoutUserInput
    timelineItems?: TimelineItemUncheckedCreateNestedManyWithoutUserInput
    vaultItems?: VaultItemUncheckedCreateNestedManyWithoutUserInput
    executor?: ExecutorUncheckedCreateNestedOneWithoutUserInput
    photos?: PhotoUncheckedCreateNestedManyWithoutUserInput
    settings?: SettingsUncheckedCreateNestedOneWithoutUserInput
    messageInvites?: MessageInviteUncheckedCreateNestedManyWithoutUserInput
    contributions?: ContributionUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutContactsInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutContactsInput, UserUncheckedCreateWithoutContactsInput>
  }

  export type UserUpsertWithoutContactsInput = {
    update: XOR<UserUpdateWithoutContactsInput, UserUncheckedUpdateWithoutContactsInput>
    create: XOR<UserCreateWithoutContactsInput, UserUncheckedCreateWithoutContactsInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutContactsInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutContactsInput, UserUncheckedUpdateWithoutContactsInput>
  }

  export type UserUpdateWithoutContactsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    plan?: StringFieldUpdateOperationsInput | string
    pendingDeathVerificationAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    deceasedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    messages?: MessageUpdateManyWithoutUserNestedInput
    arrangements?: ArrangementUpdateManyWithoutUserNestedInput
    timelineItems?: TimelineItemUpdateManyWithoutUserNestedInput
    vaultItems?: VaultItemUpdateManyWithoutUserNestedInput
    executor?: ExecutorUpdateOneWithoutUserNestedInput
    photos?: PhotoUpdateManyWithoutUserNestedInput
    settings?: SettingsUpdateOneWithoutUserNestedInput
    messageInvites?: MessageInviteUpdateManyWithoutUserNestedInput
    contributions?: ContributionUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutContactsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    plan?: StringFieldUpdateOperationsInput | string
    pendingDeathVerificationAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    deceasedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    messages?: MessageUncheckedUpdateManyWithoutUserNestedInput
    arrangements?: ArrangementUncheckedUpdateManyWithoutUserNestedInput
    timelineItems?: TimelineItemUncheckedUpdateManyWithoutUserNestedInput
    vaultItems?: VaultItemUncheckedUpdateManyWithoutUserNestedInput
    executor?: ExecutorUncheckedUpdateOneWithoutUserNestedInput
    photos?: PhotoUncheckedUpdateManyWithoutUserNestedInput
    settings?: SettingsUncheckedUpdateOneWithoutUserNestedInput
    messageInvites?: MessageInviteUncheckedUpdateManyWithoutUserNestedInput
    contributions?: ContributionUncheckedUpdateManyWithoutUserNestedInput
  }

  export type UserCreateWithoutMessagesInput = {
    id?: string
    email: string
    name?: string | null
    plan?: string
    pendingDeathVerificationAt?: Date | string | null
    deceasedAt?: Date | string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    contacts?: ContactCreateNestedManyWithoutUserInput
    arrangements?: ArrangementCreateNestedManyWithoutUserInput
    timelineItems?: TimelineItemCreateNestedManyWithoutUserInput
    vaultItems?: VaultItemCreateNestedManyWithoutUserInput
    executor?: ExecutorCreateNestedOneWithoutUserInput
    photos?: PhotoCreateNestedManyWithoutUserInput
    settings?: SettingsCreateNestedOneWithoutUserInput
    messageInvites?: MessageInviteCreateNestedManyWithoutUserInput
    contributions?: ContributionCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutMessagesInput = {
    id?: string
    email: string
    name?: string | null
    plan?: string
    pendingDeathVerificationAt?: Date | string | null
    deceasedAt?: Date | string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    contacts?: ContactUncheckedCreateNestedManyWithoutUserInput
    arrangements?: ArrangementUncheckedCreateNestedManyWithoutUserInput
    timelineItems?: TimelineItemUncheckedCreateNestedManyWithoutUserInput
    vaultItems?: VaultItemUncheckedCreateNestedManyWithoutUserInput
    executor?: ExecutorUncheckedCreateNestedOneWithoutUserInput
    photos?: PhotoUncheckedCreateNestedManyWithoutUserInput
    settings?: SettingsUncheckedCreateNestedOneWithoutUserInput
    messageInvites?: MessageInviteUncheckedCreateNestedManyWithoutUserInput
    contributions?: ContributionUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutMessagesInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutMessagesInput, UserUncheckedCreateWithoutMessagesInput>
  }

  export type UserUpsertWithoutMessagesInput = {
    update: XOR<UserUpdateWithoutMessagesInput, UserUncheckedUpdateWithoutMessagesInput>
    create: XOR<UserCreateWithoutMessagesInput, UserUncheckedCreateWithoutMessagesInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutMessagesInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutMessagesInput, UserUncheckedUpdateWithoutMessagesInput>
  }

  export type UserUpdateWithoutMessagesInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    plan?: StringFieldUpdateOperationsInput | string
    pendingDeathVerificationAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    deceasedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    contacts?: ContactUpdateManyWithoutUserNestedInput
    arrangements?: ArrangementUpdateManyWithoutUserNestedInput
    timelineItems?: TimelineItemUpdateManyWithoutUserNestedInput
    vaultItems?: VaultItemUpdateManyWithoutUserNestedInput
    executor?: ExecutorUpdateOneWithoutUserNestedInput
    photos?: PhotoUpdateManyWithoutUserNestedInput
    settings?: SettingsUpdateOneWithoutUserNestedInput
    messageInvites?: MessageInviteUpdateManyWithoutUserNestedInput
    contributions?: ContributionUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutMessagesInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    plan?: StringFieldUpdateOperationsInput | string
    pendingDeathVerificationAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    deceasedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    contacts?: ContactUncheckedUpdateManyWithoutUserNestedInput
    arrangements?: ArrangementUncheckedUpdateManyWithoutUserNestedInput
    timelineItems?: TimelineItemUncheckedUpdateManyWithoutUserNestedInput
    vaultItems?: VaultItemUncheckedUpdateManyWithoutUserNestedInput
    executor?: ExecutorUncheckedUpdateOneWithoutUserNestedInput
    photos?: PhotoUncheckedUpdateManyWithoutUserNestedInput
    settings?: SettingsUncheckedUpdateOneWithoutUserNestedInput
    messageInvites?: MessageInviteUncheckedUpdateManyWithoutUserNestedInput
    contributions?: ContributionUncheckedUpdateManyWithoutUserNestedInput
  }

  export type UserCreateWithoutMessageInvitesInput = {
    id?: string
    email: string
    name?: string | null
    plan?: string
    pendingDeathVerificationAt?: Date | string | null
    deceasedAt?: Date | string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    contacts?: ContactCreateNestedManyWithoutUserInput
    messages?: MessageCreateNestedManyWithoutUserInput
    arrangements?: ArrangementCreateNestedManyWithoutUserInput
    timelineItems?: TimelineItemCreateNestedManyWithoutUserInput
    vaultItems?: VaultItemCreateNestedManyWithoutUserInput
    executor?: ExecutorCreateNestedOneWithoutUserInput
    photos?: PhotoCreateNestedManyWithoutUserInput
    settings?: SettingsCreateNestedOneWithoutUserInput
    contributions?: ContributionCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutMessageInvitesInput = {
    id?: string
    email: string
    name?: string | null
    plan?: string
    pendingDeathVerificationAt?: Date | string | null
    deceasedAt?: Date | string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    contacts?: ContactUncheckedCreateNestedManyWithoutUserInput
    messages?: MessageUncheckedCreateNestedManyWithoutUserInput
    arrangements?: ArrangementUncheckedCreateNestedManyWithoutUserInput
    timelineItems?: TimelineItemUncheckedCreateNestedManyWithoutUserInput
    vaultItems?: VaultItemUncheckedCreateNestedManyWithoutUserInput
    executor?: ExecutorUncheckedCreateNestedOneWithoutUserInput
    photos?: PhotoUncheckedCreateNestedManyWithoutUserInput
    settings?: SettingsUncheckedCreateNestedOneWithoutUserInput
    contributions?: ContributionUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutMessageInvitesInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutMessageInvitesInput, UserUncheckedCreateWithoutMessageInvitesInput>
  }

  export type ContributionCreateWithoutInviteInput = {
    id?: string
    contributorName: string
    contributorNote?: string | null
    type: string
    content?: string | null
    mediaUrl?: string | null
    mediaBlobPath?: string | null
    viewedByUser?: boolean
    importedToTimelineItemId?: string | null
    archivedAt?: Date | string | null
    createdAt?: Date | string
    user: UserCreateNestedOneWithoutContributionsInput
  }

  export type ContributionUncheckedCreateWithoutInviteInput = {
    id?: string
    userId: string
    contributorName: string
    contributorNote?: string | null
    type: string
    content?: string | null
    mediaUrl?: string | null
    mediaBlobPath?: string | null
    viewedByUser?: boolean
    importedToTimelineItemId?: string | null
    archivedAt?: Date | string | null
    createdAt?: Date | string
  }

  export type ContributionCreateOrConnectWithoutInviteInput = {
    where: ContributionWhereUniqueInput
    create: XOR<ContributionCreateWithoutInviteInput, ContributionUncheckedCreateWithoutInviteInput>
  }

  export type ContributionCreateManyInviteInputEnvelope = {
    data: ContributionCreateManyInviteInput | ContributionCreateManyInviteInput[]
    skipDuplicates?: boolean
  }

  export type UserUpsertWithoutMessageInvitesInput = {
    update: XOR<UserUpdateWithoutMessageInvitesInput, UserUncheckedUpdateWithoutMessageInvitesInput>
    create: XOR<UserCreateWithoutMessageInvitesInput, UserUncheckedCreateWithoutMessageInvitesInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutMessageInvitesInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutMessageInvitesInput, UserUncheckedUpdateWithoutMessageInvitesInput>
  }

  export type UserUpdateWithoutMessageInvitesInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    plan?: StringFieldUpdateOperationsInput | string
    pendingDeathVerificationAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    deceasedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    contacts?: ContactUpdateManyWithoutUserNestedInput
    messages?: MessageUpdateManyWithoutUserNestedInput
    arrangements?: ArrangementUpdateManyWithoutUserNestedInput
    timelineItems?: TimelineItemUpdateManyWithoutUserNestedInput
    vaultItems?: VaultItemUpdateManyWithoutUserNestedInput
    executor?: ExecutorUpdateOneWithoutUserNestedInput
    photos?: PhotoUpdateManyWithoutUserNestedInput
    settings?: SettingsUpdateOneWithoutUserNestedInput
    contributions?: ContributionUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutMessageInvitesInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    plan?: StringFieldUpdateOperationsInput | string
    pendingDeathVerificationAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    deceasedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    contacts?: ContactUncheckedUpdateManyWithoutUserNestedInput
    messages?: MessageUncheckedUpdateManyWithoutUserNestedInput
    arrangements?: ArrangementUncheckedUpdateManyWithoutUserNestedInput
    timelineItems?: TimelineItemUncheckedUpdateManyWithoutUserNestedInput
    vaultItems?: VaultItemUncheckedUpdateManyWithoutUserNestedInput
    executor?: ExecutorUncheckedUpdateOneWithoutUserNestedInput
    photos?: PhotoUncheckedUpdateManyWithoutUserNestedInput
    settings?: SettingsUncheckedUpdateOneWithoutUserNestedInput
    contributions?: ContributionUncheckedUpdateManyWithoutUserNestedInput
  }

  export type ContributionUpsertWithWhereUniqueWithoutInviteInput = {
    where: ContributionWhereUniqueInput
    update: XOR<ContributionUpdateWithoutInviteInput, ContributionUncheckedUpdateWithoutInviteInput>
    create: XOR<ContributionCreateWithoutInviteInput, ContributionUncheckedCreateWithoutInviteInput>
  }

  export type ContributionUpdateWithWhereUniqueWithoutInviteInput = {
    where: ContributionWhereUniqueInput
    data: XOR<ContributionUpdateWithoutInviteInput, ContributionUncheckedUpdateWithoutInviteInput>
  }

  export type ContributionUpdateManyWithWhereWithoutInviteInput = {
    where: ContributionScalarWhereInput
    data: XOR<ContributionUpdateManyMutationInput, ContributionUncheckedUpdateManyWithoutInviteInput>
  }

  export type UserCreateWithoutContributionsInput = {
    id?: string
    email: string
    name?: string | null
    plan?: string
    pendingDeathVerificationAt?: Date | string | null
    deceasedAt?: Date | string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    contacts?: ContactCreateNestedManyWithoutUserInput
    messages?: MessageCreateNestedManyWithoutUserInput
    arrangements?: ArrangementCreateNestedManyWithoutUserInput
    timelineItems?: TimelineItemCreateNestedManyWithoutUserInput
    vaultItems?: VaultItemCreateNestedManyWithoutUserInput
    executor?: ExecutorCreateNestedOneWithoutUserInput
    photos?: PhotoCreateNestedManyWithoutUserInput
    settings?: SettingsCreateNestedOneWithoutUserInput
    messageInvites?: MessageInviteCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutContributionsInput = {
    id?: string
    email: string
    name?: string | null
    plan?: string
    pendingDeathVerificationAt?: Date | string | null
    deceasedAt?: Date | string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    contacts?: ContactUncheckedCreateNestedManyWithoutUserInput
    messages?: MessageUncheckedCreateNestedManyWithoutUserInput
    arrangements?: ArrangementUncheckedCreateNestedManyWithoutUserInput
    timelineItems?: TimelineItemUncheckedCreateNestedManyWithoutUserInput
    vaultItems?: VaultItemUncheckedCreateNestedManyWithoutUserInput
    executor?: ExecutorUncheckedCreateNestedOneWithoutUserInput
    photos?: PhotoUncheckedCreateNestedManyWithoutUserInput
    settings?: SettingsUncheckedCreateNestedOneWithoutUserInput
    messageInvites?: MessageInviteUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutContributionsInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutContributionsInput, UserUncheckedCreateWithoutContributionsInput>
  }

  export type MessageInviteCreateWithoutContributionsInput = {
    id?: string
    token: string
    contributorName: string
    contributorEmail?: string | null
    message?: string | null
    expiresAt: Date | string
    revokedAt?: Date | string | null
    lastUsedAt?: Date | string | null
    useCount?: number
    createdAt?: Date | string
    user: UserCreateNestedOneWithoutMessageInvitesInput
  }

  export type MessageInviteUncheckedCreateWithoutContributionsInput = {
    id?: string
    userId: string
    token: string
    contributorName: string
    contributorEmail?: string | null
    message?: string | null
    expiresAt: Date | string
    revokedAt?: Date | string | null
    lastUsedAt?: Date | string | null
    useCount?: number
    createdAt?: Date | string
  }

  export type MessageInviteCreateOrConnectWithoutContributionsInput = {
    where: MessageInviteWhereUniqueInput
    create: XOR<MessageInviteCreateWithoutContributionsInput, MessageInviteUncheckedCreateWithoutContributionsInput>
  }

  export type UserUpsertWithoutContributionsInput = {
    update: XOR<UserUpdateWithoutContributionsInput, UserUncheckedUpdateWithoutContributionsInput>
    create: XOR<UserCreateWithoutContributionsInput, UserUncheckedCreateWithoutContributionsInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutContributionsInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutContributionsInput, UserUncheckedUpdateWithoutContributionsInput>
  }

  export type UserUpdateWithoutContributionsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    plan?: StringFieldUpdateOperationsInput | string
    pendingDeathVerificationAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    deceasedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    contacts?: ContactUpdateManyWithoutUserNestedInput
    messages?: MessageUpdateManyWithoutUserNestedInput
    arrangements?: ArrangementUpdateManyWithoutUserNestedInput
    timelineItems?: TimelineItemUpdateManyWithoutUserNestedInput
    vaultItems?: VaultItemUpdateManyWithoutUserNestedInput
    executor?: ExecutorUpdateOneWithoutUserNestedInput
    photos?: PhotoUpdateManyWithoutUserNestedInput
    settings?: SettingsUpdateOneWithoutUserNestedInput
    messageInvites?: MessageInviteUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutContributionsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    plan?: StringFieldUpdateOperationsInput | string
    pendingDeathVerificationAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    deceasedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    contacts?: ContactUncheckedUpdateManyWithoutUserNestedInput
    messages?: MessageUncheckedUpdateManyWithoutUserNestedInput
    arrangements?: ArrangementUncheckedUpdateManyWithoutUserNestedInput
    timelineItems?: TimelineItemUncheckedUpdateManyWithoutUserNestedInput
    vaultItems?: VaultItemUncheckedUpdateManyWithoutUserNestedInput
    executor?: ExecutorUncheckedUpdateOneWithoutUserNestedInput
    photos?: PhotoUncheckedUpdateManyWithoutUserNestedInput
    settings?: SettingsUncheckedUpdateOneWithoutUserNestedInput
    messageInvites?: MessageInviteUncheckedUpdateManyWithoutUserNestedInput
  }

  export type MessageInviteUpsertWithoutContributionsInput = {
    update: XOR<MessageInviteUpdateWithoutContributionsInput, MessageInviteUncheckedUpdateWithoutContributionsInput>
    create: XOR<MessageInviteCreateWithoutContributionsInput, MessageInviteUncheckedCreateWithoutContributionsInput>
    where?: MessageInviteWhereInput
  }

  export type MessageInviteUpdateToOneWithWhereWithoutContributionsInput = {
    where?: MessageInviteWhereInput
    data: XOR<MessageInviteUpdateWithoutContributionsInput, MessageInviteUncheckedUpdateWithoutContributionsInput>
  }

  export type MessageInviteUpdateWithoutContributionsInput = {
    id?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    contributorName?: StringFieldUpdateOperationsInput | string
    contributorEmail?: NullableStringFieldUpdateOperationsInput | string | null
    message?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: DateTimeFieldUpdateOperationsInput | Date | string
    revokedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    lastUsedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    useCount?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutMessageInvitesNestedInput
  }

  export type MessageInviteUncheckedUpdateWithoutContributionsInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    contributorName?: StringFieldUpdateOperationsInput | string
    contributorEmail?: NullableStringFieldUpdateOperationsInput | string | null
    message?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: DateTimeFieldUpdateOperationsInput | Date | string
    revokedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    lastUsedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    useCount?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type UserCreateWithoutTimelineItemsInput = {
    id?: string
    email: string
    name?: string | null
    plan?: string
    pendingDeathVerificationAt?: Date | string | null
    deceasedAt?: Date | string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    contacts?: ContactCreateNestedManyWithoutUserInput
    messages?: MessageCreateNestedManyWithoutUserInput
    arrangements?: ArrangementCreateNestedManyWithoutUserInput
    vaultItems?: VaultItemCreateNestedManyWithoutUserInput
    executor?: ExecutorCreateNestedOneWithoutUserInput
    photos?: PhotoCreateNestedManyWithoutUserInput
    settings?: SettingsCreateNestedOneWithoutUserInput
    messageInvites?: MessageInviteCreateNestedManyWithoutUserInput
    contributions?: ContributionCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutTimelineItemsInput = {
    id?: string
    email: string
    name?: string | null
    plan?: string
    pendingDeathVerificationAt?: Date | string | null
    deceasedAt?: Date | string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    contacts?: ContactUncheckedCreateNestedManyWithoutUserInput
    messages?: MessageUncheckedCreateNestedManyWithoutUserInput
    arrangements?: ArrangementUncheckedCreateNestedManyWithoutUserInput
    vaultItems?: VaultItemUncheckedCreateNestedManyWithoutUserInput
    executor?: ExecutorUncheckedCreateNestedOneWithoutUserInput
    photos?: PhotoUncheckedCreateNestedManyWithoutUserInput
    settings?: SettingsUncheckedCreateNestedOneWithoutUserInput
    messageInvites?: MessageInviteUncheckedCreateNestedManyWithoutUserInput
    contributions?: ContributionUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutTimelineItemsInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutTimelineItemsInput, UserUncheckedCreateWithoutTimelineItemsInput>
  }

  export type PhotoCreateWithoutTimelineItemInput = {
    id?: string
    url: string
    thumbnailUrl?: string | null
    blobPath: string
    caption?: string | null
    width?: number | null
    height?: number | null
    sizeBytes?: number | null
    order?: number
    createdAt?: Date | string
    user: UserCreateNestedOneWithoutPhotosInput
  }

  export type PhotoUncheckedCreateWithoutTimelineItemInput = {
    id?: string
    userId: string
    url: string
    thumbnailUrl?: string | null
    blobPath: string
    caption?: string | null
    width?: number | null
    height?: number | null
    sizeBytes?: number | null
    order?: number
    createdAt?: Date | string
  }

  export type PhotoCreateOrConnectWithoutTimelineItemInput = {
    where: PhotoWhereUniqueInput
    create: XOR<PhotoCreateWithoutTimelineItemInput, PhotoUncheckedCreateWithoutTimelineItemInput>
  }

  export type PhotoCreateManyTimelineItemInputEnvelope = {
    data: PhotoCreateManyTimelineItemInput | PhotoCreateManyTimelineItemInput[]
    skipDuplicates?: boolean
  }

  export type UserUpsertWithoutTimelineItemsInput = {
    update: XOR<UserUpdateWithoutTimelineItemsInput, UserUncheckedUpdateWithoutTimelineItemsInput>
    create: XOR<UserCreateWithoutTimelineItemsInput, UserUncheckedCreateWithoutTimelineItemsInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutTimelineItemsInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutTimelineItemsInput, UserUncheckedUpdateWithoutTimelineItemsInput>
  }

  export type UserUpdateWithoutTimelineItemsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    plan?: StringFieldUpdateOperationsInput | string
    pendingDeathVerificationAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    deceasedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    contacts?: ContactUpdateManyWithoutUserNestedInput
    messages?: MessageUpdateManyWithoutUserNestedInput
    arrangements?: ArrangementUpdateManyWithoutUserNestedInput
    vaultItems?: VaultItemUpdateManyWithoutUserNestedInput
    executor?: ExecutorUpdateOneWithoutUserNestedInput
    photos?: PhotoUpdateManyWithoutUserNestedInput
    settings?: SettingsUpdateOneWithoutUserNestedInput
    messageInvites?: MessageInviteUpdateManyWithoutUserNestedInput
    contributions?: ContributionUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutTimelineItemsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    plan?: StringFieldUpdateOperationsInput | string
    pendingDeathVerificationAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    deceasedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    contacts?: ContactUncheckedUpdateManyWithoutUserNestedInput
    messages?: MessageUncheckedUpdateManyWithoutUserNestedInput
    arrangements?: ArrangementUncheckedUpdateManyWithoutUserNestedInput
    vaultItems?: VaultItemUncheckedUpdateManyWithoutUserNestedInput
    executor?: ExecutorUncheckedUpdateOneWithoutUserNestedInput
    photos?: PhotoUncheckedUpdateManyWithoutUserNestedInput
    settings?: SettingsUncheckedUpdateOneWithoutUserNestedInput
    messageInvites?: MessageInviteUncheckedUpdateManyWithoutUserNestedInput
    contributions?: ContributionUncheckedUpdateManyWithoutUserNestedInput
  }

  export type PhotoUpsertWithWhereUniqueWithoutTimelineItemInput = {
    where: PhotoWhereUniqueInput
    update: XOR<PhotoUpdateWithoutTimelineItemInput, PhotoUncheckedUpdateWithoutTimelineItemInput>
    create: XOR<PhotoCreateWithoutTimelineItemInput, PhotoUncheckedCreateWithoutTimelineItemInput>
  }

  export type PhotoUpdateWithWhereUniqueWithoutTimelineItemInput = {
    where: PhotoWhereUniqueInput
    data: XOR<PhotoUpdateWithoutTimelineItemInput, PhotoUncheckedUpdateWithoutTimelineItemInput>
  }

  export type PhotoUpdateManyWithWhereWithoutTimelineItemInput = {
    where: PhotoScalarWhereInput
    data: XOR<PhotoUpdateManyMutationInput, PhotoUncheckedUpdateManyWithoutTimelineItemInput>
  }

  export type UserCreateWithoutPhotosInput = {
    id?: string
    email: string
    name?: string | null
    plan?: string
    pendingDeathVerificationAt?: Date | string | null
    deceasedAt?: Date | string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    contacts?: ContactCreateNestedManyWithoutUserInput
    messages?: MessageCreateNestedManyWithoutUserInput
    arrangements?: ArrangementCreateNestedManyWithoutUserInput
    timelineItems?: TimelineItemCreateNestedManyWithoutUserInput
    vaultItems?: VaultItemCreateNestedManyWithoutUserInput
    executor?: ExecutorCreateNestedOneWithoutUserInput
    settings?: SettingsCreateNestedOneWithoutUserInput
    messageInvites?: MessageInviteCreateNestedManyWithoutUserInput
    contributions?: ContributionCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutPhotosInput = {
    id?: string
    email: string
    name?: string | null
    plan?: string
    pendingDeathVerificationAt?: Date | string | null
    deceasedAt?: Date | string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    contacts?: ContactUncheckedCreateNestedManyWithoutUserInput
    messages?: MessageUncheckedCreateNestedManyWithoutUserInput
    arrangements?: ArrangementUncheckedCreateNestedManyWithoutUserInput
    timelineItems?: TimelineItemUncheckedCreateNestedManyWithoutUserInput
    vaultItems?: VaultItemUncheckedCreateNestedManyWithoutUserInput
    executor?: ExecutorUncheckedCreateNestedOneWithoutUserInput
    settings?: SettingsUncheckedCreateNestedOneWithoutUserInput
    messageInvites?: MessageInviteUncheckedCreateNestedManyWithoutUserInput
    contributions?: ContributionUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutPhotosInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutPhotosInput, UserUncheckedCreateWithoutPhotosInput>
  }

  export type TimelineItemCreateWithoutPhotosInput = {
    id?: string
    date: Date | string
    title: string
    story?: string | null
    mediaUrl?: string | null
    createdAt?: Date | string
    user: UserCreateNestedOneWithoutTimelineItemsInput
  }

  export type TimelineItemUncheckedCreateWithoutPhotosInput = {
    id?: string
    userId: string
    date: Date | string
    title: string
    story?: string | null
    mediaUrl?: string | null
    createdAt?: Date | string
  }

  export type TimelineItemCreateOrConnectWithoutPhotosInput = {
    where: TimelineItemWhereUniqueInput
    create: XOR<TimelineItemCreateWithoutPhotosInput, TimelineItemUncheckedCreateWithoutPhotosInput>
  }

  export type UserUpsertWithoutPhotosInput = {
    update: XOR<UserUpdateWithoutPhotosInput, UserUncheckedUpdateWithoutPhotosInput>
    create: XOR<UserCreateWithoutPhotosInput, UserUncheckedCreateWithoutPhotosInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutPhotosInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutPhotosInput, UserUncheckedUpdateWithoutPhotosInput>
  }

  export type UserUpdateWithoutPhotosInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    plan?: StringFieldUpdateOperationsInput | string
    pendingDeathVerificationAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    deceasedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    contacts?: ContactUpdateManyWithoutUserNestedInput
    messages?: MessageUpdateManyWithoutUserNestedInput
    arrangements?: ArrangementUpdateManyWithoutUserNestedInput
    timelineItems?: TimelineItemUpdateManyWithoutUserNestedInput
    vaultItems?: VaultItemUpdateManyWithoutUserNestedInput
    executor?: ExecutorUpdateOneWithoutUserNestedInput
    settings?: SettingsUpdateOneWithoutUserNestedInput
    messageInvites?: MessageInviteUpdateManyWithoutUserNestedInput
    contributions?: ContributionUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutPhotosInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    plan?: StringFieldUpdateOperationsInput | string
    pendingDeathVerificationAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    deceasedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    contacts?: ContactUncheckedUpdateManyWithoutUserNestedInput
    messages?: MessageUncheckedUpdateManyWithoutUserNestedInput
    arrangements?: ArrangementUncheckedUpdateManyWithoutUserNestedInput
    timelineItems?: TimelineItemUncheckedUpdateManyWithoutUserNestedInput
    vaultItems?: VaultItemUncheckedUpdateManyWithoutUserNestedInput
    executor?: ExecutorUncheckedUpdateOneWithoutUserNestedInput
    settings?: SettingsUncheckedUpdateOneWithoutUserNestedInput
    messageInvites?: MessageInviteUncheckedUpdateManyWithoutUserNestedInput
    contributions?: ContributionUncheckedUpdateManyWithoutUserNestedInput
  }

  export type TimelineItemUpsertWithoutPhotosInput = {
    update: XOR<TimelineItemUpdateWithoutPhotosInput, TimelineItemUncheckedUpdateWithoutPhotosInput>
    create: XOR<TimelineItemCreateWithoutPhotosInput, TimelineItemUncheckedCreateWithoutPhotosInput>
    where?: TimelineItemWhereInput
  }

  export type TimelineItemUpdateToOneWithWhereWithoutPhotosInput = {
    where?: TimelineItemWhereInput
    data: XOR<TimelineItemUpdateWithoutPhotosInput, TimelineItemUncheckedUpdateWithoutPhotosInput>
  }

  export type TimelineItemUpdateWithoutPhotosInput = {
    id?: StringFieldUpdateOperationsInput | string
    date?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    story?: NullableStringFieldUpdateOperationsInput | string | null
    mediaUrl?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutTimelineItemsNestedInput
  }

  export type TimelineItemUncheckedUpdateWithoutPhotosInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    date?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    story?: NullableStringFieldUpdateOperationsInput | string | null
    mediaUrl?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type UserCreateWithoutArrangementsInput = {
    id?: string
    email: string
    name?: string | null
    plan?: string
    pendingDeathVerificationAt?: Date | string | null
    deceasedAt?: Date | string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    contacts?: ContactCreateNestedManyWithoutUserInput
    messages?: MessageCreateNestedManyWithoutUserInput
    timelineItems?: TimelineItemCreateNestedManyWithoutUserInput
    vaultItems?: VaultItemCreateNestedManyWithoutUserInput
    executor?: ExecutorCreateNestedOneWithoutUserInput
    photos?: PhotoCreateNestedManyWithoutUserInput
    settings?: SettingsCreateNestedOneWithoutUserInput
    messageInvites?: MessageInviteCreateNestedManyWithoutUserInput
    contributions?: ContributionCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutArrangementsInput = {
    id?: string
    email: string
    name?: string | null
    plan?: string
    pendingDeathVerificationAt?: Date | string | null
    deceasedAt?: Date | string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    contacts?: ContactUncheckedCreateNestedManyWithoutUserInput
    messages?: MessageUncheckedCreateNestedManyWithoutUserInput
    timelineItems?: TimelineItemUncheckedCreateNestedManyWithoutUserInput
    vaultItems?: VaultItemUncheckedCreateNestedManyWithoutUserInput
    executor?: ExecutorUncheckedCreateNestedOneWithoutUserInput
    photos?: PhotoUncheckedCreateNestedManyWithoutUserInput
    settings?: SettingsUncheckedCreateNestedOneWithoutUserInput
    messageInvites?: MessageInviteUncheckedCreateNestedManyWithoutUserInput
    contributions?: ContributionUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutArrangementsInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutArrangementsInput, UserUncheckedCreateWithoutArrangementsInput>
  }

  export type UserUpsertWithoutArrangementsInput = {
    update: XOR<UserUpdateWithoutArrangementsInput, UserUncheckedUpdateWithoutArrangementsInput>
    create: XOR<UserCreateWithoutArrangementsInput, UserUncheckedCreateWithoutArrangementsInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutArrangementsInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutArrangementsInput, UserUncheckedUpdateWithoutArrangementsInput>
  }

  export type UserUpdateWithoutArrangementsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    plan?: StringFieldUpdateOperationsInput | string
    pendingDeathVerificationAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    deceasedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    contacts?: ContactUpdateManyWithoutUserNestedInput
    messages?: MessageUpdateManyWithoutUserNestedInput
    timelineItems?: TimelineItemUpdateManyWithoutUserNestedInput
    vaultItems?: VaultItemUpdateManyWithoutUserNestedInput
    executor?: ExecutorUpdateOneWithoutUserNestedInput
    photos?: PhotoUpdateManyWithoutUserNestedInput
    settings?: SettingsUpdateOneWithoutUserNestedInput
    messageInvites?: MessageInviteUpdateManyWithoutUserNestedInput
    contributions?: ContributionUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutArrangementsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    plan?: StringFieldUpdateOperationsInput | string
    pendingDeathVerificationAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    deceasedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    contacts?: ContactUncheckedUpdateManyWithoutUserNestedInput
    messages?: MessageUncheckedUpdateManyWithoutUserNestedInput
    timelineItems?: TimelineItemUncheckedUpdateManyWithoutUserNestedInput
    vaultItems?: VaultItemUncheckedUpdateManyWithoutUserNestedInput
    executor?: ExecutorUncheckedUpdateOneWithoutUserNestedInput
    photos?: PhotoUncheckedUpdateManyWithoutUserNestedInput
    settings?: SettingsUncheckedUpdateOneWithoutUserNestedInput
    messageInvites?: MessageInviteUncheckedUpdateManyWithoutUserNestedInput
    contributions?: ContributionUncheckedUpdateManyWithoutUserNestedInput
  }

  export type UserCreateWithoutVaultItemsInput = {
    id?: string
    email: string
    name?: string | null
    plan?: string
    pendingDeathVerificationAt?: Date | string | null
    deceasedAt?: Date | string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    contacts?: ContactCreateNestedManyWithoutUserInput
    messages?: MessageCreateNestedManyWithoutUserInput
    arrangements?: ArrangementCreateNestedManyWithoutUserInput
    timelineItems?: TimelineItemCreateNestedManyWithoutUserInput
    executor?: ExecutorCreateNestedOneWithoutUserInput
    photos?: PhotoCreateNestedManyWithoutUserInput
    settings?: SettingsCreateNestedOneWithoutUserInput
    messageInvites?: MessageInviteCreateNestedManyWithoutUserInput
    contributions?: ContributionCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutVaultItemsInput = {
    id?: string
    email: string
    name?: string | null
    plan?: string
    pendingDeathVerificationAt?: Date | string | null
    deceasedAt?: Date | string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    contacts?: ContactUncheckedCreateNestedManyWithoutUserInput
    messages?: MessageUncheckedCreateNestedManyWithoutUserInput
    arrangements?: ArrangementUncheckedCreateNestedManyWithoutUserInput
    timelineItems?: TimelineItemUncheckedCreateNestedManyWithoutUserInput
    executor?: ExecutorUncheckedCreateNestedOneWithoutUserInput
    photos?: PhotoUncheckedCreateNestedManyWithoutUserInput
    settings?: SettingsUncheckedCreateNestedOneWithoutUserInput
    messageInvites?: MessageInviteUncheckedCreateNestedManyWithoutUserInput
    contributions?: ContributionUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutVaultItemsInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutVaultItemsInput, UserUncheckedCreateWithoutVaultItemsInput>
  }

  export type UserUpsertWithoutVaultItemsInput = {
    update: XOR<UserUpdateWithoutVaultItemsInput, UserUncheckedUpdateWithoutVaultItemsInput>
    create: XOR<UserCreateWithoutVaultItemsInput, UserUncheckedCreateWithoutVaultItemsInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutVaultItemsInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutVaultItemsInput, UserUncheckedUpdateWithoutVaultItemsInput>
  }

  export type UserUpdateWithoutVaultItemsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    plan?: StringFieldUpdateOperationsInput | string
    pendingDeathVerificationAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    deceasedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    contacts?: ContactUpdateManyWithoutUserNestedInput
    messages?: MessageUpdateManyWithoutUserNestedInput
    arrangements?: ArrangementUpdateManyWithoutUserNestedInput
    timelineItems?: TimelineItemUpdateManyWithoutUserNestedInput
    executor?: ExecutorUpdateOneWithoutUserNestedInput
    photos?: PhotoUpdateManyWithoutUserNestedInput
    settings?: SettingsUpdateOneWithoutUserNestedInput
    messageInvites?: MessageInviteUpdateManyWithoutUserNestedInput
    contributions?: ContributionUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutVaultItemsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    plan?: StringFieldUpdateOperationsInput | string
    pendingDeathVerificationAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    deceasedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    contacts?: ContactUncheckedUpdateManyWithoutUserNestedInput
    messages?: MessageUncheckedUpdateManyWithoutUserNestedInput
    arrangements?: ArrangementUncheckedUpdateManyWithoutUserNestedInput
    timelineItems?: TimelineItemUncheckedUpdateManyWithoutUserNestedInput
    executor?: ExecutorUncheckedUpdateOneWithoutUserNestedInput
    photos?: PhotoUncheckedUpdateManyWithoutUserNestedInput
    settings?: SettingsUncheckedUpdateOneWithoutUserNestedInput
    messageInvites?: MessageInviteUncheckedUpdateManyWithoutUserNestedInput
    contributions?: ContributionUncheckedUpdateManyWithoutUserNestedInput
  }

  export type UserCreateWithoutExecutorInput = {
    id?: string
    email: string
    name?: string | null
    plan?: string
    pendingDeathVerificationAt?: Date | string | null
    deceasedAt?: Date | string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    contacts?: ContactCreateNestedManyWithoutUserInput
    messages?: MessageCreateNestedManyWithoutUserInput
    arrangements?: ArrangementCreateNestedManyWithoutUserInput
    timelineItems?: TimelineItemCreateNestedManyWithoutUserInput
    vaultItems?: VaultItemCreateNestedManyWithoutUserInput
    photos?: PhotoCreateNestedManyWithoutUserInput
    settings?: SettingsCreateNestedOneWithoutUserInput
    messageInvites?: MessageInviteCreateNestedManyWithoutUserInput
    contributions?: ContributionCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutExecutorInput = {
    id?: string
    email: string
    name?: string | null
    plan?: string
    pendingDeathVerificationAt?: Date | string | null
    deceasedAt?: Date | string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    contacts?: ContactUncheckedCreateNestedManyWithoutUserInput
    messages?: MessageUncheckedCreateNestedManyWithoutUserInput
    arrangements?: ArrangementUncheckedCreateNestedManyWithoutUserInput
    timelineItems?: TimelineItemUncheckedCreateNestedManyWithoutUserInput
    vaultItems?: VaultItemUncheckedCreateNestedManyWithoutUserInput
    photos?: PhotoUncheckedCreateNestedManyWithoutUserInput
    settings?: SettingsUncheckedCreateNestedOneWithoutUserInput
    messageInvites?: MessageInviteUncheckedCreateNestedManyWithoutUserInput
    contributions?: ContributionUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutExecutorInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutExecutorInput, UserUncheckedCreateWithoutExecutorInput>
  }

  export type UserUpsertWithoutExecutorInput = {
    update: XOR<UserUpdateWithoutExecutorInput, UserUncheckedUpdateWithoutExecutorInput>
    create: XOR<UserCreateWithoutExecutorInput, UserUncheckedCreateWithoutExecutorInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutExecutorInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutExecutorInput, UserUncheckedUpdateWithoutExecutorInput>
  }

  export type UserUpdateWithoutExecutorInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    plan?: StringFieldUpdateOperationsInput | string
    pendingDeathVerificationAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    deceasedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    contacts?: ContactUpdateManyWithoutUserNestedInput
    messages?: MessageUpdateManyWithoutUserNestedInput
    arrangements?: ArrangementUpdateManyWithoutUserNestedInput
    timelineItems?: TimelineItemUpdateManyWithoutUserNestedInput
    vaultItems?: VaultItemUpdateManyWithoutUserNestedInput
    photos?: PhotoUpdateManyWithoutUserNestedInput
    settings?: SettingsUpdateOneWithoutUserNestedInput
    messageInvites?: MessageInviteUpdateManyWithoutUserNestedInput
    contributions?: ContributionUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutExecutorInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    plan?: StringFieldUpdateOperationsInput | string
    pendingDeathVerificationAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    deceasedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    contacts?: ContactUncheckedUpdateManyWithoutUserNestedInput
    messages?: MessageUncheckedUpdateManyWithoutUserNestedInput
    arrangements?: ArrangementUncheckedUpdateManyWithoutUserNestedInput
    timelineItems?: TimelineItemUncheckedUpdateManyWithoutUserNestedInput
    vaultItems?: VaultItemUncheckedUpdateManyWithoutUserNestedInput
    photos?: PhotoUncheckedUpdateManyWithoutUserNestedInput
    settings?: SettingsUncheckedUpdateOneWithoutUserNestedInput
    messageInvites?: MessageInviteUncheckedUpdateManyWithoutUserNestedInput
    contributions?: ContributionUncheckedUpdateManyWithoutUserNestedInput
  }

  export type UserCreateWithoutSettingsInput = {
    id?: string
    email: string
    name?: string | null
    plan?: string
    pendingDeathVerificationAt?: Date | string | null
    deceasedAt?: Date | string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    contacts?: ContactCreateNestedManyWithoutUserInput
    messages?: MessageCreateNestedManyWithoutUserInput
    arrangements?: ArrangementCreateNestedManyWithoutUserInput
    timelineItems?: TimelineItemCreateNestedManyWithoutUserInput
    vaultItems?: VaultItemCreateNestedManyWithoutUserInput
    executor?: ExecutorCreateNestedOneWithoutUserInput
    photos?: PhotoCreateNestedManyWithoutUserInput
    messageInvites?: MessageInviteCreateNestedManyWithoutUserInput
    contributions?: ContributionCreateNestedManyWithoutUserInput
  }

  export type UserUncheckedCreateWithoutSettingsInput = {
    id?: string
    email: string
    name?: string | null
    plan?: string
    pendingDeathVerificationAt?: Date | string | null
    deceasedAt?: Date | string | null
    createdAt?: Date | string
    updatedAt?: Date | string
    contacts?: ContactUncheckedCreateNestedManyWithoutUserInput
    messages?: MessageUncheckedCreateNestedManyWithoutUserInput
    arrangements?: ArrangementUncheckedCreateNestedManyWithoutUserInput
    timelineItems?: TimelineItemUncheckedCreateNestedManyWithoutUserInput
    vaultItems?: VaultItemUncheckedCreateNestedManyWithoutUserInput
    executor?: ExecutorUncheckedCreateNestedOneWithoutUserInput
    photos?: PhotoUncheckedCreateNestedManyWithoutUserInput
    messageInvites?: MessageInviteUncheckedCreateNestedManyWithoutUserInput
    contributions?: ContributionUncheckedCreateNestedManyWithoutUserInput
  }

  export type UserCreateOrConnectWithoutSettingsInput = {
    where: UserWhereUniqueInput
    create: XOR<UserCreateWithoutSettingsInput, UserUncheckedCreateWithoutSettingsInput>
  }

  export type UserUpsertWithoutSettingsInput = {
    update: XOR<UserUpdateWithoutSettingsInput, UserUncheckedUpdateWithoutSettingsInput>
    create: XOR<UserCreateWithoutSettingsInput, UserUncheckedCreateWithoutSettingsInput>
    where?: UserWhereInput
  }

  export type UserUpdateToOneWithWhereWithoutSettingsInput = {
    where?: UserWhereInput
    data: XOR<UserUpdateWithoutSettingsInput, UserUncheckedUpdateWithoutSettingsInput>
  }

  export type UserUpdateWithoutSettingsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    plan?: StringFieldUpdateOperationsInput | string
    pendingDeathVerificationAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    deceasedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    contacts?: ContactUpdateManyWithoutUserNestedInput
    messages?: MessageUpdateManyWithoutUserNestedInput
    arrangements?: ArrangementUpdateManyWithoutUserNestedInput
    timelineItems?: TimelineItemUpdateManyWithoutUserNestedInput
    vaultItems?: VaultItemUpdateManyWithoutUserNestedInput
    executor?: ExecutorUpdateOneWithoutUserNestedInput
    photos?: PhotoUpdateManyWithoutUserNestedInput
    messageInvites?: MessageInviteUpdateManyWithoutUserNestedInput
    contributions?: ContributionUpdateManyWithoutUserNestedInput
  }

  export type UserUncheckedUpdateWithoutSettingsInput = {
    id?: StringFieldUpdateOperationsInput | string
    email?: StringFieldUpdateOperationsInput | string
    name?: NullableStringFieldUpdateOperationsInput | string | null
    plan?: StringFieldUpdateOperationsInput | string
    pendingDeathVerificationAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    deceasedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
    contacts?: ContactUncheckedUpdateManyWithoutUserNestedInput
    messages?: MessageUncheckedUpdateManyWithoutUserNestedInput
    arrangements?: ArrangementUncheckedUpdateManyWithoutUserNestedInput
    timelineItems?: TimelineItemUncheckedUpdateManyWithoutUserNestedInput
    vaultItems?: VaultItemUncheckedUpdateManyWithoutUserNestedInput
    executor?: ExecutorUncheckedUpdateOneWithoutUserNestedInput
    photos?: PhotoUncheckedUpdateManyWithoutUserNestedInput
    messageInvites?: MessageInviteUncheckedUpdateManyWithoutUserNestedInput
    contributions?: ContributionUncheckedUpdateManyWithoutUserNestedInput
  }

  export type ContactCreateManyUserInput = {
    id?: string
    name: string
    email?: string | null
    phone?: string | null
    relationship?: string | null
    isExecutor?: boolean
    isBackup?: boolean
    createdAt?: Date | string
  }

  export type MessageCreateManyUserInput = {
    id?: string
    recipientName: string
    recipientEmail?: string | null
    type?: string
    subject?: string | null
    content?: string | null
    mediaUrl?: string | null
    mediaBlobPath?: string | null
    mediaDurationSec?: number | null
    triggerDate?: Date | string | null
    state?: string
    approvalPromptedAt?: Date | string | null
    approvalExpiresAt?: Date | string | null
    sentAt?: Date | string | null
    archivedAt?: Date | string | null
    deliveryToken?: string | null
    approvalToken?: string | null
    approvalRemindersSent?: number
    createdAt?: Date | string
    updatedAt?: Date | string
  }

  export type ArrangementCreateManyUserInput = {
    id?: string
    type: string
    vendor: string
    contact?: string | null
    notes?: string | null
    createdAt?: Date | string
  }

  export type TimelineItemCreateManyUserInput = {
    id?: string
    date: Date | string
    title: string
    story?: string | null
    mediaUrl?: string | null
    createdAt?: Date | string
  }

  export type VaultItemCreateManyUserInput = {
    id?: string
    label: string
    encryptedData: string
    createdAt?: Date | string
  }

  export type PhotoCreateManyUserInput = {
    id?: string
    timelineItemId?: string | null
    url: string
    thumbnailUrl?: string | null
    blobPath: string
    caption?: string | null
    width?: number | null
    height?: number | null
    sizeBytes?: number | null
    order?: number
    createdAt?: Date | string
  }

  export type MessageInviteCreateManyUserInput = {
    id?: string
    token: string
    contributorName: string
    contributorEmail?: string | null
    message?: string | null
    expiresAt: Date | string
    revokedAt?: Date | string | null
    lastUsedAt?: Date | string | null
    useCount?: number
    createdAt?: Date | string
  }

  export type ContributionCreateManyUserInput = {
    id?: string
    inviteId: string
    contributorName: string
    contributorNote?: string | null
    type: string
    content?: string | null
    mediaUrl?: string | null
    mediaBlobPath?: string | null
    viewedByUser?: boolean
    importedToTimelineItemId?: string | null
    archivedAt?: Date | string | null
    createdAt?: Date | string
  }

  export type ContactUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    relationship?: NullableStringFieldUpdateOperationsInput | string | null
    isExecutor?: BoolFieldUpdateOperationsInput | boolean
    isBackup?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ContactUncheckedUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    relationship?: NullableStringFieldUpdateOperationsInput | string | null
    isExecutor?: BoolFieldUpdateOperationsInput | boolean
    isBackup?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ContactUncheckedUpdateManyWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    name?: StringFieldUpdateOperationsInput | string
    email?: NullableStringFieldUpdateOperationsInput | string | null
    phone?: NullableStringFieldUpdateOperationsInput | string | null
    relationship?: NullableStringFieldUpdateOperationsInput | string | null
    isExecutor?: BoolFieldUpdateOperationsInput | boolean
    isBackup?: BoolFieldUpdateOperationsInput | boolean
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type MessageUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    recipientName?: StringFieldUpdateOperationsInput | string
    recipientEmail?: NullableStringFieldUpdateOperationsInput | string | null
    type?: StringFieldUpdateOperationsInput | string
    subject?: NullableStringFieldUpdateOperationsInput | string | null
    content?: NullableStringFieldUpdateOperationsInput | string | null
    mediaUrl?: NullableStringFieldUpdateOperationsInput | string | null
    mediaBlobPath?: NullableStringFieldUpdateOperationsInput | string | null
    mediaDurationSec?: NullableIntFieldUpdateOperationsInput | number | null
    triggerDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    state?: StringFieldUpdateOperationsInput | string
    approvalPromptedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    approvalExpiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    sentAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    archivedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    deliveryToken?: NullableStringFieldUpdateOperationsInput | string | null
    approvalToken?: NullableStringFieldUpdateOperationsInput | string | null
    approvalRemindersSent?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type MessageUncheckedUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    recipientName?: StringFieldUpdateOperationsInput | string
    recipientEmail?: NullableStringFieldUpdateOperationsInput | string | null
    type?: StringFieldUpdateOperationsInput | string
    subject?: NullableStringFieldUpdateOperationsInput | string | null
    content?: NullableStringFieldUpdateOperationsInput | string | null
    mediaUrl?: NullableStringFieldUpdateOperationsInput | string | null
    mediaBlobPath?: NullableStringFieldUpdateOperationsInput | string | null
    mediaDurationSec?: NullableIntFieldUpdateOperationsInput | number | null
    triggerDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    state?: StringFieldUpdateOperationsInput | string
    approvalPromptedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    approvalExpiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    sentAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    archivedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    deliveryToken?: NullableStringFieldUpdateOperationsInput | string | null
    approvalToken?: NullableStringFieldUpdateOperationsInput | string | null
    approvalRemindersSent?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type MessageUncheckedUpdateManyWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    recipientName?: StringFieldUpdateOperationsInput | string
    recipientEmail?: NullableStringFieldUpdateOperationsInput | string | null
    type?: StringFieldUpdateOperationsInput | string
    subject?: NullableStringFieldUpdateOperationsInput | string | null
    content?: NullableStringFieldUpdateOperationsInput | string | null
    mediaUrl?: NullableStringFieldUpdateOperationsInput | string | null
    mediaBlobPath?: NullableStringFieldUpdateOperationsInput | string | null
    mediaDurationSec?: NullableIntFieldUpdateOperationsInput | number | null
    triggerDate?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    state?: StringFieldUpdateOperationsInput | string
    approvalPromptedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    approvalExpiresAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    sentAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    archivedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    deliveryToken?: NullableStringFieldUpdateOperationsInput | string | null
    approvalToken?: NullableStringFieldUpdateOperationsInput | string | null
    approvalRemindersSent?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    updatedAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ArrangementUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    type?: StringFieldUpdateOperationsInput | string
    vendor?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ArrangementUncheckedUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    type?: StringFieldUpdateOperationsInput | string
    vendor?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ArrangementUncheckedUpdateManyWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    type?: StringFieldUpdateOperationsInput | string
    vendor?: StringFieldUpdateOperationsInput | string
    contact?: NullableStringFieldUpdateOperationsInput | string | null
    notes?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type TimelineItemUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    date?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    story?: NullableStringFieldUpdateOperationsInput | string | null
    mediaUrl?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    photos?: PhotoUpdateManyWithoutTimelineItemNestedInput
  }

  export type TimelineItemUncheckedUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    date?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    story?: NullableStringFieldUpdateOperationsInput | string | null
    mediaUrl?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    photos?: PhotoUncheckedUpdateManyWithoutTimelineItemNestedInput
  }

  export type TimelineItemUncheckedUpdateManyWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    date?: DateTimeFieldUpdateOperationsInput | Date | string
    title?: StringFieldUpdateOperationsInput | string
    story?: NullableStringFieldUpdateOperationsInput | string | null
    mediaUrl?: NullableStringFieldUpdateOperationsInput | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type VaultItemUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    label?: StringFieldUpdateOperationsInput | string
    encryptedData?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type VaultItemUncheckedUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    label?: StringFieldUpdateOperationsInput | string
    encryptedData?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type VaultItemUncheckedUpdateManyWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    label?: StringFieldUpdateOperationsInput | string
    encryptedData?: StringFieldUpdateOperationsInput | string
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PhotoUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    url?: StringFieldUpdateOperationsInput | string
    thumbnailUrl?: NullableStringFieldUpdateOperationsInput | string | null
    blobPath?: StringFieldUpdateOperationsInput | string
    caption?: NullableStringFieldUpdateOperationsInput | string | null
    width?: NullableIntFieldUpdateOperationsInput | number | null
    height?: NullableIntFieldUpdateOperationsInput | number | null
    sizeBytes?: NullableIntFieldUpdateOperationsInput | number | null
    order?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    timelineItem?: TimelineItemUpdateOneWithoutPhotosNestedInput
  }

  export type PhotoUncheckedUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    timelineItemId?: NullableStringFieldUpdateOperationsInput | string | null
    url?: StringFieldUpdateOperationsInput | string
    thumbnailUrl?: NullableStringFieldUpdateOperationsInput | string | null
    blobPath?: StringFieldUpdateOperationsInput | string
    caption?: NullableStringFieldUpdateOperationsInput | string | null
    width?: NullableIntFieldUpdateOperationsInput | number | null
    height?: NullableIntFieldUpdateOperationsInput | number | null
    sizeBytes?: NullableIntFieldUpdateOperationsInput | number | null
    order?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PhotoUncheckedUpdateManyWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    timelineItemId?: NullableStringFieldUpdateOperationsInput | string | null
    url?: StringFieldUpdateOperationsInput | string
    thumbnailUrl?: NullableStringFieldUpdateOperationsInput | string | null
    blobPath?: StringFieldUpdateOperationsInput | string
    caption?: NullableStringFieldUpdateOperationsInput | string | null
    width?: NullableIntFieldUpdateOperationsInput | number | null
    height?: NullableIntFieldUpdateOperationsInput | number | null
    sizeBytes?: NullableIntFieldUpdateOperationsInput | number | null
    order?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type MessageInviteUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    contributorName?: StringFieldUpdateOperationsInput | string
    contributorEmail?: NullableStringFieldUpdateOperationsInput | string | null
    message?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: DateTimeFieldUpdateOperationsInput | Date | string
    revokedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    lastUsedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    useCount?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    contributions?: ContributionUpdateManyWithoutInviteNestedInput
  }

  export type MessageInviteUncheckedUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    contributorName?: StringFieldUpdateOperationsInput | string
    contributorEmail?: NullableStringFieldUpdateOperationsInput | string | null
    message?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: DateTimeFieldUpdateOperationsInput | Date | string
    revokedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    lastUsedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    useCount?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    contributions?: ContributionUncheckedUpdateManyWithoutInviteNestedInput
  }

  export type MessageInviteUncheckedUpdateManyWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    token?: StringFieldUpdateOperationsInput | string
    contributorName?: StringFieldUpdateOperationsInput | string
    contributorEmail?: NullableStringFieldUpdateOperationsInput | string | null
    message?: NullableStringFieldUpdateOperationsInput | string | null
    expiresAt?: DateTimeFieldUpdateOperationsInput | Date | string
    revokedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    lastUsedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    useCount?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ContributionUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    contributorName?: StringFieldUpdateOperationsInput | string
    contributorNote?: NullableStringFieldUpdateOperationsInput | string | null
    type?: StringFieldUpdateOperationsInput | string
    content?: NullableStringFieldUpdateOperationsInput | string | null
    mediaUrl?: NullableStringFieldUpdateOperationsInput | string | null
    mediaBlobPath?: NullableStringFieldUpdateOperationsInput | string | null
    viewedByUser?: BoolFieldUpdateOperationsInput | boolean
    importedToTimelineItemId?: NullableStringFieldUpdateOperationsInput | string | null
    archivedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    invite?: MessageInviteUpdateOneRequiredWithoutContributionsNestedInput
  }

  export type ContributionUncheckedUpdateWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    inviteId?: StringFieldUpdateOperationsInput | string
    contributorName?: StringFieldUpdateOperationsInput | string
    contributorNote?: NullableStringFieldUpdateOperationsInput | string | null
    type?: StringFieldUpdateOperationsInput | string
    content?: NullableStringFieldUpdateOperationsInput | string | null
    mediaUrl?: NullableStringFieldUpdateOperationsInput | string | null
    mediaBlobPath?: NullableStringFieldUpdateOperationsInput | string | null
    viewedByUser?: BoolFieldUpdateOperationsInput | boolean
    importedToTimelineItemId?: NullableStringFieldUpdateOperationsInput | string | null
    archivedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ContributionUncheckedUpdateManyWithoutUserInput = {
    id?: StringFieldUpdateOperationsInput | string
    inviteId?: StringFieldUpdateOperationsInput | string
    contributorName?: StringFieldUpdateOperationsInput | string
    contributorNote?: NullableStringFieldUpdateOperationsInput | string | null
    type?: StringFieldUpdateOperationsInput | string
    content?: NullableStringFieldUpdateOperationsInput | string | null
    mediaUrl?: NullableStringFieldUpdateOperationsInput | string | null
    mediaBlobPath?: NullableStringFieldUpdateOperationsInput | string | null
    viewedByUser?: BoolFieldUpdateOperationsInput | boolean
    importedToTimelineItemId?: NullableStringFieldUpdateOperationsInput | string | null
    archivedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ContributionCreateManyInviteInput = {
    id?: string
    userId: string
    contributorName: string
    contributorNote?: string | null
    type: string
    content?: string | null
    mediaUrl?: string | null
    mediaBlobPath?: string | null
    viewedByUser?: boolean
    importedToTimelineItemId?: string | null
    archivedAt?: Date | string | null
    createdAt?: Date | string
  }

  export type ContributionUpdateWithoutInviteInput = {
    id?: StringFieldUpdateOperationsInput | string
    contributorName?: StringFieldUpdateOperationsInput | string
    contributorNote?: NullableStringFieldUpdateOperationsInput | string | null
    type?: StringFieldUpdateOperationsInput | string
    content?: NullableStringFieldUpdateOperationsInput | string | null
    mediaUrl?: NullableStringFieldUpdateOperationsInput | string | null
    mediaBlobPath?: NullableStringFieldUpdateOperationsInput | string | null
    viewedByUser?: BoolFieldUpdateOperationsInput | boolean
    importedToTimelineItemId?: NullableStringFieldUpdateOperationsInput | string | null
    archivedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutContributionsNestedInput
  }

  export type ContributionUncheckedUpdateWithoutInviteInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    contributorName?: StringFieldUpdateOperationsInput | string
    contributorNote?: NullableStringFieldUpdateOperationsInput | string | null
    type?: StringFieldUpdateOperationsInput | string
    content?: NullableStringFieldUpdateOperationsInput | string | null
    mediaUrl?: NullableStringFieldUpdateOperationsInput | string | null
    mediaBlobPath?: NullableStringFieldUpdateOperationsInput | string | null
    viewedByUser?: BoolFieldUpdateOperationsInput | boolean
    importedToTimelineItemId?: NullableStringFieldUpdateOperationsInput | string | null
    archivedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type ContributionUncheckedUpdateManyWithoutInviteInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    contributorName?: StringFieldUpdateOperationsInput | string
    contributorNote?: NullableStringFieldUpdateOperationsInput | string | null
    type?: StringFieldUpdateOperationsInput | string
    content?: NullableStringFieldUpdateOperationsInput | string | null
    mediaUrl?: NullableStringFieldUpdateOperationsInput | string | null
    mediaBlobPath?: NullableStringFieldUpdateOperationsInput | string | null
    viewedByUser?: BoolFieldUpdateOperationsInput | boolean
    importedToTimelineItemId?: NullableStringFieldUpdateOperationsInput | string | null
    archivedAt?: NullableDateTimeFieldUpdateOperationsInput | Date | string | null
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PhotoCreateManyTimelineItemInput = {
    id?: string
    userId: string
    url: string
    thumbnailUrl?: string | null
    blobPath: string
    caption?: string | null
    width?: number | null
    height?: number | null
    sizeBytes?: number | null
    order?: number
    createdAt?: Date | string
  }

  export type PhotoUpdateWithoutTimelineItemInput = {
    id?: StringFieldUpdateOperationsInput | string
    url?: StringFieldUpdateOperationsInput | string
    thumbnailUrl?: NullableStringFieldUpdateOperationsInput | string | null
    blobPath?: StringFieldUpdateOperationsInput | string
    caption?: NullableStringFieldUpdateOperationsInput | string | null
    width?: NullableIntFieldUpdateOperationsInput | number | null
    height?: NullableIntFieldUpdateOperationsInput | number | null
    sizeBytes?: NullableIntFieldUpdateOperationsInput | number | null
    order?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
    user?: UserUpdateOneRequiredWithoutPhotosNestedInput
  }

  export type PhotoUncheckedUpdateWithoutTimelineItemInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    url?: StringFieldUpdateOperationsInput | string
    thumbnailUrl?: NullableStringFieldUpdateOperationsInput | string | null
    blobPath?: StringFieldUpdateOperationsInput | string
    caption?: NullableStringFieldUpdateOperationsInput | string | null
    width?: NullableIntFieldUpdateOperationsInput | number | null
    height?: NullableIntFieldUpdateOperationsInput | number | null
    sizeBytes?: NullableIntFieldUpdateOperationsInput | number | null
    order?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }

  export type PhotoUncheckedUpdateManyWithoutTimelineItemInput = {
    id?: StringFieldUpdateOperationsInput | string
    userId?: StringFieldUpdateOperationsInput | string
    url?: StringFieldUpdateOperationsInput | string
    thumbnailUrl?: NullableStringFieldUpdateOperationsInput | string | null
    blobPath?: StringFieldUpdateOperationsInput | string
    caption?: NullableStringFieldUpdateOperationsInput | string | null
    width?: NullableIntFieldUpdateOperationsInput | number | null
    height?: NullableIntFieldUpdateOperationsInput | number | null
    sizeBytes?: NullableIntFieldUpdateOperationsInput | number | null
    order?: IntFieldUpdateOperationsInput | number
    createdAt?: DateTimeFieldUpdateOperationsInput | Date | string
  }



  /**
   * Batch Payload for updateMany & deleteMany & createMany
   */

  export type BatchPayload = {
    count: number
  }

  /**
   * DMMF
   */
  export const dmmf: runtime.BaseDMMF
}